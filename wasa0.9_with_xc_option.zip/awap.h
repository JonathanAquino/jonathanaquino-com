#ifndef ___awap___
#define ___awap___

#include "awap-eval.h"

/*----------------------------------------*
 * awap.h -- awap header file (1/20/99)
 *----------------------------------------*/

#define DOC_SEP '\0'  //the internal document delimitor for '\n'.
#define SNT_SEP '\1'  //the internal sentence delimitor for sub-documents.
#define MAXDEPTH 50
#define defposfile "./tmp.pos"
#define defnegfile "./tmp.neg"
#define LINEBUFLEN 256  //for command
#define MAXWORD 128	//for STRBUF

#define TRUE  (1)
#define FALSE (0)
#define UNDEF (-1) 

#ifndef min
#define min(a, b) ((a)<=(b) ? (a) : (b))
#endif

//Service procedures
//Used in awap.c and awap-pat.c
#define RATIO(X, Y) ((Y) ? ((double) (X)/(double) (Y)) : 1.0)
extern void ERREXIT(char *message);

#endif
