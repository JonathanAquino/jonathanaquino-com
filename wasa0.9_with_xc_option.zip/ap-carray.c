/******************************************************************
 * ap-carray.c
 * - character array module 
 * 11 JUN 00: created by arim@i.kyushu-u.ac.jp
 *            a modification of ap-iarray.c
 * $Id: ap-carray.c,v 1.1.1.1 2006/07/20 12:24:20 arim Exp $
 ******************************************************************/

#include <assert.h>
#include <stdio.h>  /* for BUFSIZ */
#include <stdlib.h>  
#include <string.h> /* for memcpy */
#include <math.h>   /* for pow(), and log() */
#include <ctype.h>  /* isgraph(), isspace() */
#include <limits.h>  /* INT_MAX */
#include "ap-util.h"
#include "ap-carray.h"

/*
 * Intarray
 */

#define ASSERT_ON
//#undef ASSERT_ON

#define PRINT_IN_ASCII
//#undef PRINT_IN_ASCII

//#define DEBUG

/******************************************************************
 * Allocation and free routines
 * 
 ******************************************************************/

ChaArray ca_alloc_len(int len)
{
  ChaArray tmp; /* Note: Charray is a pointer to a struct. */
  char *tmpval;

  if ((tmp = (ChaArray) malloc(sizeof(struct _cha_array))) == NULL)
    error_exit("ca_alloc: cannot allocate memory\n");

  len = max(len, DEFAULT_ARRAY_LEN); /* for efficiency with realloc() */
  if ((tmpval = (char *) calloc(len, sizeof(char))) == NULL)
    error_exit("ca_alloc: cannot allocate memory\n");
  tmp->val    = tmpval;
  tmp->len    = 0;      /* A new array is always empty */
  tmp->maxlen = len;
  return tmp;
}

ChaArray ca_alloc(void) {
	return ca_alloc_len(0);
}

void ca_free(ChaArray tmp)
{
  if (tmp == NULL) return;
  free(tmp->val);
  /* do nothing for tmp->len */
  /* do nothing for tmp->maxlen */
  free(tmp);
}

void ca_make_null(ChaArray tmp)
{
  tmp->len = 0; 
  /* do nothing for tmp->val */
  /* do nothing for tmp->maxlen */
}


/* Inport ap_expansion_length() from ap-util.h */

void ca_realloc(ChaArray ca, int size)
{
  int maxlen;
  char *tmpval; 

#ifdef DEBUG
  assert(ca != NULL);
#endif
  /*
   * No need for expansion
   */
  if (ca->maxlen >= size)
    return; /* do nothing */
  
  /*
   * Expanding ca so that it has enough length to keep size cells. 
   */
  maxlen = ap_expansion_length(size);
  /* debug("ca_realloc: ap_expansion_length=%d\n", maxlen); */
  if ((tmpval = (char *) realloc(ca->val, maxlen * sizeof(char))) == NULL)
    error_exit("ca_alloc: cannot reallocate memory\n");
  ca->val    = tmpval;
  ca->maxlen = maxlen; 
  /* do nothing with ca->len */
}

/******************************************************************
 * Array generator
 * 
 ******************************************************************/

int ca_get(ChaArray ia, int i) {
  assert(i < ia->len);
  return ia->val[i];
}

int ca_put(ChaArray ia, int i, int value) {
  int n;
  if (i >= ia->len) {
    ia_realloc(ia, i+1);
    for (n = ia->len; n < i+1; n++) 
	  ia->val[n] = 0;
  }
  ia->val[i] = value;
  ia->len = i+1;
}

void ca_fill_random(ChaArray ca, char low, char high, int len)
{   /* fill ca with len random elements whose values take
       the range from char low to char high including high. */
    int n, m;
    int range;
    char  ch;

#ifdef ASSERT_ON
    assert(ca != NULL);
#endif
    range = high - low + 1; //Note: +1 is necessary to include high
    ca_make_null(ca);
    for (n = 0; n < len; n++) {
      m = (rand() % range);
      ch = (char) low + m;
      ca_add(ca, ch); 
    }
    ca->len = n;
}

void ca_fill_random_alpha(ChaArray ca, int len) {
  ca_fill_random(ca, 'A', 'Z', len);
}

void ca_fill_random_digit(ChaArray ca, int len) {
  ca_fill_random(ca, '0', '9', len);
}

void ca_fill_random_genome(ChaArray ca, int len) {
  char c, d;
  int n;
  ca_fill_random(ca, 'A', 'D', len);
  for (n = 0; n < len; n++) {
    c = ca->val[n];
    if (c == 'A') 
      d = 'A';
    else if (c == 'B') 
      d = 'T';
    else if (c == 'C') 
      d = 'C';
    else if (c == 'D') 
      d = 'G';
    else
      d = '!';
    ca->val[n] = d;
  }
}


int ca_is_equal(ChaArray ca, ChaArray da)
{ /* checks if ca and da are same intarrays
   */
  int n;
#ifdef ASSERT_ON
  assert(ca != NULL && da != NULL); 
  assert(ca->maxlen >= da->len);
#endif
  if (ca->len != da->len)
    return 0;
  for (n = 0; n < ca->len; n++)
    if (ca->val[n] != da->val[n])
      return 0;
  return 1;
}

/******************************************************************
 * Append routines
 * 
 ******************************************************************/

/* inline cannot used for g++ due to undefined refenrece at ld */
//inline 
void ca_push_back(ChaArray ca, char c)
{ /* - append a character with the end of ca. 
   * - expands the array if it is full. 
   */
  int len;
#ifdef DEBUG
  assert(ca != NULL);
#endif
  len = ca->len; 
  ca_realloc(ca, len + 1); /* ensuring ca->len < len+1 */
  ca->val[len] = c;
  ca->len = len + 1;
}

void ca_add(ChaArray ca, char c)
{
  ca_push_back(ca, c);
}

/* - returns the last element of ca */
char ca_last(ChaArray ca) {   
#ifdef ASSERT_ON
    assert(ca != NULL); 
    assert(ca->len > 0); /* critical */
#endif
    return (ca->val[ca->len - 1]);
}

/* returns the index of the last element */
int ca_tail_index(ChaArray ca) {
  return ca->len - 1;
}

void ca_append(ChaArray ca, ChaArray cb)
{ /* - append the contents of ib with the end of ca
   * - ca is reallocated if it has enough memory to have cb. 
   */
  int n, m; 

#ifdef DEBUG
  assert(ca != NULL && cb != NULL);
#endif
  ca_realloc(ca, (ca->len + cb->len));
  for (m = ca->len, n = 0; n < cb->len; m++, n++)
    ca->val[m] = cb->val[n];
  ca->len = m; 
}

/* fast version with memcopy */
void ca_copy(ChaArray ca, ChaArray cb)
{ /* - copies the contents of cb into the cells of ca
   * - it is truncated if cb is longer than the allocated part of ca. 
   */
  int n, maxlen;
#ifdef DEBUG
  assert(ca != NULL && cb != NULL);
#endif
  ca_realloc(ca, cb->len);
  memcpy(ca->val, cb->val, cb->len * sizeof(char));
  ca->len = cb->len;
}

void ca_copy_org(ChaArray ca, ChaArray cb)
{ /* - copies the contents of cb into the cells of ca
   * - it is truncated if cb is longer than the allocated part of ca. 
   */
  int n, maxlen;
//#ifdef DEBUG
  assert(ca != NULL && cb != NULL);
//#endif
  ca_realloc(ca, cb->len);
  ca_make_null(ca);  
  for (n = 0; n < cb->len; n++)
    ca_add(ca, cb->val[n]);
}

int ca_top(ChaArray ca) {  return ca_last(ca);  } //wrapper 

int ca_is_empty(ChaArray ca)
{
#ifdef ASSERT_ON
    assert(ca != NULL);
#endif
    return (ca->len == 0);
}

void ca_push(ChaArray ca, char c)
{
  ca_push_back(ca, c);
}

/* inline cannot used for g++ due to undefined refenrece at ld */
//inline 
char ca_pop(ChaArray ca) 
{ /* - append a character with the end of ca. 
   * - expands the array if it is full. 
   */
#ifdef DEBUG
    assert(ca != NULL);
#endif
    return ca->val[--(ca->len)];
}

/******************************************************************
 * Print routines
 * 
 ******************************************************************/

char printable_char(char c) {
  if (isgraph(c))
    return c;
  else if (c == '\0')
    return '#'; 
  else if (isspace(c))
    return '_'; 
  else
    return '@'; 
}

void ca_print_printable_char(ChaArray ca)
{
  int n;
  char ch;
#ifdef DEBUG
  assert(ca != NULL);
#endif
  if (ca == NULL) return; 
  for (n = 0; n < ca->len; n++) {
    ch = printable_char(ca->val[n]);
    printf("%c", ch);
  }
}

void ca_print_ascii(ChaArray ca)
{
  int n;
  char c;
#ifdef DEBUG
  assert(ca != NULL);
#endif
  if (ca == NULL) return; 

  for (n = 0; n < ca->len; n++) {
    c = ca->val[n];
    if (isgraph(c))
      printf("%c", c);
    else if (isspace(c))
      printf("%c", ' ');
    else if (c == '\n')
      printf("\'\\n\'");
    else if (c == '\r')
      printf("\'\\r\'");
    else
      printf("\'\\%d\'", c);
  }
}

void ca_print(ChaArray ca) {
#ifdef PRINT_IN_ASCII
    ca_print_ascii(ca); 
#else
    ca_print_printable_char(ca); 
#endif
}

void ca_report(ChaArray ca)
{
  int maxlen = DEFAULT_COLWIDTH * 3; 
  if(ca == NULL) {
    printf("\t ia\t == NULL!\n");
    return;
  }
  printf("\t ca\t len=%d\t maxlen=%d (%.3f MB)\n",
	 ca->len,
	 ca->maxlen, 
	 ((double) ca->maxlen)* (double) sizeof(char) / MEGA
	 );
  if (ca->len <= maxlen) {
    printf("\t[");
    ca_print(ca);
    printf("]\n");
  } else {
    printf("\t skipping the output... \n");
  }
}

/*
 * Print routines for unsigned char as small integers. 
 */

void ca_print_code(ChaArray ca)
{
  int n;
#ifdef DEBUG
  assert(ca != NULL);
#endif
  if (ca == NULL) return; 
  for (n = 0; n < ca->len; n++)
    printf("\'\\%u\':", (unsigned int) ca->val[n]); /* printing as an unsigned integer */
}

//for compatibility
void ca_int_print(ChaArray ca) { ca_print_code(ca); }

void ca_report_code(ChaArray ca)
{
    int maxlen = DEFAULT_COLWIDTH * 3; 
    if(ca == NULL) {
	printf("\t ia\t == NULL!\n");
	return;
    }
    printf("\t ca\t len=%d\t maxlen=%d\n", ca->len, ca->maxlen);
    if (ca->len <= maxlen) {
	printf("\t "); ca_int_print(ca); print_nl();
    } else {
	printf("\t skipping the output... \n");
    }
}

//for compatibility
void ca_int_report(ChaArray ca) { ca_report_code(ca); }



/******************************************************************
 * File I/O routines
 * 
 ******************************************************************/

#ifndef min
#define min(a, b) ((a)<=(b) ? (a) : (b))
#endif
#define PERMS 0666
#define MYBUFSIZ (4)
#define WRITABLE(n, nmax) (min(MYBUFSIZ, nmax - n))
/* BUFSIZ == 1024 in stdio.h on Solaris2.6 */

int ca_write_disk(ChaArray ca, char *out_filename)
{   /* - writes the contents of ca to a binary file on a disk.  
     * - returns the number of bytes written if succeeded and
     * NULL otherwise. */
    FILE *fp;
    int n     = 0; /* the number of bytes written so far*/

    debug("ca_write_disk: opening output file: %s\n", out_filename);
    /* Carray: Is it right? */
    if ((fp = fopen(out_filename, "wb")) == NULL) { /* to open with 666 */
	/* Warning: this mode should be binary */
	printf("ca_write_disk: cannot open %s\n", out_filename);
	return FALSE;
    }

    debug("ca_write_disk: writing a char array...\n");
    for (n = 0; n < ca->len; n++) {
      if (fputc(ca->val[n], fp) == EOF)
	break; //for
    }
    //debug("ca_write_disk: closing output file...\n");
    fclose(fp);
    if (n != ca->len)
    error_exit("ca_write_disk: write error at %dth letter on %s\n",
	       n, out_filename);
    return n; 
}

int ca_read_disk(ChaArray ca, char *in_filename)
{ /* - reads the contents of ca from a binary file on a disk. 
   * - returns the number of bytes written if succeeded and
   * NULL otherwise. */
    FILE *fp;
    int n   = 0;	/* the number of letters written */
    char c;
    
    debug("ca_read_disk: opening input file: %s\n", in_filename);
    if ((fp = fopen(in_filename, "rb")) == NULL) {
	/* Warning: the mode should be binary to correct reading */
	printf("ca_read_disk: cannot open %s\n", in_filename);
	return FALSE;
    }
    
#ifdef DEBUG
    assert(ca != NULL);
#endif
    debug("ca_read_disk: reading an int array...\n");
    n   = 0;
    while ((c = fgetc(fp)) != EOF) {
      ca_add(ca, c);
      n++;
    }
    if (ferror(fp)) { /* error of some kind */
	printf("ca_read_disk: read error on file %s\n", in_filename);
	fclose(fp);
	return FALSE;
    }
    debug("ca_read_disk: closing input file...\n");
    fclose(fp);
    return n; 
}

int ca_remove_disk(char *filename) {
  int n = 1;
  if ((n = remove(filename)) == EOF) {
	printf("ca_remove_disk: cannot remove file %s\n", filename);
	return FALSE;
  }
}

/*
 * verification: 24 SEP 99 by arim
 */

int ca_veryfy_disk(ChaArray ca, char *filename)
{ /* - Verify if the original ia and its copy on a disk  file_name are
     identical */
  ChaArray cac;
  int n;
  
  cac = ca_alloc_len(ca->len); /* temporary */
  if (ca_read_disk(cac, filename) == FALSE)  {
      printf("ca_verify: cannot read the file: %s\n", filename);
      return FALSE;
  }
  for (n = 0; n < cac->len; n++) {
      //if (1) 
      //  debug("equiv: n=%d: %d!=%d\n", n, ca->val[n], cac->val[n]);
      if (ca->val[n] != cac->val[n]) {
	  printf("ca and cac differ at %d-th cell!\n", n);
	  return FALSE;
      }
  }
  debug("ca_verify: verification suceeded. \n");  
  return TRUE;
}

/******************************************************************
 * Interface to C-string
 ******************************************************************/

/* ca_append_str:
 * - appends a C-string to the tail of ca. 
 */
ChaArray ca_append_str(ChaArray ca, char *str)
{
    int n = 0;

    while (*str != '\0' && n < INT_MAX) {
	  ca_add(ca, *str);
	  str++;
	  n++; 
    }
    return ca; 
}

/* ca_copy_str:
 * - overwrite a C-string to the tail of ca.
 */

//inline /* inline cannot used for g++ due to undefined refenrece at ld */
ChaArray ca_copy_str(ChaArray ca, char *str)
{
    int n = 0;

    ca_make_null(ca);
    return ca_append_str(ca, str);
}

/* ca_copy_str:
 * - copy the contents of ca into a C-string. 
 */
void ca_write_to_str(ChaArray ca, char *str, int len)
{
  int n;
  assert(ca != NULL);
  len = min(len, ca->len); 
  for (n = 0; n < len; n++)
    str[n] = ca->val[n]; 
}

/******************************************************************
 * End
 * 
 ******************************************************************/

