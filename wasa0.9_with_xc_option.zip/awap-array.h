#ifndef ___array___
#define ___array___

/* 
 * awap-array.c -- template for awap programs
 * - modified based on awap-pat.c on 30 JUL 2005 by arim@ist
 * - created by arim@i (dd/mm/yy)
 */

#include "awap.h"

/*
 * Macros
 */

/*
 * Types 
 */ 

/*
 * Externs: functions and global varialbles 
 */ 

extern void intcpy(int *A, int *B, int len); 
extern int count_index_points(char *Text, int N, DocSet docset);
extern void make_index_array(char *Text, int *A, int N, DocSet docset);
extern void make_Prm(int *Sary, int *Prm, int n); 
extern void make_Doc(char *Text, int *A, int *Doc, int N, int n, DocSet docset);
extern void make_ObjC(char *ObjC, int Posnum, int Negnum); 
extern void make_Hgt_Simple(char *Text, int *A, int *Sary, int *Hgt, int n,int len);
extern void count_matchlength(DocSet docset); 
extern char *get_a_document(char Text[], int A[], int Sary[],
							int Doc[], int N, int n,
							int idx,
							int *len_ptr, int *orig_ptr, int *doc_ptr); 

/* LCP with function pointer */
extern int lcp_word(int p, int q, char *Text);
extern int lcp_letter(int p, int q, char *Text);
extern void make_Hgt_Simple_Func(char *Text, int *A, int *Sary, int *Hgt,
								 int n, int len,
								 int (*lcpfunc)(int p, int q, char *Text));

#endif 
