#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "awap.h"
//#include "awap-pat.h"
#include "awap-pattern.h"
#include "awap-query.h"
#include "awap-docset.h"
#include "awap-discover.h"


#define COMLEN_FIND 8 // #args + 1
#define COMLEN 8 // #args + 1

#define USAGE_STR_FIND "usage: find d k [eval #pat flag_w flag_e [firstword]] \n"


//Global:
static char argv[COMLEN][MAXWORD];
static int  argc = 0;

int check_number_range(int value, char *msg, int low, int high) {
    if (value < low || value > high) {
        talk_printf_msg("check_number_range param [%s] must has range [%d,%d]\n", msg, 0, 1);
        talk_send_msg();
        return 0;
    }
    else
        return 1;
}

void command_find(int argc, char *argv[], DocSet docset, QUERY *query, PatSet *patset_ptr)
{
    //Args
    if (argc == 0) {
        talk_printf_msg(USAGE_STR_FIND);//Try again!
        talk_send_msg();
        return;
    }
    if (argc > 0) query->top_k = atoi(argv[4]);
    if (argc > 1) {
        query->eval = atoi(argv[3]);
        if (!check_number_range(query->eval, "eval", 1, MAX_FUNC))
            return;
    }
    if (argc > 2) {
        talk_printf_msg(USAGE_STR_FIND);//Try again!
        talk_send_msg();
        return;
    }

    //Mining
    *patset_ptr = discover(docset, query);

    //Output
    patset_print(*patset_ptr);
}

#define USAGE_STR_SIDE "usage: setside num  (num = +1, 0, -1)"

void command_side(int  argc, char *argv[], DocSet docset, Query query) {
    //Args
    if (argc < 2)
        ERREXIT("too few arguments! \n" USAGE_STR_SIDE);
    int flag = atoi(argv[1]);
    query->occ_side = flag;
}

#define USAGE_STR_SET "usage: set param [values] \n" \
"- set side val\t print only patterns in <val> side (pos/+1, both/0, or neg/-1 side \n" \
"- set minsup val\t find only patterns of min frequency <val>\n" \
" "

#define DEBUG_CMDSET

void command_set(int  argc, char *argv[], DocSet docset, QUERY *query) {
    char *param = argv[1];

    //Command dispatch

        if (argc < 2) {
            printf("no arguments\n" USAGE_STR_SET "\n");
        }
        else if (is_cmd_match(param, "help")) {
            printf("no arguments\n" USAGE_STR_SET "\n");
        }
        else if (is_cmd_match(param, "topk") ||
                 is_cmd_match(param, "npat")||
                 is_cmd_match(param, "maxpat")) {
            int value = atoi(argv[2]);
            query->top_k = value;
        }
        else if (is_cmd_match(param, "eval")) {
            char *value = argv[2];
            int eid = strtol(value, NULL, 10); //convert str to int
            if (eid <= 0) //note: zero means conversion failed.
                eid = eval_get_eid(value);
            if (eid < 1 && eid > MAX_FUNC) {
                printf("the range of [%s] exceeds [1,%d]: %d\n",
                       value, MAX_FUNC,eid);
                return;
            }
            query->eval = eid;
        }
        else if (is_cmd_match(param, "minsup")) {
            int value = atoi(argv[2]);
            query->min_sup = value;
        }
        else if (is_cmd_match(param, "side") ||
                 is_cmd_match(param, "occside")) {
            int value = atoi(argv[2]);
            query->occ_side = value;
        }
        else if (is_cmd_match(param, "flag_w")) {
            int value = atoi(argv[2]);
            query_set_boolean_flag(query, FLAG_WORD_MODE, value);
        }
        else if (is_cmd_match(param, "flag_b")) {
            int value = atoi(argv[2]);
            query_set_boolean_flag(query, FLAG_BOTH_SIDE, value);
        }
        else if (is_cmd_match(param, "flag_l") ||
                 is_cmd_match(param, "list") ) {
            int value = atoi(argv[2]);
            query_set_boolean_flag(query, FLAG_PRINT_LOC, value);
        }
        else {
            printf("the parameter name not supported: %s\n", param);
        }
}

#define USAGE_STR_PRINT "usage: print param \n" \
"- print query \t print query \n" \
"- #print patset\t print patset <val>\n" \
" "

#define DEBUG_CMDPRINT

void command_print(int  argc, char *argv[], DocSet docset, QUERY *query) {
    char *param = argv[1];

    //Command dispatch

        if (argc < 2) {
            printf("no arguments\n" USAGE_STR_PRINT "\n");
        }
        else if (is_cmd_match(param, "query")) {
            query_print(query);
        }
        else {
            printf("the parameter name not supported: %s\n", param);
        }
}

#define USAGE_STR_SHOW_CNT "usage: show patid  \npatid is any non-negative integer no more than the number of the discovered patterns."

#define DEBUG_CMDSHOW_CNT

void command_context_doc(int  argc, char *argv[], DocSet docset) {
    int len;
    int offset;
    int doc_id;

    if (argc < 2) ERREXIT("too few arguments! \n" USAGE_STR_SHOW_CNT);
    int pos = atoi(argv[1]);

    char *str = ds_get_a_document(docset, pos, &len, &offset, &doc_id);

#ifdef DEBUG_CMDSHOW_CNT
    printf("@doc %d %d [%.*s]\n", doc_id, offset, len, str);
#endif
}

#define DEBUG_CMDPAT

void command_context_pat(int  argc, char *argv[], DocSet docset, PatSet *patset_ptr) {
    if (argc < 2) ERREXIT("too few arguments! \n" USAGE_STR_SHOW_CNT);
    int pid = atoi(argv[1]);

#ifdef DEBUG_CMDPAT
    printf("@pat patset %d, patset_ptr %d\n", *patset_ptr, patset_ptr);
#endif
    PatSet patset = *patset_ptr;

    printf("@pat get_pattern...\n");
    Pattern pattern = patset_get_pattern(patset, pid);

    printf("@pat print_docs...\n");

#ifdef DEBUG_CMDPAT
    printf("@pat %d with %d positions\n", pid, pattern->list->len);
#endif

    ds_print_documents(docset, pattern->list);
}

void command_show_doc(int  argc, char *argv[], DocSet docset) {
    int len;
    int offset;
    if (argc < 2)
        ERREXIT("too few arguments! \n" USAGE_STR_SHOW_CNT);
    int doc_id = atoi(argv[1]);
}

/* EOF */

