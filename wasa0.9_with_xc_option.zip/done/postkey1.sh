#!bash

sort -t ":" -k 5 | cut -d ":" -f1,2,5 | tr ":" "\t"  

