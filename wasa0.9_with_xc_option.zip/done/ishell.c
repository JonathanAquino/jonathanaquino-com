/*
 * ishell.c
 * based on ishell.c
 * 29JUL2005, arim@ist.hokudai.ac.jp
 */

#include <stdio.h>
#include "talk.h"

// For debugging
#define OUT_LONGLINE "01234567890123456789012345678901234567890123456789"
#define ERR_LONGLINE "ABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJ"
#define REPEAT 3  

//===============================================//
//  test routone 
//===============================================//

static int num_repeat = REPEAT; 



void ishell()
{
	int argc = 0;
	int success = 0;
	int i; 
	char line[BUFLEN];
	char command[BUFLEN];

	line[0] = command[0] = '\0';

	fflush(stdin);
	prompt();


	while(get_line(line)) {

		if (get_a_word(line, command) > 0) {
			for (i = 0; i < num_repeat; i++) {
				talk_printf("o%s%d %s\n", command, i, OUT_LONGLINE);
				//fprintf(stdout, "o%s%d %s\n", command, i, OUT_LONGLINE);
				//sentence_end(stdout);
			}

			session_end(stdout);
		}
		else {
			fprintf(stdout, "exit!\n");

			session_end(stdout);
			break;
		} 

		prompt();
	} //endwhile

}

void ishell1()
{
	int argc = 0;
	int success = 0;
	int i; 
	char line[BUFLEN];
	char command[BUFLEN];

	line[0] = command[0] = '\0';

	fflush(stdin);
	prompt();


	while(get_line(line)) {

		if (get_a_word(line, command) > 0) {
			for (i = 0; i < num_repeat; i++) {
				fprintf(stdout, "%s%d %s\n", command, i, OUT_LONGLINE);
				//printout(stdout, "%s%d %s\n", command, i, OUT_LONGLINE);
			}
			session_end(stdout);
			for (i = 0; i < num_repeat; i++) {
				//printout(stdout, "%s%d %s\n", command, i, OUT_LONGLINE);
				fprintf(stdout, "%s%d %s\n", command, i, OUT_LONGLINE);
			}
			session_end(stdout);
			/*       for (i = 0; i < num_repeat; i++) { */
			/* 	//printerr(stderr, "%s%d %s\n", command, i, ERR_LONGLINE); */
			/* 	fprintf(stderr, "%s%d %s\n", command, i, ERR_LONGLINE); */
			/*       } */
			/*       sentence_end(stderr); */
			/*       session_end(stderr); */
      
		}
		else {
			fprintf(stdout, "exit!\n");
			session_end(stdout);
			//session_end(stderr);
			break;
		} 

		prompt();
	} //endwhile

}

int main(int argc, char *argv[])
{
	if (argc == 2) 
		num_repeat = atoi(argv[1]);
	else if (argc > 2) {
		printf("Too many arguments\nusage: ishell [num lines]\n");
		exit(0);
	}
  
	ishell();
	return 0;
}


