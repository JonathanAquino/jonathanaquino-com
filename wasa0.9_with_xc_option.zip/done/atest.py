#!/bin/python.exe
### ashell.py
### - An communication package for interactive communication
###   by Python popen2 module on Cygwin and linux.
### - See 
### O'reilly python cookbook Recipe 9.12.
### "Capturing the Output and Error Streams from a Unix Shell Command"

import aSession 

### TEST ROUTINE ##############################################

HEADER_MSG = '@main ##### beg message #####\n'
TRAILER_MSG= '@main ##### end message ##### '

def putOutput(outdata):
    #Warning this should match only the beginning of a line 
    print HEADER_MSG+outdata+TRAILER_MSG

def shell():

    ### Warning: -z Option is necessary
    masterCommand = './awap.exe -z -p data/ship.pos -n data/ship.neg -w -e ';
    print masterCommand
    session = aSession.Open(masterCommand) 

    shellcmd = 'help \n'
    outdata = aSession.Exec(session, shellcmd)
    putOutput(outdata)

    shellcmd = 'find 1 1 1 5 \n'
    outdata = aSession.Exec(session, shellcmd)
    putOutput(outdata)

    shellcmd = 'end\n'
    outdata = aSession.Exec(session, shellcmd)
    putOutput(outdata)

    aSession.Close(session)
    print '@ishell: Done.'

### EXEC ##############################################

if __name__ == '__main__': ## Exec only when executed as an app
    shell();

### EOF ##############################################
