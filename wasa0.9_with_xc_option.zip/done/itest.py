#!/bin/python.exe 
### oreilly python cookbook Recipe 9.12.
### Capturing the Output and Error Streams from a Unix Shell Command

import aSession 

### TEST ROUTINE ##############################################

HEADER_MSG = '@main ##### beg message #####\n'
TRAILER_MSG= '@main ##### end message ##### '

def putOutput(outdata):
    #Warning this should match only the beginning of a line 
    print HEADER_MSG+outdata+TRAILER_MSG

def shell():

    masterCommand = './ishell.exe ';
    print masterCommand
    session = aSession.Open(masterCommand) 

    shellcmd = 'aaa\n'
    outdata = aSession.Exec(session, shellcmd)
    putOutput(outdata)

    shellcmd = 'bbb\n'
    outdata = aSession.Exec(session, shellcmd)
    putOutput(outdata)

    shellcmd = '\n'
    outdata = aSession.Exec(session, shellcmd)
    putOutput(outdata)

    aSession.Close(session)
    print '@ishell: Done.'

#==========
# Main routine

shell();

### EOF 
