#!bash

sort -t ":" -k 6 | cut -d ":" -f1,2,6 | tr ":" "\t"  

