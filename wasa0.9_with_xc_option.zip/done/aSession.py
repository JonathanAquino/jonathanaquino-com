#!/bin/python.exe
### ashell.py
### - An communication package for interactive communication
###   by Python popen2 module on Cygwin and linux.
### - See 
### O'reilly python cookbook Recipe 9.12.
### "Capturing the Output and Error Streams from a Unix Shell Command"

import os
import popen2
import select
import fcntl
import sys

### Constants and Flags 

Trace = True
Debug = False

### System specific parameter.
maxCount = 1000000 #the maximum number of lines in a session. For debug.

### PUBLIC: TOPLEVEL ROUTINES ######################################
### A pipe triple: 
### pipes = (outpipe, inpipe) 

### Spawn an interactive command to the host environment (e.g.,unix/cygwin)
### returns a pipe triple pipes = (outpipe, inpipe, errpipe)
### usage: pipes = startSession(masterCommand) 

def Open(masterCommand): 
    pipes =  popen2.popen2(masterCommand, 1)
    makeNonBlockingPipes(pipes)
    return pipes

### 
def Exec(pipes, shellcmd):
    outdata = getInteract(pipes, shellcmd)
    if (outdata == None): 
        print "@warning: aSession.Exec: None returned!"
        #print "@error: aSession.Exec: command failed!"
    return outdata 
    
### Closing pipe triple
def Close(pipes):
    closePipes(pipes)

### IMPLEMENTATION ##############################################

### make a given pipe non-blocking
def makeNonBlocking(pipe):
     fd = pipe.fileno()
     fl = fcntl.fcntl(fd, fcntl.F_GETFL)
     fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NDELAY)
     if (Trace): print "@talk makeNonBlocking: made it!"

def makeNonBlockingPipes(pipes):
     (outpipe, inpipe) = pipes
     makeNonBlocking(outpipe)

### Closing pipe triple
def closePipes(pipes):
     (outpipe, inpipe) = pipes
     inpipe.close()
     outpipe.close()

### put a command string to the shell and print all outputs from
### outpipe and errpipe.
### usage: (outdata, errdata) = getInteract(pipes, shellcmd)     
def getInteract(pipes, shellcmd):
    #Note: 
    #outpipe: out stream of the command
    # inpipe:  in stream of the command
    #errpipe: err stream of the command

    (outpipe, inpipe) = pipes
    outfd = outpipe.fileno( )
    infd = inpipe.fileno( )
     
    if (Trace): print '@talk exec [', shellcmd, '] '
    inpipe.write(shellcmd)

    isInitialMsg = True #Indicates the message is the initial one
    outEOF = False
    outdata = ''
    while (not outEOF):

        ##prepare check lists
        #Note: This call of select blocks until at least one file 
        #descriptors in inready is ready.

#         incheck = []
#         if not outEOF:
#             incheck = incheck + [outfd]
#         if (Trace): print '@talk waiting... ', incheck 
#         (inready, outready, errready) = select.select(incheck, [], [])

        # inready:  input indicator of talk.py
        #outready: output indicator of talk.py
        #Note: Now, at least one file descriptor is ready

        incheck = []
        if not outEOF:
            incheck = incheck + [outfd]
        outcheck = []
        if not outEOF:
            outcheck = outcheck + [infd]
        if (Trace): print '@talk waiting... ', incheck 
        #(inready, outready, errready) = select.select(incheck,outcheck,[])
        (inready, outready, errready) = select.select(incheck, [], [])
        if (Trace): 
            print '@talk returned!',' ir=',inready,' or=',outready,' er',errready

        #Check if outfd is ready
        if outfd in inready:
            #if (Trace): print '@talk SESSION BEGS'
            count = 0
            while (True): 
                 outbuffer = outpipe.readline()
                 outmsg = outbuffer.replace('\n', '\\n')

                 if (Trace):
                     print '@talk msg['+outmsg+']'

                 #Something Wrong. May be error occured
                 if (isInitialMsg):
                     #print "aSession: empty outmsg";
                     if (outmsg == ''):
                         return None
                     else:
                         isInitialMsg = False

                 if (outbuffer == 'RET\n'):
                     if (Trace):
                         print '@talk parse [RET] - a session ends'
                         print '==='
                     outEOF = True;
                     break
                 elif (outbuffer == 'BEG\n'):
                     if (Trace):
                         print '@talk parse [BEG] - a msg begins'
                 elif (outbuffer == 'END\n'):
                     if (Trace):
                         print '@talk parse [END] - a msg ends'
                 else:
                     outdata = outdata + outbuffer

                 if (count > maxCount):
                     if (Trace):
                         print '@talk error: number of lines exceeded: '+ str(count)+'>maxCount='+str(maxCount)+'; exit!'
                     outdata = outdata + ' [the transmission killed! maxCount ='+str(count)+']'
                     return outdata
                 count = count + 1
            #end while

    outstr = outdata.replace('BEG\n', '')
    return outstr 

### TEST ROUTINE ##############################################

HEADER_MSG = '@main ##### beg message #####\n'
TRAILER_MSG= '@main ##### end message ##### '

def putOutput(outdata):
    #Warning this should match only the beginning of a line 
    print HEADER_MSG+outdata+TRAILER_MSG

def shell():

    ### Warning: -z Option is necessary
    masterCommand = './awap.exe -z -p data/ship.pos -n data/ship.neg -w -e ';
    print masterCommand
    session = aSession.Open(masterCommand) 

    shellcmd = 'help \n'
    outdata = aSession.Exec(session, shellcmd)
    putOutput(outdata)

    shellcmd = 'find 1 1 1 5 \n'
    outdata = aSession.Exec(session, shellcmd)
    putOutput(outdata)

    shellcmd = 'end\n'
    outdata = aSession.Exec(session, shellcmd)
    putOutput(outdata)

    aSession.Close(session)
    print '@ishell: Done.'

### EXEC ##############################################

if __name__ == '__main__': ## Exec only when executed as an app
    shell();

### EOF ##############################################
