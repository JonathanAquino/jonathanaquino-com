#ifndef ___ev_print___
#define ___ev_print___

/**************************************** 
 * ev_print.h -- 
 * - created by arim@ist (25JUL06)
 ****************************************/

//#include "awap.h"

/****************************************
 * Macros
 ****************************************/

#define EV_EXT_PAT "pat"
#define EV_EXT_SEQ "seq"
#define EV_EXT_DOC "tat"

/****************************************
 * Types 
 ****************************************/ 

/****************************************
 * Externs: functions and global varialbles 
 ****************************************/ 

extern void ev_print_dataset(PatSet patset, char *name);

#endif 
