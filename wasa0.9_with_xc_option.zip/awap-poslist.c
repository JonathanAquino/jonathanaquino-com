/* 
 * awap-ctable.c -- contingency table (02/09/2005)
 */

#include <stdlib.h>
#include "awap-poslist.h"

PosList poslist_create(int maxlen) {
	PosList tmp;
	int *tmpval; 
	if ((tmp = (PosList) malloc(sizeof(struct _poslist))) == NULL)	
		ERREXIT("poslist_create: cannot allocate memory.");
	if ((tmpval = (int *) malloc(maxlen * sizeof(int))) == NULL)	
		ERREXIT("poslist_create: cannot allocate memory.");
	tmp->maxlen = maxlen;
	tmp->len = 0;
	tmp->val = tmpval;
	return tmp;
}

//just copying 
PosList polist_gen(int *ia, int len) {
	PosList list; 
	int i;
	list = poslist_create(len);
	for (i = 0; i < len; i++) {
		list->val[i] = ia[i];
	}
	list->len = len;
	return list;
}

void polist_print(PosList list) {
	int i;
	for (i = 0; i < list->len; i++) {
	  int lpos = list->val[i];
	  printf("%d ", lpos);
	}
	  printf("\n");
}

