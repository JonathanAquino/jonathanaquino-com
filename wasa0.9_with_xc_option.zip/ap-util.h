/*
 * ap-util.h
 * $Id: ap-util.h,v 1.1.1.1 2006/07/20 12:24:20 arim Exp $
 */

#ifndef INCLUDED_AP_UTIL
#define INCLUDED_AP_UTIL

#include <stdio.h>
#include <time.h>
#include <stdarg.h>   /* Necessary for vararg notation ... in this file */

/******************************************************************
 * Importing global variables
 ******************************************************************/

/*
 * Global variables for Timing routines: 
 * from Sedgiwick's tertially quick sort program
 */
extern int    g_rptctr, 
              g_printflg,  
              g_rept;
extern time_t g_starttime;
extern time_t g_time;

/******************************************************************
 * Macros
 ******************************************************************/

#define TRUE  (1)
#define FALSE (0)
#define BYTESIZE  8
#define KILO      1024
#define MEGA      (KILO*KILO)   /* (1048576 = 1024 * 1024)  */

#define BLOCKSIZE  (10 * MEGA) /* 10 megabytes = 10 * 1024 * 1024KB */
#define MAX_BUFLEN (256)  /* the max length of the input line buffer */
#define DEFAULT_ARRAY_LEN       (1 * 1024)  /* 1024 = 1K CELLS */
#define DEFAULT_SHORT_ARRAY_LEN (1 * 12)  
#define DEFAULT_COLWIDTH  72 /* the default terminal width */
#define DEFAULT_WINHEIGHT 42 /* the default terminal width */
#define DIGHT_WIDTH_INT   8 /* the default length of printing integers */
#define DIGHT_WIDTH_BOOL  2 /* the default length of printing booleans */
//#define IOBUFSIZE      1024
#define IOBUFSIZE         128

/*
 * Printing
 */
#define MAX_PRINT 100 
   /* the maximum number of elements in an array/list to be printed */

/*
 * Timing routines: 
 * from Sedgiwick's tertially quick sort program
 */
#define DMOD(x,y)  (x - () (x/y))
#define OSTREAM    stdout
#define TASK(str)  debug_printf((str)); debug_printf("\n");
#define CIN        g_starttime = clock();
#define COUT       {g_time = clock() - g_starttime; printf("@time:" "\t%10.6f sec   \t%10d min\n", ((double) (clock() - g_starttime))/CLK_TCK, (int) ((clock() - g_starttime)/CLK_TCK)/60);};
/* Note: The line end continuation by the backslash may not work with gcc on Sparc and DigitalUnix. */
#define NL         debug_printf("\n");
#define SET_REPEAT(count)	({g_rept = count;})
#define REPEAT(s)    for (g_rptctr=0; g_rptctr<g_rept; g_rptctr++) { s }; 
#define T_SEC       ((double) g_time/CLK_TCK)
#define T_CLOCK       ((double) g_time)

/******************************************************************
 * Types
 ******************************************************************/

/*
 * generic type: for ap-varray.c and ap-vlist.c
 */
typedef void *V;

/*
 * Boolean 
 */
typedef int Bool; 


/******************************************************************
 * Functions
 ******************************************************************/

/* replacement for ERREXIT */
#define ON  (1)
#define OFF (0)

extern void error_exit(char *fmt, ...); 
extern void debug_init(void); 
extern void debug_on(void); 
extern void debug_off(void); 
extern int  is_debug(void);
extern int  debug_get(void); 
extern void debug_push(int newval); 
extern int debug_pop(void); 
extern void debug(char *fmt, ...); 
extern void debug_printf(char *fmt, ...); 
extern int  debug_report(void); 
extern void print_nl(void); 
extern void print_nchar(int n, char c); 

extern int ap_expansion_length(int len); 
extern int ap_util_decimal_length(int x); 
extern int ap_numdigit(int x);  /* replacement of ap...length */

extern int mem_test(int max); 

/*
 * Timing routines from Sedgiwick's tertially quick sort program
 */

//aritmetics
#ifndef min
#define min(a, b) ((a)<=(b) ? (a) : (b))
#endif
#ifndef max
#define max(a, b) ((a)>(b) ? (a) : (b))
#endif

#endif

