/* 
 * awap-docset.c 6 June 99, by arim@i.kyushu-u.ac.jp.
 * -- text index module for awap.c
 */


#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <limits.h>
#include <math.h>
#include <assert.h>

#include "awap.h"
#include "ap-util.h"
#include "ap-iarray.h"
#include "ap-carray.h"
#include "awap-docset.h"
#include "awap-array.h"
#include "awap-poslist.h"
#include "awap-visit-func.h"

//Global Variables

#undef DEBUG_ARRAY
#undef DEBUG_INFILE
#undef DEBUG_CAT
#undef DEBUG_SUBSTR
#undef DEBUG_DELIM

static int Debug = 0; 


/****************************************
 * Global definitions
 ****************************************/

/****************************************
 * Allocation
 ****************************************/

extern void ds_init_sep_list(DocSet docset);

/** Create a new document set.
	@param none
	@retern a new DocSet object
	@author arim@ist.hokudai.ac.jp
 */
DocSet ds_alloc()
{
  DocSet docset; 
  docset = (struct _DocSet *) malloc(sizeof(struct _DocSet));
  if (docset == NULL)
    error_exit("ds_alloc: cannot allocate memory!\n");

  docset->Text_buf= ca_alloc(); //Extensible input text buffer
  docset->A_buf   = ia_alloc(); //Extensible input buffer
  docset->Doc_buf = ia_alloc(); //Extensible input buffer
  docset->Cat_buf = ca_alloc(); //Extensible input buffer
  docset->Num_buf = ia_alloc(); //Extensible input buffer

  docset->Text = NULL; // Input Text. (Text[0 .. N-1])
  docset->A    = NULL; // Indexing point. (A[0 .. n-1])
  docset->Sary = NULL; // Suffix array of A.         (rank -> position)
  docset->Prm  = NULL; // Inverse function of Saray. (position -> rank)
  docset->Hgt  = NULL; // Height array.              (rank -> height)
  docset->Doc  = NULL; // Documents numbers.   (position -> doc number)
  docset->ObjC = NULL; // Objective Condition.   (doc number -> {0, 1})

  docset->maxTextLen = 0; 
  docset->maxListLen = 0; 
  docset->TextLen = 0;	//the length of the text array Text
  docset->Num     = 0;	//the length of the index arrays A, Sary, Prm, Hgt, Doc, ObjC
  docset->Posnum  = 0;	//the number of positive documents
  docset->Negnum  = 0;	//the number of negative documents
  docset->MaxML   = 0;	//the maximum length of branching words
  docset->AveML   = 0;	//the average length of branching words

  docset->word_sep_list = cht_alloc(); //the character table for word delimitors.
  docset->sent_sep_list = cht_alloc(); //the character table for word delimitors.
  ds_init_sep_list(docset);

  //the function pointer to a letter conversion function
  docset->char_convert_func = ds_convert_downcase_char; 

  return docset;
}


/** Delete a document set. 
	@param docset
	@retern none
	@author arim@ist.hokudai.ac.jp
 */
void ds_free(DocSet docset)
{
  free(docset->Text);
  free(docset->A);
  free(docset->Sary);
  free(docset->Prm);
  free(docset->Hgt);
  free(docset->Doc);
  free(docset->ObjC);
  free(docset);
}


#define EOL_CHAR ('\127') //dammy
//char g_basic_sent_sep_list[] = { EOL_CHAR };
//char g_basic_word_sep_list[] = { DOC_SEP, ' ', EOL_CHAR };

char g_basic_sent_sep_list[] =
  { ',', ':', ';', '.', '?', '!', '\"','|', 
	'(', ')', '[', ']', '{', '}', '<', '>', EOL_CHAR };
char g_basic_word_sep_list[] = { DOC_SEP, ' ', '-', '\'', EOL_CHAR };

void _ds_insert_all_seps(Chtable cht, char *t) {
  while (*t != EOL_CHAR) {
	assert(*t >= 0);
	cht_put(cht, *t, 1);
	t++;
  }
}  

void ds_init_sep_list(DocSet docset) {
  //insert sent_seps
  _ds_insert_all_seps(docset->sent_sep_list, g_basic_sent_sep_list);

  //insert word_seps
  //note: word_sep_list should be a superset of sent_sep_list.
  _ds_insert_all_seps(docset->word_sep_list, g_basic_word_sep_list);
  _ds_insert_all_seps(docset->word_sep_list, g_basic_sent_sep_list);
}

int ds_is_word_sep(DocSet docset, char c) {
  return cht_get(docset->word_sep_list, c); 
}

int ds_is_sent_sep(DocSet docset, char c) {
  return cht_get(docset->sent_sep_list, c); 
}

/************************************************
 * the function pointer to a letter conversion function
 ************************************************/

/** Convert an original letter to its internal code */
char ds_convert_no_conversion(char c) {
  char ch; 
  if (c == EOF || c == '\n' || c == '\r')
	ch = DOC_SEP;
  else 
	ch = c;
  return(ch);
}

/** Convert an original letter to its internal code */
char ds_convert_downcase_char(char c) {
  char ch; 
  if (c == EOF || c == '\n' || c == '\r')
	ch = DOC_SEP;
  else if (isdigit(c))
	ch = c;
  else if (isalpha(c))
	ch = tolower(c);
  else
	ch = c;
  return(ch);
}


/************************************************
 * Reading Text 
 ************************************************/

/** Reading a text file into an existing document set.

	@param docset, file name, pointer to the number of documents (returned)
	@retern none
	@author arim@ist.hokudai.ac.jp
 */
void ds_read_file(DocSet docset, char *infile, char cat_id)
{
  FILE *fp;
  Charray  Text_buf= docset->Text_buf;
  Intarray A_buf   = docset->A_buf;
  Intarray Doc_buf = docset->Doc_buf;
  char ch, last;
  char (* char_convert_func)(char c);

  //set function pointer
  char_convert_func = docset->char_convert_func;

  int  doc_id = ca_tail_index(docset->Cat_buf);
#ifdef DEBUG_CAT
  if (doc_id != ca_tail_index(docset->Cat_buf))
	error_exit("doc_id != ca_tail_index(docset->Cat_buf): %d %d\n",
			   doc_id, ca_tail_index(docset->Cat_buf));
  assert(doc_id == ca_tail_index(docset->Cat_buf));
#endif

  if ((fp = fopen(infile, "r")) == NULL)
    error_exit("read_text: cannot open input file: %s\n", infile);

  last = DOC_SEP; 
  while (TRUE) {

	char _c = getc(fp); //read the original letter
	ch = char_convert_func(_c); //the letter to be inserted
	ca_push_back(Text_buf, ch);

	//update doc_id
    if (last == DOC_SEP && ch != DOC_SEP) {
	  doc_id++;
	  ca_push_back(docset->Cat_buf, cat_id);
#ifdef DEBUG_CAT
	  if (doc_id != ca_tail_index(docset->Cat_buf))
		error_exit("doc_id != ca_tail_index(docset->Cat_buf): %d %d\n",
				   doc_id, ca_tail_index(docset->Cat_buf));
	  assert(doc_id == ca_tail_index(docset->Cat_buf));
#endif
    }

	//word Index: A, Doc
    if (ds_is_word_sep(docset, last) &&
		!ds_is_word_sep(docset, ch) ) {
	  ia_push_back(A_buf, ca_tail_index(Text_buf));
	  ia_push_back(Doc_buf, doc_id);
    }

	//Sent: replace SENT_SEP with DOC_SEP
    if (ds_is_sent_sep(docset, ch)) {
	  int i0 = ca_tail_index(Text_buf); //the last sent_sep
	  Text_buf->val[i0] = DOC_SEP;
    }

	last = ch;
	if (_c == EOF)
	  break;
  }
  close(fp);  

  //terminate a file by DOC_SEP
  if (ca_tail_index(Text_buf) != DOC_SEP) {
	ca_push_back(Text_buf, DOC_SEP);
  }

}

void ds_read_files(DocSet docset, Intarray infiles, char cat_id) {
  int last_doc_id = ca_tail_index(docset->Cat_buf);
  int i;
  for (i = 0; i < infiles->len; i++) {
	char *infile = (char *)ia_get(infiles, i);
	ds_read_file(docset, infile, cat_id); 
  }

  //set the total number of documents inserted in this cat_id
  int _doc_id = ca_tail_index(docset->Cat_buf);
  int num_doc = _doc_id - last_doc_id;
  ia_put(docset->Num_buf, cat_id, (_doc_id - last_doc_id));
#ifdef DEBUG_ARRAY
  printf("ds_read_files: num_doc=%d\tNum_buf[%d]=%d\n",
		 num_doc, cat_id, ia_get(docset->Num_buf, cat_id));
#endif
}

/** Printing all sentences one at a line starting with its doc_ids 
 */
void ds_print_text(DocSet docset, FILE *fp) {
  char ch;
  int doc_id, last_doc_id;
  int i = 0; //array index
  int n = 0; //text index
  for (i = 0; i < docset->A_buf->len; i++) {
	int p = docset->A_buf->val[i];
	doc_id = docset->Doc_buf->val[i];
	while (n < p) {
	  ch = docset->Text_buf->val[n];
	  if (ch == DOC_SEP) {
		fprintf(fp, "\n%d:", doc_id);
	  }
	  else 
		putc(ch, fp);
	  n++;
	}
	last_doc_id = doc_id;
  }
}

void ds_print_text0(Charray ta, FILE *fp) {
  int i;
  for (i = 0; i < ta->len; i++)
    putc(ta->val[i], fp);
}

#define DS_ALLOC_ARRAY(ARRAY, TYPE, LEN, MSG) \
  if ((ARRAY = (TYPE *) calloc(LEN, sizeof(TYPE))) == NULL) error_exit((MSG))

int ds_count_up(DocSet docset) {
  ;
}

///helper routine
void ds_alloc_arrays(DocSet docset) {
  //Text
  docset->TextLen    = docset->Text_buf->len;
  docset->maxTextLen = docset->Text_buf->maxlen;
  docset->Text       = docset->Text_buf->val;
  assert(docset->Text[docset->TextLen - 1] == DOC_SEP);

  //Arrays
  int len = docset->Num = docset->A_buf->len; 
  docset->maxListLen = docset->A_buf->maxlen;
  DS_ALLOC_ARRAY(docset->Sary,int, len, "Sary: cannot allocate memory!\n");
  DS_ALLOC_ARRAY(docset->Prm, int, len, "Prm : cannot allocate memory!\n");
  DS_ALLOC_ARRAY(docset->Hgt, int, len, "Hgt : cannot allocate memory!\n");

  docset->A   = docset->A_buf->val;
  docset->Doc = docset->Doc_buf->val;
  docset->ObjC= docset->Cat_buf->val;
  assert(docset->Num == docset->A_buf->len);
  assert(docset->Num == docset->Doc_buf->len);
  docset->Posnum = ia_get(docset->Num_buf, DS_CATID_POS);
  docset->Negnum = ia_get(docset->Num_buf, DS_CATID_NEG);
}

void ds_print(DocSet docset, FILE *fp) {
  fprintf(fp, "ds: #%d \n", docset);
  if (docset == NULL) return;
  fprintf(fp, "  TextLen:%d\n", docset->TextLen);
  fprintf(fp, "  Num\t: %d\n", docset->Num);
  fprintf(fp, "  Posnum: %d\n",docset->Posnum);
  fprintf(fp, "  Negnum: %d\n",docset->Negnum);
  fprintf(fp, "  Text\t: #%d\t%d\n", docset->Text, docset->TextLen);
  fprintf(fp, "  A\t: #%d\t%d\n", docset->A, docset->Num);
  fprintf(fp, "  Doc\t: #%d\t%d\n", docset->Doc, docset->Num);
  fprintf(fp, "  ObjC\t: #%d\t%d\n",docset->ObjC, docset->Cat_buf->len);
  fprintf(fp, "  Sary\t: #%d\t%d\n",docset->Sary, docset->Num);
  fprintf(fp, "  Prm\t: #%d\t%d\n", docset->Prm, docset->Num);
  fprintf(fp, "  Hgt\t: #%d\t%d\n", docset->Hgt, docset->Num);
  //fprintf(fp, "  Num_buf:#%d\t%d\n",docset->Num_buf, docset->Num_buf->len);
}


void _debug_print_array(int *A, int len) {
  int i;
  for (i = 0; i < len; i++) {
	int value = A[i];
	printf("%d ", value);
  }
  putchar('\n');
}

/** Building a set of arrays for a document set. 
	@param docset
	@retern none
	@author arim@ist.hokudai.ac.jp
 */
void ds_makeindex(DocSet docset, Query query)
{
  //debug_on();
  TASK("Making A array")
#ifdef DEBUG_ARRAY
  _debug_print_array(docset->A, docset->Num);
#endif

  /*******************************
   * Sary
   *******************************/

  TASK("Making Sary")
  int i;
  for (i = 0; i < docset->Num; i++)
    docset->Sary[i] = i;
  sort_init(); 
  ssort2main(docset->Text, docset->A, docset->Sary,
	     docset->Num);
#ifdef DEBUG_ARRAY
  _debug_print_array(docset->Sary, docset->Num);
#endif

  /*******************************
   * Prm
   *******************************/

  TASK("Making Prm") 
  make_Prm(docset->Sary, docset->Prm, docset->Num);
#ifdef DEBUG_ARRAY
  _debug_print_array(docset->Prm, docset->Num);
#endif

  /*******************************
   * Hgt
   *******************************/

  TASK("Making Hgt")
  int (*lcp_func)(int p, int q, char *Text);
  if (IS_FLAG_ON(query, FLAG_WORD_MODE))
	lcp_func = lcp_word;
  else 
	lcp_func = lcp_letter;
  make_Hgt_Simple_Func(docset->Text, docset->A, docset->Sary,
		  docset->Hgt, docset->Num, docset->TextLen, lcp_func); 
#ifdef DEBUG_ARRAY
  _debug_print_array(docset->Hgt, docset->Num);
#endif

  //make_Hgt_Liner(docset->Text, docset->A, docset->Sary,
  //docset->Prm, docset->Hgt, docset->Num);

  /*******************************
   * AML
   *******************************/

  TASK("Making AML") 
  // counting AML, MaxML in Hgt and Sary
  count_matchlength(docset); 

  return;
}

/** Constructing a new document set from a pair of positive and
	negative files. A wrapper routine for awap-docset.c 

	@param docset an existing empty document set
	@param posfile positive file name
	@param negfile negative file name

	@retern none
	@author arim@ist.hokudai.ac.jp
	@version 0.0.1
 */
void ds_build(DocSet docset, Query query, Intarray posfiles, Intarray negfiles)
{
  //Reading Text
  ds_read_files(docset, posfiles, DS_CATID_POS);
  ds_read_files(docset, negfiles, DS_CATID_NEG);

  // Memory Allocation
  if (Debug) printf("alloc_arrays\n");
  ds_count_up(docset);
  ds_alloc_arrays(docset); 

#ifdef DEBUG_ARRAY
  ds_print(docset, stdout);
#endif

  // Computing Text Index
  if (Debug) printf("makeindex\n");
  ds_makeindex(docset, query);

}


/* Given idx on A array, return a read-only string for the unique
 * document containing idx in its text.
 */
char *ds_get_a_document(DocSet docset, int idx,
						int *len_ptr, int *orig_ptr, int *doc_ptr) {
	return get_a_document(docset->Text, docset->A, docset->Sary,
						  docset->Doc,
						  docset->TextLen, docset->Num, idx,
						  len_ptr, orig_ptr, doc_ptr);
}

void ds_print_a_document(DocSet docset, int idx) {
	int len, offset, doc_id;

	char *str = ds_get_a_document(docset, idx, &len, &offset, &doc_id); 
	sentence_beg(stdout); 
	printf("@doc %d %d [%.*s]\n", doc_id, offset, len, str);
	sentence_end(stdout); 
}

void ds_print_documents(DocSet docset, PosList list) {
	int i;
	int len, offset, docid;
	
	if (list == NULL) {
		printf("empty list!\n");
		return;
	}

	printf("printing %d docs\n", list->len); 
	for (i = 0; i < list->len; i++) {
		int idx = list->val[i];
		char *str = ds_get_a_document(docset, idx, &len, &offset, &docid);

		sentence_beg(stdout); 
		printf("@doc %3d %5d %3d %4d %6d [%.*s]\n",
			   i, docid, offset, len, idx, 
			   len, str);
		sentence_end(stdout); 
	}
}

/** Conversion from a pair (L,H) to the substring of Text
 */
void ds_retrieve_substr(DocSet docset, Charray ca, int L, int H) {
  int i; 

  assert(ca != NULL);
  ca_make_null(ca);
  int pos = docset->A[docset->Sary[L]];
  char *s = docset->Text + pos; 

#ifdef DEBUG_SUBSTR
  int len = min(H, docset->Textlen - pos);
  printf("#docset: H=%d", H);
  printf("\t[%.*s]\n", H, s);
#endif

  for (i = 0; i < H; i++) {
	ca_push_back(ca, *s++);
  }
}

/** A wrapper: Conversion from a pair (L,H) to the substring of Text
 */
Charray ds_get_substr(DocSet docset, int L, int H) {
  Charray ca = ca_alloc();
  ds_retrieve_substr(docset, ca, L, H);
  return ca;
}

void ds_print_suffices(DocSet docset, Query query, FILE *fp) {
  Charray ca = ca_alloc();
  int L;
  for (L = 0; L < docset->Num - 1; L++) {
	int H = docset->Hgt[L];
	ds_retrieve_substr(docset, ca, L, H);
	fprintf(fp, "%d:%d:", L, H);
	if (IS_FLAG_ON(query, FLAG_PRINT_PATTERN_DEBUG)) 
	  fprintf(fp, "\"%.*s\"\n", ca->len, ca->val);
	else 
	  fprintf(fp, "%.*s\n", ca->len, ca->val);
  }
}


int ds_get_docid (DocSet docset, int i) {
  assert(i < docset->Num);
  int x = docset->Sary[i];
  return docset->Doc[x];
}

int ds_get_textpos(DocSet docset, int i) {
  assert(i < docset->Num);
  return docset->A[i];
}

/* EOF */
