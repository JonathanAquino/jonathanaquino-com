/* 
 * awap-textindex.c 06SEP2005 by arim@i.kyushu-u.ac.jp.
 * -- text index module for awap.c
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

//#include "awap.h"
#include "ap-util.h"
#include "ap-iarray.h"
#include "ap-carray.h"
//#include "talk.h"

/** Reading a text file into an existing document set.
@param docset, file name, pointer to the number of documents (returned)
@retern none
@author arim@ist.hokudai.ac.jp
*/

//#define DEBUG_FILE
#undef DEBUG_FILE

int ia_last_index(IntArray ia) {
	return ia->len - 1;
}

int ca_last_index(ChaArray ca) {
	return ca->len - 1;
}

int is_space_char(char c) {
	if (c == ' ') return TRUE;
	if (c == '\t') return TRUE;
	if (c == '\n') return TRUE;
	if (c == '\r') return TRUE;
	if (c == EXT_DOC_DELIM) return TRUE;
	return FALSE;
}

int is_token_char(char c) {
	return !((c == ' ')
			 || (c == '\t')
			 || (c == '\r')
			 || (c == EOF)
			 || (c == EXT_DOC_DELIM));
}

void ds_read_text(DocSet docset, char *infile, int catid)
{
	FILE *fp;
	int len = docset->len;
	char cur;
	char out_char;
#ifdef DEBUG_FILE
	int num_index = 0;
#endif
	int numdoc = 0;

	ChaArray tbuf = ca_alloc(); //buffer for Txt array
	IntArray ibuf = ia_alloc(); //buffer for Ind array
	IntArray dbuf = ia_alloc(); //buffer for Doc array
	IntArray cbuf = ia_alloc(); //buffer for Cat array

#ifdef DEBUG_FILE
		printf("tx_read_text: open file\n");
#endif

	if ((fp = fopen(infile, "r")) == NULL)
		errexit("read_text: Can't open input posfile");

#ifdef DEBUG_FILE
	printf("tx_read_text: start reading... %s\n", infile);
#endif

	int docid = docset->posdoc + docset->negdoc; 
	int last = EXT_DOC_DELIM;

	while ((cur = getc(fp)) != EOF) {

		//document delimitor
		if (cur == EXT_DOC_DELIM) {
			out_char = INT_EOD;
			docid++;
			if (catid == CAT_POS)
				docset->posdoc++;
			else if (catid == CAT_NEG)
				docset->negdoc++;
			else
				errexit("tx_read_file: no such catid: %d\n", catid);
		}
		//word delimitor
		else if (is_space_char(cur)) {
			out_char = INT_EOW;
		}
		//non-space char
		else if (is_token_char(cur)) {
			//letter
			if (isalpha(cur)) {
				out_char = tolower(cur);
			}
			//digit
			else if (isdigit(cur)) {
				out_char = cur;
			}
			//
			else {
				out_char = cur;
			}
			//ia_add(ibuf, ca_last_index(tbuf));
		}
		else {
			;
		}
#ifdef DEBUG_FILE		
		printf("[%d] istoken=%d isspace=%d\n",
			   cur, is_token_char(cur), is_space_char(cur));
#endif 
		//update index push current index
		ca_add(tbuf, out_char);
		if (is_space_char(last) && is_token_char(cur)) {
			ia_add(ibuf, ca_last_index(tbuf));
			ia_add(dbuf, docid);
			ia_add(cbuf, catid);
#ifdef DEBUG_FILE
			printf("@index[%d]\n", ia_last_index(ibuf));
			num_index++;
#endif
		}
		last = cur;
	}
	//add EOF
	ca_add(tbuf, out_char);
	last = cur;

	//set docset
	assert(ibuf->len == dbuf->len);
	assert(ibuf->len == cbuf->len);

	ca_append(docset->ta, tbuf);
	ia_append(docset->ia, ibuf);
	ia_append(docset->da, dbuf);
	ia_append(docset->ca, cbuf);

#ifdef DEBUG_FILE
	printf("tx_read_text: end reading: ibuf=%d, dbuf=%d, cbuf=%d\n",
		   ibuf->len, dbuf->len, cbuf->len);
#endif
	//note: to update docset->posdoc or docset->negdoc outside

	//Clear memory
	ca_free(tbuf); 
	ia_free(ibuf); 
	ia_free(dbuf); 
	ia_free(cbuf); 
	close(fp);  
#ifdef DEBUG_FILE
		printf("tx_read_text: close file\n");
#endif
}

char *tx_normalized_char_str(char c) {
	char buf[MAXWORD];
	char *d;
	if (c == INT_EOW)
		d = " ";
	else if (c == INT_EOD)
		d = "[EOD]";
	else if (c == '\n')
		d = "\\n";
	else if (c == '\r')
		d = "\\r";
	else if (c == '\t')
		d = "\\t";
	else if (c == INT_EOF)
		d = "[EOF]";
	else {
		buf[0] = c;
		buf[1] = '\0';
		d = buf;
	}
	return d;
}

void tx_print_suffix(DocSet docset, int idx, int maxlen) {
	char c;
	int p, len;
	if (idx >= docset->len)
		return;
	printf("[BEG]");
	p = docset->Idx[idx];
	len = 0;
	while (((c = docset->Txt[p]) != INT_EOD) && (c != INT_EOF)) {
		if (len >= maxlen)
			break;
		printf("%s", tx_normalized_char_str(c));		
		p++;
		len++;
	}
	printf("%s", tx_normalized_char_str(c));		
	printf("\n");
}

void tx_print_text(DocSet docset) {
	char c;
	int p;
	int idx;
	p = 0;
	while ((c != INT_EOF)) {
		while (((c = docset->Txt[p]) != INT_EOD) && (c != INT_EOF)) {
			if (p >= docset->len)
				return;
			printf("%s", tx_normalized_char_str(c));		
			p++; 
		}
		printf("%s", tx_normalized_char_str(c));		
		printf("\n");
	}
}




