#ifndef ___eval___
#define ___eval___ 

/* 
 * awap-eval.h
 */

#include "awap-ctable.h"
#include "awap-query.h"

/* // Contingency table (oldname: PN) */
/* typedef struct _ctable { */

/*     int P0, P1, N0, N1; */

/* } *ContigTable; */

#define FUNC_ENTROPY  (0)
#define FUNC_BINERR   (1)
#define FUNC_GINIIDX  (2)
#define FUNC_SC       (3)
#define FUNC_INVFREQ  (4)
#define MAX_FUNC      (5)

#define COMPUTE_MEASURE(measure, Query, CTABLE)  \
{ if (Query->eval == FUNC_BINERR)                \
    measure = minimum_class_err(CTABLE);         \
  else if (Query->eval == FUNC_ENTROPY)          \
    measure = minimum_entropy(CTABLE);           \
  else if (Query->eval == FUNC_GINIIDX)          \
    measure = minimum_gini(CTABLE);              \
  else if (Query->eval == FUNC_INVFREQ)          \
    measure = minimum_invfreq(CTABLE);           \
  else if (Query->eval == FUNC_SC)          \
    measure = minimum_sc(CTABLE);           \
  else  ERREXIT("discover: no such eval\n"); }    


//Forward declaration
extern int eval_get_eid(char *name); 
extern double eval_compute(QUERY *Query, Ctable CTABLE); 

double minimum_class_err(Ctable);
double minimum_entropy(Ctable);
double minimum_gini(Ctable);
double minimum_invfreq(Ctable);  
double minimum_sc(Ctable); 


#endif 

