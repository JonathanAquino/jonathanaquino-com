#ifndef ___ishell___
#define ___ishell___

/* 
 * awap-templ.h -- template for awap programs
 * Global definitions
 * - created by arim@i (03 SEP 2005)
 */

#include "awap.h"

/*
 * Macros
 */

#define MAXARGS (256)

/*
 * Types 
 */ 

/*
 * Externs: functions and global varialbles 
 */ 

extern char *g_linebuf; 

extern char *is_parse_line(int  *argc_ptr, char *argv[]); 

extern void is_print_args(int argc, char *argv[]); 

extern int is_cmd_match(char *cmd, char *keyword); 

extern char *is_get_line_buffer(); 

#endif 
