/* 
 * awap-init.c -- Initialization
 * (1/15/99)
 * 
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <limits.h>
#include <assert.h>

#include "awap.h"
#include "awap-docset.h"


#undef DEBUG_HGT
#undef DEBUG_SNT

void intcpy(int *A, int *B, int len) {
	int i;
	for(i = 0; i < len; i++) *A++ = *B++;
}

/*
 * Making Index Point Array
 */

// Count index points

int count_index_points(char *Text, int N, DocSet docset)
{// N = the length of the text array
	int num; //Num
	int i, j;
	char c;
	//printf("DEBUG: count_index_points: Text=%d, N=%d\n", Text, N);
  
	num = 0;
	i = 0;
	while (i<N) {
	  //if ((c = Text[i]) == ' ' || c == DOC_SEP) {
	  if (CHT_IS_CHAR_ON(docset->word_sep_list, Text[i])) {
			num++;
			i++;
			if (i >= N) {
				//printf("DEBUG: count_index_points: ABORT\n");
				return num;
			}
		} else {
			i++;
		}
	}
	//printf("DEBUG: count_index_points: NORMAL EXIT\n");
	return num;
}

// Make Text Ptr Array
void make_index_array(char *Text, int *A, int N, DocSet docset)
{
    int i, j;
    char c;

    j = 0;
    for (i = 0; i < N; i++) {
	  //Skip spaces
	  //while ((c = Text[i]) == ' ' || c == DOC_SEP || c == SNT_SEP) {
	  while (CHT_IS_CHAR_ON(docset->word_sep_list, Text[i])) {
		i++;
		if (i >= N) return;
	  }

	  //Now, a non-space character encountered
	  A[j++] = i;

	  //Skip non-spaces
	  //while (!((c = Text[i]) == ' ' || c == DOC_SEP || c == SNT_SEP)) {
	  while (!CHT_IS_CHAR_ON(docset->word_sep_list, Text[i])) {
		i++;
		if (i >= N) return;
	  }
    }
}

// Make Text Ptr Array
void org_make_index_array(char *Text, int *A, int N)
{
    int i, j;
    char c;

    j = 0;
    for (i = 0; i < N; i++) {
		//Skip spaces
		while ((c = Text[i]) == ' ' || c == DOC_SEP || c == SNT_SEP) {
			i++;
			if (i >= N) return;
		}

		//Now, a non-space character encountered
		A[j++] = i;

		//Skip non-spaces
		while (!((c = Text[i]) == ' ' || c == DOC_SEP || c == SNT_SEP)) {
			i++;
			if (i >= N) return;
		}
    }
}

//===============================================//
//                                                //
//          Doc, ObjC, Prm, Hgt (1/15/99)        //
//                                              //
//===============================================//

/*
 * Make Prm
 */
void make_Prm(int *Sary, int *Prm, int n)
{
    int i;
    for(i=0; i<n; i++)
		Prm[Sary[i]] = i;
}

char *get_a_document(char Text[], int A[], int Sary[],
					 int Doc[], int N, int n,
					 int idx,
					 int *len_ptr, int *orig_ptr, int *doc_ptr) {
	//The doc_id and position of the current index point idx.
	int doc = Doc[idx]; 
	int pos = A[idx];
	//int pos = Text[A[Sary[idx]]];
	char *s;
	char *str;
	int len = 0;

	if (pos < 0 || pos >= N) ERREXIT("get_a_document: wrong range!");
	//Seek the start of the document 
	s = Text + pos;
	while (*s != DOC_SEP && s > Text) {
		s--;
		len++; 
	}
	str = s + 1; //beginning of doc

	//Seek the end of the document
	s = Text + pos + 1; 
	while (*s != DOC_SEP && s < Text + N) {
		s++;
		len++; 
	}
	*len_ptr = len; //the length of the string
	*orig_ptr= Text + pos - str; //the index of origin (at pos) 
	*doc_ptr = doc; //the document id of the string
	return str;
}

/*
 * Make Hgt
 */

int _is_word_boundary(char c) {
  return (c == ' ' || c == DOC_SEP);
}

//extern int (*lcp)(int p, int q, char *Text)

/** A trimmed version of LCP function for word suffix arrays
 * based on O(n^2) time version of LCP implementation.
 */
int lcp_word(int p, int q, char *Text)
{
  int n = 0;
  int last = -1;
  while((Text[p] == Text[q]) ||
		(_is_word_boundary(Text[p]) && _is_word_boundary(Text[q]))) {
	if (_is_word_boundary(Text[p]) && _is_word_boundary(Text[q]))
	  last = n;
	if (Text[p] == DOC_SEP || Text[q] == DOC_SEP)
	  break;
	p++;
	q++; 
	n++;
  }
  return last + 1; //lcp length is the index last plus one
}

/** A standard LCP function for letter-based suffix arrays
 */
int lcp_letter(int p, int q, char *Text)
{
    int i = 0;
    while(Text[p]!= DOC_SEP && Text[p++] == Text[q++])
		i++;
    return i;
}

int lcp(int p, int q, char *Text) {
  lcp_letter(p, q, Text);
}

// Make Hgt: Simple Version
// note: lcpfunc is a function pointer (See K & R, 2nd ed, Sec 5.11, pp145).
void make_Hgt_Simple_Func(char *Text, int *A, int *Sary, int *Hgt, int n, int len,
						  int (*lcpfunc)(int p, int q, char *Text))
{
    int i;
    
    for(i = 0; i < n - 1; i++) {
	  Hgt[i] = lcpfunc(A[Sary[i]], A[Sary[i+1]], Text);
#ifdef DEBUG_HGT
	  printf("make_Hgt_Simple: %d: %d, %d => %d\n",
			 i, Sary[i], Sary[i+1], Hgt[i]);
#endif
	}
    Hgt[n-1] = -1;
}

// Dammy 
void make_Hgt_Simple(char *Text, int *A, int *Sary, int *Hgt, int n, int len)
{
  make_Hgt_Simple_Func(Text, A, Sary, Hgt, n, len, lcp_word);
}


// Make Hgt: Simple Version 
void org_make_Hgt_Simple(char *Text, int *A, int *Sary, int *Hgt, int n, int len)
{
    int i;
    
    for(i = 0; i < n - 1; i++) {
	  Hgt[i] = lcp_letter(A[Sary[i]], A[Sary[i+1]], Text);
#ifdef DEBUG_HGT
	  printf("make_Hgt_Simple: %d: %d, %d => %d\n",
			 i, Sary[i], Sary[i+1], Hgt[i]);
#endif
	}
    Hgt[n-1] = -1;
}


// Make Hgt: Liner Version
void make_Hgt_Liner(char *Text, int *A, int *Sary, int *Prm, int *Hgt, int n)
{
    int p, q, i;
    int h;

    h = 0;
    for(p=0; p<n; p++) {
		if ((i = Prm[p]) == n-1)  continue;
		q = Sary[i+1];
		if (h > 0)
			Hgt[i] = h + lcp_letter(A[p]+h, A[q]+h, Text);
		else 
			Hgt[i] = lcp_letter(A[p], A[q], Text);
		h = Hgt[i] - (A[p+1]-A[p]);
    }
    Hgt[n-1] = -1;
}

// Make Hgt: Tuned Liner Version

void make_Hgt_Tuned_Liner(char *Text, int *A, int *Sary, int *Prm, int *Hgt, int n)
{
    int a, b, c, p, i; 

    b = 0;
    for(p=0; p<n; p++) {
		if(b < (a = A[p]))  b = a;
		if ((i=Prm[p]) == n-1)  continue;
		c = A[Sary[i+1]]+ b-a;
		while(Text[b] != DOC_SEP && Text[b] == Text[c]) {
			b++; c++;
		}
		Hgt[i] = b-a;
    }
    Hgt[n-1] = -1;
}

/* utility */

void count_matchlength(DocSet docset) {
	int sum = 0;
	int max = 0;
	int i; 
	for(i = 0; i < docset->Num - 1; i++) {
		sum = sum + docset->Hgt[i];
		if (max < docset->Hgt[i]) max = docset->Hgt[i];
	}
	docset->MaxML = max; 
	docset->AveML = sum / (docset->Num - 1);

	//fprintf(stdout,"@size sarray %5.1f %5.1f (ave_and_max_in_bytes)\n",
	//(double) aml, (double) MaxML);
}

void ERREXIT(char *message)
{
    fprintf(stderr, "ERR: %s\n", message);
    fprintf(stderr, "##END \n"); //for GUI version
    fflush(stderr);
    exit(1);
}

/*
 * 
 */

/* EOF */
