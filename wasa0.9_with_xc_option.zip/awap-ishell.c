/* 
 * awap-ishell.h -- a collection of helper routines for an interactive shell 
 * - modified based on awap-pat.c on 30 JUL 2005 by arim@ist
 * - created by arim@i (03 SEP 2005)
 */

#include "awap.h"
#include "talk.h"

/*
 * Global definitions
 */

char g_linebuf[LINEBUFLEN]; 

#undef DEBUG_SHELL	

/*
 * Main 
 */

char *is_get_line_buffer() {
	g_linebuf[LINEBUFLEN - 1] = '\0'; //for safity
	return g_linebuf; 
}

//extern int _is_parse_args(char *line, int *argc_ptr, char *shell_argv[]); 

int _is_parse_args(char *line, int *argc_ptr, char *shell_argv[]) {
	static char _argbuf[LINEBUFLEN]; 
	char *abuf = _argbuf;
	char last = '\0';
	int  n = 0;

#ifdef DEBUG_SHELL	
	printf("@debug line=[%s]\n", line);
#endif

	while (TRUE) {
		char c = *line;
#ifdef DEBUG_SHELL	
		printf("(%c)", c);
#endif

		if ((c == ' ' || c == '\0')) {
			if (c != last) {
				//Push the current word
				*abuf = '\0'; //terminate the arg buffer by null char.
				abuf = _argbuf; //goto the beginning
				if (strlen(abuf) == 0)
					break; 
				shell_argv[n++] = strdup(abuf); //create a new copy

#ifdef DEBUG_SHELL	
				printf("@debug [%s] \n", abuf);
#endif
				//reflesh abuf
				abuf = _argbuf;
				*abuf = '\0'; 
			}
		}
		else {
			*abuf = c;
			abuf++;
		}

		if (c == '\0')
			break; //while

		last = c;
		line++;
	}// while
#ifdef DEBUG_SHELL	
	printf("\n");
#endif
	*argc_ptr = n;
	return *argc_ptr;
}


char *is_parse_line(int  *argc_ptr, char *argv[]) {
	char *val = get_line(g_linebuf);
	_is_parse_args(g_linebuf, argc_ptr, argv);
	return val; 
}

void is_print_args(int argc, char *argv[]) {
	int i;
	printf("argc=%d argv:", argc);
	for (i = 0; i < argc; i++) 
	  printf("[%s] ", argv[i]);
	printf("\n");
}

int is_cmd_match(char *cmd, char *keyword) {
	int len;
	len = strlen(keyword);
	return (strncmp(cmd, keyword, len) == 0);
}

/* EOF */

