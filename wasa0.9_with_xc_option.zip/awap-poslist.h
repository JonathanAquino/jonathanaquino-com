#ifndef ___poslist___
#define ___poslist___ 

// Contingency table (oldname: PN)
typedef struct _poslist {
    int maxlen;	//allocated length
    int len;    //the current length of contents
	int *val;   //the containt array of integers
} *PosList;

extern PosList poslist_create(int maxlen); 
extern PosList polist_gen(int *ia, int len); 
extern void polist_print(PosList list);

#endif 

