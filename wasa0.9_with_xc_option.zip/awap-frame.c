
#include <stdlib.h>
#include "awap-stack.h"

static int Flag_frameinit = 0;

//Global
int *Nary;    //Integer List sorted by QSort

int MaxDepth; //[1..MaxDepth]


//===============================================//
// ELEMENT 
//===============================================//

/* return new element */
Element element_create() {
	Element tmp = NULL;
	if ((tmp = (Element ) malloc(sizeof(struct _element))) == NULL)
		ERREXIT("error: elem_create: cannot allocate memory!\n");
	tmp->left = -1;
	tmp->hgt  = -1;
}

//#define MAKENULL(s) {(s).top = -1;}
//#define TOP(s) (&((s).element[(s).top]))
//#define POP(s) {(s).top--;}
//#define PUSH(s, e) {(s).element[++((s).top)] = e;}

Element stack_top(STACK s) {
	int index = s.top;
	return &(s.element[index]); 
}

void stack_pop(STACK s) {
	s.top--;
}

// void stack_push(STACK s, ELEMENT e) {
// 	int index = ++(s.top); 
// 	s.element[index] = e;
// }

void stack_makenull(STACK s) {
	s.top = -1;
}


//===============================================//
// FRAME 
//===============================================//

Frame Frame_alloc(DocSet docset, int D, int k)
{
  //Initialization
  int i;
  if (Flag_frameinit == 0) {
    for(i = 1; i <= D; i++) { //Note: Ranges [1..D]
      SF[i].Stack.element = (Element )0;
    }
    Flag_frameinit = 1;
  }
  //Stack frame
  for(i = 1; i <= D; i++) {  //Note: Ranges [1..D]
    if ((SF[i].Stack.element
	 = calloc((docset->MaxML+2), sizeof(Element ))) == NULL)
      ERREXIT("SAFE_REALLOC: Can't allocate memory");
    if ((SF[i].Sary
	 = calloc(docset->Num+1, sizeof(int *))) == NULL)
      ERREXIT("SAFE_REALLOC: Can't allocate memory");
    if ((SF[i].Hgt
	 = calloc(docset->Num+1, sizeof(int *))) == NULL)
      ERREXIT("SAFE_REALLOC: Can't allocate memory");
  }
  //Array buffer
  if ((Nary  = calloc(docset->Num * k + 1, sizeof(int *))) == NULL)
    ERREXIT("SAFE_REALLOC: Can't allocate memory");

  return SF; 
}


void Frame_free(Frame SF, int D)
{
  int i;
  for(i = 1; i <= MaxDepth; i++) {
    free(SF[i].Stack.element);
    //if (SF[i].Sary != Sary) free(SF[i].Sary); //Error
    //if (SF[i].Hgt != Hgt)   free(SF[i].Hgt);  //Error
  }
  free(Nary);
}

