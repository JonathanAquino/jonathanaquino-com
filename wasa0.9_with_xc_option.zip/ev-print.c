/* ev-print.c 
 * - created by arim@ist (25JUL06)
 */

#include <assert.h>
#include "awap-patset.h"
#include "ev-print.h"

/****************************************
 * Global definitions
 ****************************************/

FILE *ev_open_outfile(char *outfile) {
  FILE *fp;
  if ((fp = fopen(outfile, "w")) == NULL) { 
	error_exit("ev_open_write_file: cannot open file: %s\n", outfile);
  }
  return fp;
}

void ev_close_outfile(FILE *fp) {
  fclose(fp);
}

/****************************************
 * Routines: 
 ****************************************/ 

void ev_print_polist_pat(int pid, Pattern pat, DocSet docset, FILE *fp) {
  assert(docset != NULL);
  assert(pat != NULL);
  int H = pat->H; //the length of the pattern 
  PosList list = pat->list;
  assert(list != NULL);
  int i;
  for (i = 0; i < list->len; i++) {
	int x = list->val[i]; //index position
	int lpos = ds_get_textpos(docset, x);
	int rpos = lpos + H - 1;
	int sid  = ds_get_docid(docset, x);
	fprintf(fp, "%d:%d:%d:%d \n", pid, sid, lpos, rpos);
  }
  //fprintf(fp, "\n");
}


void ev_print_eventset(PatSet patset, FILE *fp)
{

  int D, pid; 
  int pnum = -1, nnum = -1;
  int i; 
  Pattern pat;

  pattern_print_axis(patset->query);

  pid = 0; 
  pat = patset_iter_begin(patset);
  while (pat != NULL) {
	if (pid > MAX_OUT_PATTERN || pid >= patset->num)
	  error_exit("output_patset: LIM_OUTPUT reached!\n");
	assert(pat != NULL);
	PosList list = pat->list;
	assert(list != NULL);
	//pattern_print(pat, pid, patset->query);
#ifdef DEBUG_EVENT	
	printf("%d %d\n", pid, list);
	//polist_print(list);
#endif
	ev_print_polist_pat(pid, pat, patset->docset, fp);
	pat = pat->next;
	pid++; 
  }
} 

void ev_print_pattern(int pid, Pattern pat, DocSet docset, FILE *fp) {
	int pnum, nnum;
	static Charray ca = NULL;
	if (ca == NULL)
	  ca = ca_alloc();
	ds_retrieve_substr(docset, ca, pat->L, pat->H);
	fprintf(fp, "%d:\"%.*s\"\n", pid, ca->len, ca->val);
}



void ev_print_patset(PatSet patset, FILE *fp)
{

  int pid; 
  Pattern pat;

  pattern_print_axis(patset->query);

  pid = 0; 
  pat = patset_iter_begin(patset);
  while (pat != NULL) {
	if (pid > MAX_OUT_PATTERN || pid >= patset->num)
	  error_exit("output_patset: LIM_OUTPUT reached!\n");
	//myown print
	ev_print_pattern(pid, pat, patset->docset, fp);
	pat = pat->next;
	pid++; 
  }
}	

/****************************************
 * Routines: main
 ****************************************/ 

static char outfile[128];

char *ev_file_ext(char *name, char *ext) {
  strcpy(outfile, name); //copy
  strcat(outfile, "."); //cat
  strcat(outfile, ext); //cat
  return outfile;
}

void ev_print_dataset(PatSet patset, char *name) {
  assert(name != NULL);
  char *outfile;
  FILE *fp;
  //print a list of (pid, pattern string)
  outfile = ev_file_ext(name, EV_EXT_PAT);
  fp = ev_open_outfile(outfile);
  ev_print_patset(patset, fp);
  ev_close_outfile(fp);

  //print a list of events (pid, sid, lpos, rpos))
  outfile = ev_file_ext(name, EV_EXT_SEQ);
  fp = ev_open_outfile(outfile);
  ev_print_eventset(patset, fp);
  ev_close_outfile(fp);

  //print a list of (did, document string)
  outfile = ev_file_ext(name, EV_EXT_DOC);
  fp = ev_open_outfile(outfile);
  ds_print_text(patset->docset, fp);
  ev_close_outfile(fp);
}

/* EOF */

