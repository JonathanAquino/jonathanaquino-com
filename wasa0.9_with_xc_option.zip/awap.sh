#!/bin/bash 

#cmd="awap"
cmd="/home/arim/work/DEV/awap276c/awap276c/awap"
USAGE='jwap posfile negfile [maxpatts] [evalfunc] [sign]\n
OPTIONS\n
 maxp\t - a positive integer \n
 func\t - an integer in {1,2,3,4,5}. 1: class error 2:entropy, \n
     \t 3:gini index, 4:maxfreq, 5:sc (stochastic complexity)\n
 sign\t - a boolean +1 (pos) or -1 (neg) for selecting the dataset.'

#default parameters
dim=1
prox=1
eval=2	#ENTROPY
npat=120
#eval=5	#SC
sign="+1"

if [ $# -le 1 ]
then
    echo "Error: too few or many arguments."
    echo -e $USAGE;
    exit 1;
fi

# echo "arg1: $1"
# echo "arg2: $2"
# echo "arg3: $3"
# echo "arg4: $4"
# echo "arg5: $5"

if [ $# -ge 2 ]
then
    pos=$1;
    neg=$2;
fi

if [ $# -ge 3 ]
then
    npat=$3;
fi

if [ $# -ge 4 ] 
then 
    eval=$4; 
fi 

if [ $# -ge 5 ] 
then 
    sign=$5; 
fi 

shift
shift
shift
shift
shift

echo "pos=$pos"
echo "neg=$neg"
echo "npat=$npat"
echo "eval=$eval"
echo "sign=$sign"

#echo "comm $posfile $negfile $@"
posfile="$pos.euc"
negfile="$neg.euc"
nkf -e $pos > $posfile
nkf -e $neg > $negfile
# echo "nkf -e $pos > $posfile"
# echo "nkf -e $neg > $negfile"

#-e: escape is active 
#echo -e "set side $sign \nfind $dim $prox $eval $npat $@ \nend";
echo "$cmd -p $posfile -n $negfile -w -e  | perl hiragana.pl | nkf -s "
echo -e "set side $sign \nfind $dim $prox $eval $npat \nend" | $cmd -p $posfile -n $negfile -w -e  
#echo -e "set side $sign \nfind $dim $prox $eval $npat \nend" | $cmd -p $posfile -n $negfile -w -e  | perl hiragana.pl | nkf -s 
rm -f $posfile $negfile 