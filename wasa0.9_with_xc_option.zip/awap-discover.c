/* 
 * awap-discover.c -- Mining Words Association Patterns, 17 may 99.
 * v280: Simplified version for phrase discovery only
 * v5: minimum_{class_err,entroy,gini}() and list_opearation() is now same to v3.
 * v4: Bug is fixed. This is v1 without safe_calloc. safe.
 * v3: wrong version: safe_calloc may be wrong. May 1999 
 * v1: modified by arim, May 1999
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <limits.h>
#include <math.h>
#include <assert.h>

#include "awap.h"
#include "awap-docset.h"
#include "awap-stack.h"
#include "awap-pattern.h"
#include "awap-patset.h"
#include "awap-poslist.h"
#include "awap-chtable.h"

#define DEBUG_TRACE0
#undef DEBUG_TRACE
#undef DEBUG_WORDMODE

/****************************************
 * Global variables
 ****************************************/ 

/****************************************
 * Normalized subwords on a suffix array
 ****************************************/ 

#define	SET_NCA_NODE(L,H,I) { (L) = (I); (H) = Hgt[(I)]; }
#define SET_TOP_NODE(L,H,S) { L = TOP((S))->left; H = TOP((S))->hgt;}

IntPair get_parent_of_top(Stack S) {
  return &(S->val[S->top - 1]);
}

/** last_proper_index_point: 
 returns the length of the longest proper prefix of the given 
 subword ending with a proper indexing point if it exists, and
 returns zero if the substring contains no proper indexing point.
 */
int normalize_subword_height(Stack S, int *Sary, int L, int H, int Hnca,
							DocSet docset, Query query)
{
  int H_parent, H_tmp, pos;
  int H_new = 0;
  char c;

  //getting the parent of the current node
  if (S->top < 1)
    error_exit("last_proper_index_point: no parent node in the stack!\n");

  //H_parent = NEXTTOP(S)->hgt;
  H_parent = get_parent_of_top(S)->hgt;

  if (H_parent > Hnca)
    ;//do nothing
  else
    H_parent = Hnca;

  if (H_parent >= H)
	error_exit("last_proper_index_point: H_parent >= H: impossible!\n");

#define DIS_GET_CHAR(docset, pos, H_tmp) ((docset)->Text[(pos) + (H_tmp) - 1])
  
  //try to find a space on an edge from the current to the parent.
  pos = docset->A[Sary[L]];
  c = DIS_GET_CHAR(docset, pos, H_tmp);

  //move the pointer to the nearest word_sep
  while (!ds_is_word_sep(docset, c) && c != DOC_SEP) {
	H_tmp--;
	c = DIS_GET_CHAR(docset, pos, H_tmp);
	if (H_parent >= H_tmp) return 0;
  }

  while ((ds_is_word_sep(docset, c) || c == DOC_SEP)) {
	H_tmp--;
	c = DIS_GET_CHAR(docset, pos, H_tmp);
	if (H_parent >= H_tmp) return 0;
  }
  return H_tmp;
} 

int org_normalize_subword_height(Stack S, int *Sary, int L, int H, int Hnca,
							DocSet docset, Query query)
{
  int H_parent, H_tmp, pos;
  int H_new = 0;
  char c;

  //getting the parent of the current node
  if (S->top < 1)
    error_exit("last_proper_index_point: no parent node in the stack!\n");

  //H_parent = NEXTTOP(S)->hgt;
  H_parent = get_parent_of_top(S)->hgt;

  if (H_parent > Hnca)
    ;//do nothing
  else
    H_parent = Hnca;

  if (H_parent >= H)
	error_exit("last_proper_index_point: H_parent >= H: impossible!\n");
  
  //try to find a space on an edge from the current to the parent.
  pos = docset->A[Sary[L]];
  for (H_tmp = H; H_parent < H_tmp; H_tmp--) {
    c = docset->Text[pos + H_tmp - 1];
	if (CHT_IS_CHAR_ON(docset->word_sep_list, c)) { //experimental
      //note: the last space is found, and return its offset from the tail.
	  H_new = H_tmp;
      break;
	}
  }

  //experimental
  for (; H_parent < H_new; H_new--) {
	if (!CHT_IS_CHAR_ON(docset->word_sep_list, c)) 
      //note: the last space is found, and return its offset from the tail.
      return H_new + 1;
    c = docset->Text[pos + H_new - 1];
  }
  
  return 0; 
} // end of last_proper_index_point()

int org_org_last_proper_index_point(Stack S, int *Sary, int L, int H, int Hnca,
							DocSet docset, Query query)
{
  int H_parent, H_tmp, pos;
  int H_new = 0;
  char c;

  //getting the parent of the current node
  if (S->top < 1)
    error_exit("last_proper_index_point: no parent node in the stack!\n");

  //H_parent = NEXTTOP(S)->hgt;
  H_parent = get_parent_of_top(S)->hgt;

  if (H_parent > Hnca)
    ;//do nothing
  else
    H_parent = Hnca;

  if (H_parent >= H)
	error_exit("last_proper_index_point: H_parent >= H: impossible!\n");
  
  //try to find a space on an edge from the current to the parent.
  pos = docset->A[Sary[L]];
  for (H_tmp = H; H_parent < H_tmp; H_tmp--) {
    c = docset->Text[pos + H_tmp - 1];

    //if (c == ' ' || c == DOC_SEP)
	//  return H_tmp;
	if (CHT_IS_CHAR_ON(docset->word_sep_list, c)) //experimental
      //note: the last space is found, and return its offset from the tail.
      return H_tmp;
  }
  return 0; 
} // end of last_proper_index_point()

/****************************************
 * function pointer to a node visiting function
 * visit_func
 ****************************************/ 

/// function pointer to visit function

/****************************************
 * Pruning by Left-maximality
 * - Right-maximality: the normal suffix trees
 * - Left-maximality : the reverse suffix trees
 ****************************************/ 

#define MAXBUF 128

int isLeftExtensible(DocSet docset, int *SA, int L, int R) {
	int i;
	char last = docset->Text[docset->A[SA[L]]]; 
	char buf[MAXBUF];
	int org_len = 0; 

  for(i = L; i <= R; i++) {
		int x = SA[i];

		//not-extensible
		if (x == 0) return 0; 

		//str[0..len-1] is the left neighbor word of the current word
		int cur  = docset->A[x];
		int prev = docset->A[x-1];
		char *str  = docset->Text+prev; 
		int len  = cur - prev; 

		if (i == L) { //copy
			if (cur - prev > MAXBUF)
				ERREXIT("error: isLeftExtensible: a word is too long\n");
			strncpy(buf, str, len);
			buf[len] = '\0';
			org_len = len;
		}
		else { //compare
			if (len != org_len)
				return 0;
			if (strncmp(buf, str, len) != 0)
				return 0;
		}
	}
	return 1;
}


/****************************************
 * Traverse: main routine
 * Enumerating all branching substrings
 ****************************************/ 

void traverse(DocSet docset, Query query, PatSet patset,
			  void (* visit_func) (int, int, int, int, DocSet, Query, PatSet))
{
  assert(docset != NULL);

  /// function pointer to visit function
  //void (* visit_func)(int L, int R, int H, int H0, DocSet docset,
  //					  Query query,PatSet patset);
  //  visit_func = docset->visit_func;

  int i; //the current text position 

  //(L, H): the current node with the associated interval (L, R)
  int L, R, H;

  //(Lnca, Hnca): the nearest common ancestor node 
  int Lnca, Hnca; 

  //Array variables
  assert(docset->Sary != NULL);
  assert(docset->Hgt != NULL);
  assert(docset->Num > 0);
  int *Sary = docset->Sary; 
  int *Hgt  = docset->Hgt; 
  int n     = docset->Num;

  //The stack for virtual nodes {L,H} 
  Stack S = stack_alloc(docset->MaxML+2); 
  stack_makenull(S);
  IntPair NcaPtr = ip_create(-1, -1); //Initial Nca = {-1,-1};  
  stack_push(S, NcaPtr); 

  // Traversing all branching strings of the text by using suffix array.
  for(i = 0; i < n; i++) {

    SET_NCA_NODE(Lnca, Hnca, i);
    SET_TOP_NODE(L, H, S); 
	R = i;

#ifdef DEBUG_TRACE
	printf("@traverse: %d:%d:%d \n", i, R, H);
#endif

    while(H > Hnca) {
	  //modified by arim: filtering out incomplete words.
	  //note: (L, H_tmp) is a pair for the current node

	  int H_tmp = H;  //do nothing
#ifdef COMMENT
	  if (IS_FLAG_ON(query, FLAG_WORD_MODE)) {
		H_tmp = normalize_subword_height(S, Sary, L, H, Hnca, docset, query);
		fflush(stdout); //omaginai
	  }
#endif
	  if (H_tmp > 0) { //prune empty normalized words {
		visit_func(L, R, H_tmp, H, docset, query, patset);
	  }

	  //if (H_tmp > 0) { //prune empty normalized words {
	  //	visit_node(L, R, H_tmp, H, docset, query, patset);
	  //}

	  Lnca = L;
	  stack_pop(S);
	  SET_TOP_NODE(L, H, S);

    }

    //print_dot(query->d, depth);

    if (H == Hnca)
	  continue;
    else if (H < Hnca) {
	  NcaPtr->left = Lnca; NcaPtr->hgt = Hnca;
	  stack_push(S, NcaPtr);
    }
  } //for-loop
}


void org_traverse(DocSet docset, Query query, PatSet patset)
{
  assert(docset != NULL);

  /// function pointer to visit function
  //void (* visit_func)(int L, int R, int H, int H0, DocSet docset,
  //					  Query query,PatSet patset);
  //  visit_func = docset->visit_func;

  int i; //the current text position 

  //(L, H): the current node with the associated interval (L, R)
  int L, R, H;

  //(Lnca, Hnca): the nearest common ancestor node 
  int Lnca, Hnca; 

  //Array variables
  assert(docset->Sary != NULL);
  assert(docset->Hgt != NULL);
  assert(docset->Num > 0);
  int *Sary = docset->Sary; 
  int *Hgt  = docset->Hgt; 
  int n     = docset->Num;

  //The stack for virtual nodes {L,H} 
  Stack S = stack_alloc(docset->MaxML+2); 
  stack_makenull(S);
  IntPair NcaPtr = ip_create(-1, -1); //Initial Nca = {-1,-1};  
  stack_push(S, NcaPtr); 

  // Traversing all branching strings of the text by using suffix array.
  for(i = 0; i < n; i++) {

    SET_NCA_NODE(Lnca, Hnca, i);
    SET_TOP_NODE(L, H, S); 
	R = i;

#ifdef DEBUG_TRACE
	printf("@traverse: %d:%d:%d \n", i, R, H);
#endif

    while(H > Hnca) {
	  //modified by arim: filtering out incomplete words.
	  //note: (L, H_tmp) is a pair for the current node

	  int H_tmp = H;  //do nothing
#ifdef COMMENT
	  if (IS_FLAG_ON(query, FLAG_WORD_MODE)) {
		H_tmp = normalize_subword_height(S, Sary, L, H, Hnca, docset, query);
		fflush(stdout); //omaginai
	  }
#endif
	  if (H_tmp > 0) { //prune empty normalized words {
		vf_visit_node_func(L, R, H_tmp, H, docset, query, patset);
	  }

	  //if (H_tmp > 0) { //prune empty normalized words {
	  //	visit_node(L, R, H_tmp, H, docset, query, patset);
	  //}

	  Lnca = L;
	  stack_pop(S);
	  SET_TOP_NODE(L, H, S);

    }

    //print_dot(query->d, depth);

    if (H == Hnca)
	  continue;
    else if (H < Hnca) {
	  NcaPtr->left = Lnca; NcaPtr->hgt = Hnca;
	  stack_push(S, NcaPtr);
    }
  } //for-loop
}


/**************************************************
 * main routine 
 **************************************************/

PatSet discover(DocSet docset, Query query,
				void (* visit_func) (int, int, int, int, DocSet, Query, PatSet))
{
#ifdef DEBUG_TRACE
  printf("@discover: enter\n");
#endif
  //Set Global object
  //_docset = docset;
  //Create an answer patset
  PatSet patset = patset_create(docset, query);

  // Discover
  traverse(docset, query, patset, visit_func);

#ifdef DEBUG_TRACE
  printf("@discover: exit\n");
#endif
  return patset; 
}


#ifdef COMMENT
PatSet org_discover(DocSet docset, Query query)
{
#ifdef DEBUG_TRACE
  printf("@discover: enter\n");
#endif
  //Set Global object
  //_docset = docset;
  //Create an answer patset
  PatSet patset = patset_create(docset, query);

  // Discover
  traverse(docset, query, patset);

#ifdef DEBUG_TRACE
  printf("@discover: exit\n");
#endif
  return patset; 
}

#endif

/* EOF */
