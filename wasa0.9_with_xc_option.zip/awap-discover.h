#ifndef ___discover___
#define ___discover___ 

#include "awap-patset.h"
#include "awap-docset.h"
#include "awap-query.h"

//extern PatSet discover(DocSet docset, Query query);

extern PatSet discover(DocSet docset, Query query,
					   void (*)(int,int, int, int, DocSet, Query, PatSet));

#endif 

