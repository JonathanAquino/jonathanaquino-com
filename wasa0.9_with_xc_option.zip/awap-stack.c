/* awap-estack.c 
 * - created by arim@ist (15JUL06)
 */

#include <stdlib.h>
#include <assert.h>
#include "awap-stack.h"

/****************************************
 * Global definitions
 ****************************************/

/****************************************
 * IntPair: 
 ****************************************/ 

IntPair ip_alloc(void) {
	IntPair tmp = NULL;
	if ((tmp = (IntPair) malloc(sizeof(struct _intpair))) == NULL)
		error_exit("error: ip_alloc: cannot allocate memory!\n");
	tmp->left = UNDEF;
	tmp->hgt  = UNDEF;
}

IntPair ip_create(int left, int hgt) {
  IntPair tmp = ip_alloc();
  tmp->left = left;
  tmp->hgt  = hgt;
  return tmp;
}

/****************************************
 * Stack 
 ****************************************/

#define BOTTOM_INDEX (-1)

Stack stack_alloc(int maxlen) {
  Stack tmp = NULL;
  if ((tmp = (Stack) malloc(sizeof(struct _estack))) == NULL)
	error_exit("stack_alloc: cannot allocate memory for _estack!\n");

  if ((tmp->val = (IntPairCell *) malloc(maxlen * sizeof(IntPairCell))) == NULL)
	error_exit("stack_alloc: cannot allocate memory for val!\n");

  tmp->maxlen = maxlen;
  tmp->top    = BOTTOM_INDEX; //make null
  return tmp;
}

Stack stack_free(Stack tmp) {
  assert(tmp != NULL);
  free(tmp->val);
  free(tmp);
}

int stack_is_empty(Stack s) {
  return (s->top <= BOTTOM_INDEX);
}

IntPair stack_top(Stack s) {
	int index = s->top;
	return &(s->val[index]); 
}

/* note: this pop-routine does not return the top cell.
 */
void stack_pop(Stack s) {
  if (s->top == BOTTOM_INDEX)
	error_exit("stack_pop: cannot pop an empty stack!\n");
  s->top--;
}

void stack_push(Stack s, IntPair ip) {
  if (s->top > s->maxlen - 2)
	error_exit("stack_push: no more cells!\n");
  s->val[++(s->top)] = *ip;
}

void stack_makenull(Stack s) {
  s->top = BOTTOM_INDEX;
}

/* EOF */

