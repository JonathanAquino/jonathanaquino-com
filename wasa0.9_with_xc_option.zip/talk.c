/*
 * emit.c
 * based on ishell.c
 * 29JUL2005, arim@ist.hokudai.ac.jp
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <assert.h>
#include <stdarg.h>
#include "ap-carray.h"
#include "talk.h"

/******************************************************************
 * Global variables
 ******************************************************************/

//#define DEBUG
#undef DEBUG

#define USAGE_STR \
    "main: usage: prog -p <pos file> -n <neg file> [-w] [-e] \n"

/* output buffer pipe communication */
#define INI_OUTBUF_SIZE (2048)
#define MIN_OUTBUF_SIZE (4096)
ChaArray g_CA_OUTBUF = NULL;
char g_TMPBUF[MIN_OUTBUF_SIZE];

/******************************************************************
 * Program 
 ******************************************************************/

//===============================================//
// Main 
//===============================================//

/*----------------------------------------*
 * INTERACTIVE SHELL
 * - modified by arim, 23 Jan 99
 *----------------------------------------*/

/*
 * Global Variable:
 */

#define USAGE_STR_HELP "Available commands: end \n"
#define USAGE_STR_EXIT "Bye! \n"

int g_UsePipeMode = TALK_ON;

void setPipeMode(int flag) {
  g_UsePipeMode = flag; 
}

void setPipeModeON()  { g_UsePipeMode = TALK_ON; }
void setPipeModeOFF() { g_UsePipeMode = TALK_OFF; }
int  getPipeMode() {  return g_UsePipeMode; }

/*
 * a line buffer for the command shell
 */
char LineBuf[BUFLEN];

void prompt() {
  if (g_UsePipeMode) return; //Do not show a prompt when using pipes
  fprintf(stdout, "command? ");
  fflush(stdout);
}

void talk_prompt() {
  prompt();
}

int get_a_word(char *line, char *command) {
  return sscanf(line, "%s ", command);
}

char *get_line(char *line) {
  FILE *stream = stdin;
  line[0] = '\0';
  char *res = fgets(line, BUFLEN, stream);
  line[strlen(line)-1] = '\0'; //delete the newline
  return res;
}

void sentence_beg(FILE *fp) {
  if (!g_UsePipeMode) return;
  fprintf(fp, "BEG\n");
  fflush(fp);
}

void sentence_end(FILE *fp) {
  if (!g_UsePipeMode) return;
  fprintf(fp, "END\n");
  fflush(fp);
}

void session_end(FILE *fp) {
  if (!g_UsePipeMode) return;
  fprintf(fp, "RET\n");
  fflush(fp);
}

void talk_session_end() {
  FILE *fp = stdout; 
  if (!g_UsePipeMode) return;
  fprintf(fp, "RET\n");
  fflush(fp);
}

void org_talk_printf(char *fmt, ...)
{ /* modification of minprintf in K&R. See pp307 of K&R 2nd in detail. */
  /* this is exactly same as printf() builtins except executed only when debug flag is on. */
  FILE *stream = stdout; 


  va_list ap;
  char *p, *sval;
  int ival;
  double dval;

  sentence_beg(stdout);
  va_start(ap, fmt);
  vfprintf(stream, fmt, ap); /* processing argumnt list */
  va_end(ap);	 /* clean up when finished */
  sentence_end(stdout);
}

void talk_print_outbuf(FILE *stream, ChaArray ca)
{
  int n;
  unsigned char c;
  assert(ca != NULL);
  if (ca == NULL) return; 

  for (n = 0; n < ca->len; n++) {
    c = ca->val[n];
	fputc(c, stream);
  }
}

void _talk_print_outbuf(FILE *stream, ChaArray ca)
{
  int n;
  unsigned char c;
  char last = '\0';
  assert(ca != NULL);
  if (ca == NULL) return; 

  for (n = 0; n < ca->len; n++) {
    c = ca->val[n];
    if (isprint(c))
	  fputc(c, stream);
    else if (c == '\n')
      fputc('\n', stream);
    else if (c == '\r')
      fputc('\n', stream);
    else if (c == '\t')
      fputc('\t', stream);
    else {
	  fprintf(stream, "\\%d", c);
	  fprintf(stderr, "talk_print_outbuf: not printable letter!: %d (x0%X)\n",
			  c, c);
	}
	last = c; 
  }
  if (last != '\n')
	fputc('\n', stream); //ensure a message is terminated by a newline.
}

void talk_printf_msg(char *fmt, ...) {
  /* modification of minprintf in K&R. See pp307 of K&R 2nd in detail. */
  /* this is exactly same as printf() builtins except executed only when debug flag is on. */
  
  if (g_CA_OUTBUF == NULL)
	g_CA_OUTBUF = ca_alloc(); //create a buffer

  va_list ap;
  char *p, *sval;
  int ival;
  double dval;

  //initialize
  va_start(ap, fmt);

  //write
  g_TMPBUF[0] = g_TMPBUF[MIN_OUTBUF_SIZE-1] = '\0'; //null terminated
  vsprintf(g_TMPBUF, fmt, ap); //write a null terminated C-string
  //terminate
  va_end(ap);	 /* clean up when finished */

  if (g_TMPBUF[MIN_OUTBUF_SIZE-1] != '\0')
	error_exit("talk_put_printf: null temination violated. something wrong!\n");
  int len = strlen(g_TMPBUF);
  ca_append_str(g_CA_OUTBUF, g_TMPBUF);

}

void talk_send_msg(void) {

#ifdef DEBUG
	fprintf(stderr, "debug: g_CA_OUTBUF: %d [",
			g_CA_OUTBUF->len);
	//talk_print_outbuf(stderr, g_CA_OUTBUF);
	fprintf(stderr, "]\n");
#endif
  
  sentence_beg(stdout);
  talk_print_outbuf(stdout, g_CA_OUTBUF);
  sentence_end(stdout);

  ca_make_null(g_CA_OUTBUF);
}


//EOF 
