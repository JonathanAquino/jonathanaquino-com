#define IS_FLAG_ON(Q, FLAG)  ((Q)->flag & (FLAG))
#define FLAG_SET_ON(Q, FLAG)  ((Q)->flag = ((Q)->flag | (FLAG)))
#define FLAG_SET_OFF(Q, FLAG) ((Q)->flag = ((Q)->flag & ~(FLAG)))

#define FLAG_NULL  (0)	
#define FLAG_WORD_MODE (1 << 0)	//Option: completing word boundary
#define FLAG_BOTH_SIDE (1 << 1)	//Option: branching word both sides
#define FLAG_PRINT_LOC (1 << 2)	//Option: printing location lists
#define FLAG_PRINT_INFILE (1 << 3)	//Option: printing input files and stop
#define FLAG_PRINT_SUFFIX (1 << 4)	//Option: printing all suffixes and stop
#define FLAG_AUTOECHO_MODE (1 << 5)	//Option: useAutoEchoMode
#define FLAG_TALKPIPE_MODE (1 << 6)	//Option: useTalkPipe (python talk mode/popen2))

