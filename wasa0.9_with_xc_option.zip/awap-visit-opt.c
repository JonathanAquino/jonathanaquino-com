/* awap-visit-opt.c
 * - created by arim@ist (17JUL06)
 */

#include "awap.h"
#include "awap-ctable.h"
#include "awap-misc.h"
#include "awap-visit-func.h"

/****************************************
 * Global definitions
 ****************************************/

/****************************************
 * Utilities
 ****************************************/ 

int pattern_is_frequent_opt(Ctable ctable, Query query) {
	int side   = query->occ_side;
	int minsup = query->min_sup; 
	//side is +1, 0, or -1
	int res1 = (ctable_count_pos(ctable) >= minsup);
	int res0 = (ctable_count_neg(ctable) >= minsup);

	if (side > 0)
	  return res1; 
	else if (side < 0) 
	  return res0;
	else //side == 0
	  return res1 || res0;
}

/****************************************
 * Routines
 ****************************************/ 

//Main work: process the current node
void visit_node_opt(
				int L, int R, int H, int H0,  //The current node
				DocSet docset, 
				Query query,
				PatSet patset //Other parameters
				) {
  Pattern pattern;
  double measure;
  PosList poslist;

#ifdef DEBUG_TRACE
  printf("@visit %d:%d:%d:%d ", L, R, H, H0);
#endif

  Ctable ctable = compute_ctable(docset, L, R);

  //Pruning by One-sided occurrence constraint
  if (query->occ_side != 0)  //PosSideFilter is active
	if (!pattern_isPosSide(ctable, query)) {
#ifdef DEBUG_TRACE
	  printf("\n");
#endif
	  return; //prune
	}

#ifdef DEBUG_TRACE
  printf(" @S");
#endif

  //Pruning by minimum support constraint
  if (!pattern_is_frequent_opt(ctable, query)) {
#ifdef DEBUG_TRACE
	printf("\n");
#endif
	return; //prune
  }

#ifdef DEBUG_TRACE
  printf(" @F");
#endif

  //Pruning by left branching property
  int *SA = docset->Sary;
  if (isLeftExtensible(docset, SA, L, R)) {
#ifdef DEBUG_TRACE
	printf("\n");
#endif
	return; //prune
  }

#ifdef DEBUG_TRACE
  printf(" @L");
#endif

  //At leaf: register the current pattern
  measure = eval_compute(query, ctable);	

  if (patset_isTopK(patset, measure) == FALSE) {
#ifdef DEBUG_TRACE
	printf("\n");
#endif
	return; //prune
  }

#ifdef DEBUG_TRACE
  printf(" @K");
#endif

  pattern = pattern_create(L, H, ctable_copy(ctable), measure);
  pattern->list = polist_gen(docset->Sary + L, R - L);
  //copy index values in Sary[L..R] 
  patset_insert(patset, pattern);

#ifdef DEBUG_TRACE
  printf(" @SUCCESS! ");
  printf("\n");
#endif

#ifdef DEBUG_WORDMODE
  vs_debug_report_trimming(docset, L, R, H, H0);
#endif

  return;
}

/****************************************
 * Routines
 ****************************************/ 

/* EOF */

