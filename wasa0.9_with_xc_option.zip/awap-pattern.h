#ifndef ___pattern___ 
#define ___pattern___ 

/**************************************** 
 * awap-pattern.h -- 
 * - created by arim@ist (15JUL06)
 ****************************************/

#include "ap-carray.h"
#include "awap-docset.h"
#include "awap-query.h"
#include "awap-ctable.h"
#include "awap-poslist.h"

/****************************************
 * Macros
 ****************************************/

/****************************************
 * Types 
 ****************************************/ 

/** struct Pattern. The data structure for representing a discovered
	pattern. 
 */
typedef struct _pattern {

  // the substring of a text
  int     L; 
  int     H; 
  Charray str; //the string 

  // the score value of the pattern
  double eval;

  // the contingency table of the pattern
  //(frequency table in positive and negative texts).
  Ctable ctable;

  // the location list of the pattern
  PosList list;

  // the pointer to the next pattern: 
  //Used to implement a linked list of patterns. 
  struct _pattern *next;

} *Pattern;

/****************************************
 * Externs: functions and global varialbles 
 ****************************************/ 

extern void pattern_initialize(DocSet docset);
extern Pattern pattern_alloc(); 
extern void pattern_free(Pattern pat);
extern Pattern pattern_create(int L, int H, Ctable ctable, double eval);
extern void pattern_print(Pattern pat, int pid, Query query); 
extern void pattern_print_axis(Query query);
extern int pattern_isPosSide(Ctable ctable, Query query); 

#endif 
