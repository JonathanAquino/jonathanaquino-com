#ifndef ___dataset___
#define ___dataset___ 

/**************************************** 
 * awap-dataset.h
 * - created by 30 July 2005 by arim@ist.hokudai.ac.jp
 * - created by 06 June 1999 by arim@i.kyushu-u.ac.jp
 * the data structure for data sets
 ****************************************/

#include <stdio.h>
#include "ap-iarray.h"
#include "ap-carray.h"
#include "awap-query.h"
#include "awap-chtable.h"

/****************************************
 * Macros
 ****************************************/

#define DS_CATID_POS (0)
#define DS_CATID_NEG (1)

/****************************************
 * Types 
 ****************************************/ 

/** struct DocSet. An internal data structure for a collection of
	strings, called documents with a set of indicies for quickly
	accessing its substrings. 
 */
typedef 
struct _DocSet {

  /**********************************************
   * Text: Arrays of letters 
   **********************************************/

  /// Input Text. (Text[0 .. N-1])	
  Charray Text_buf; 
  char *Text;

  /// The length of allocated array for text
  int maxTextLen;

  /// the total length of the text
  int TextLen;

  int PosTextLen;

  /**********************************************
   * Lists: Arrays of Indexes
   **********************************************/

  /// The length of allocated array for text
  int maxListLen; 

  /// the number of index points
  int Num    ;

  ///the number of documents per category
  Intarray Num_buf;
  int Posnum ; ///the number of positive documents
  int Negnum ; ///the number of negative documents

  /// Indexing point. (A[0 .. n-1])
  Intarray A_buf;
  int  *A   ;	

  /// Suffix array of A.         (rank -> position)
  int  *Sary;	

  /// Inverse function of Saray. (position -> rank)
  int  *Prm ;	

  /// Height array.              (rank -> height)
  int  *Hgt ;	

  /// Documents numbers.   (position -> doc number)
  Intarray Doc_buf;
  int  *Doc ;	

  /// Objective Condition.       (doc number -> {0, 1})
  Charray Cat_buf;
  char *ObjC;   

  /**********************************************
   * Others
   **********************************************/

  ///the maximum length of branching words
  int MaxML  ;

  ///the average length of branching words
  int AveML  ;   

  ///the character table for word delimitors.
  Chtable word_sep_list; 

  ///the character table for sentence delimitors.
  Chtable sent_sep_list;

  ///letter conversion function
  char (* char_convert_func)(char c); //a function pointer 

} *DocSet; 

/****************************************
 * Externs: functions and global varialbles 
 ****************************************/ 

extern DocSet ds_alloc(); 
extern void ds_free(DocSet docset); 

extern void ds_build(DocSet docset, Query query, Intarray posfiles, Intarray negfiles);

extern void ds_print(DocSet docset, FILE *fp);
extern void ds_print_text(DocSet docset, FILE *fp);
extern void ds_print_suffices(DocSet docset, Query query, FILE *fp);

extern char *ds_get_a_document(DocSet docset, int idx, int *len_ptr, int *orig_ptr, int *doc_ptr); 
extern void ds_retrieve_substr(DocSet docset, Charray ca, int L, int H);
extern Charray ds_get_substr(DocSet docset, int L, int H); 

extern int ds_is_word_sep(DocSet docset, char c);
extern int ds_is_sent_sep(DocSet docset, char c);

/* letter conversion function */
extern void ds_set_char_conversion_func(char (* func)(char c));
extern char ds_convert_no_conversion(char c);
extern char ds_convert_downcase_char(char c);

extern int ds_get_docid (DocSet docset, int i);
extern int ds_get_textpos(DocSet docset, int i);

#endif
