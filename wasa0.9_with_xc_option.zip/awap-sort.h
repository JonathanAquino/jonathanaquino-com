#ifndef ___sort___
#define ___sort___ 

extern void sort_init(void); 

extern void ssort(char *Text, int *A, int *Sary, int n); 

#endif
