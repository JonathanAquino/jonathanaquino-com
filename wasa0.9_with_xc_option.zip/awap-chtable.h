#ifndef ___awap_chtable___
#define ___awap_chtable___

/**************************************** 
 * awap-chtable.h 
 * - A character type table with O(1) membership test
 * - created by arim@ist (15JUL06)
 ****************************************/

//#include "awap.h"

/****************************************
 * Macros
 ****************************************/

#define MAXBYTE 256	//the number of bytes

#define CHT_IS_CHAR_ON(CHT, C) ((CHT)->_array[(C)])

/****************************************
 * Types 
 ****************************************/ 

typedef struct _ch_table {
  /// A Boolean array for checking word delimitors.
  char _array[MAXBYTE]; 
} *Chtable;


/****************************************
 * Externs: functions and global varialbles 
 ****************************************/ 

extern Chtable cht_alloc(); 
extern void cht_free(Chtable tmp); 
extern void cht_make_null(Chtable tmp); 
extern void cht_add_letters(Chtable cht, char *s); 
extern int  cht_get(Chtable cht, unsigned char c); 
extern void cht_put(Chtable cht, unsigned char c, int value); 

#endif 
