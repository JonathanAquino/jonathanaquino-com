#ifndef ___awap_misc___
#define ___awap_misc___

/**************************************** 
 * awap-misc.h -- 
 * - created by arim@ist (17JUL06)
 ****************************************/

//#include "awap.h"
#include "awap-ctable.h"
#include "awap-docset.h"

/****************************************
 * Macros
 ****************************************/

/****************************************
 * Types 
 ****************************************/ 

/****************************************
 * Externs: functions and global varialbles 
 ****************************************/ 

extern Ctable compute_ctable(DocSet docset, int L, int R);

extern void vs_debug_report_trimming(DocSet docset, int L, int R, int H, int H0);

#endif 
