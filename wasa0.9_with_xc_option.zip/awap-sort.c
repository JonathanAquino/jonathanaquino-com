/* 
 * awap-sort.c -- Implementation of MultiKey QuickSort
 * (12/8/98)
 * 21 SEP 99 by arim:
 - Removed some fraws and redundant codes from ssort1 and ssort2, 
 *   which greatly improved efficiecy for files with long strings. 
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <limits.h>
#include "awap.h"

//forward declaration
extern void ssort1(char *Text, int *Idx, int *sary, int n, int depth);

void sort_init(void) {
	time_t  seed;

	time(&seed);
	srand(seed);
	rand();
}

void ssort(char *Text, int *Idx, int *Sary, int n)
{
	ssort1(Text, Idx, Sary, n, 0);
}

//void ssort(char *Text, int *Idx, int *Sary, int n)
//{
//  ssort2(Text, Idx, Sary, n, 0);
//}

//===============================================//
//          SORTING  (11/5/98)                   //
//===============================================//


/*
 * MULTIKEY QUICKSORT
 */

//
// ssort1 -- Simple Version of Multikey Quicksort
//

#ifndef min
#define min(a, b) ((a)<=(b) ? (a) : (b))
#endif

//Get the d-th letter of the i-th ranked suffix in Suf
#define i2c(i) Text[Idx[Suf[i]] + depth]

//Swap two entries in SA
#define swap(a, b) { int t=Suf[a]; \
                     Suf[a]=Suf[b]; Suf[b]=t; }

//Swap n positions starting from i and j
void vecswap(int i, int j, int n, int *Suf)
{ 
    while (n-- > 0) {
		swap(i, j);
		i++;
		j++;
    }
}

/** Sort array Suf of string pointers of length n. */
void docsort1(int *Suf, int n)
{
    int    a, b, c, d, r;
	int    v; //a pivot value
    int    i;
    if (n <= 1)
		return;

	//Get a povot
    a = rand() % n;
    swap(0, a);
    v = Suf[0];

	
    a = b = 1;   	//The left  end
    c = d = n - 1;	//The right end
    for (;;) {
		//Move pointer b to the right
		while (b <= c && (r = Suf[b] - v) <= 0) {
			if (r == 0) { swap(a, b); a++; }
			b++;
		}
		//Move pointer c to the left 
		while (b <= c && (r = Suf[c] - v) >= 0) {
			if (r == 0) { swap(c, d); d--; }
			c--;
		}
		if (b > c) break;
		swap(b, c);
		b++;
		c--;
    }
    r = min(a, b - a);         vecswap(0, b - r, r, Suf);
    r = min(d - c, n - d - 1); vecswap(b, n - r, r, Suf);
	// Recursively sort the subarray [a, b) at the left end
    r = b - a; docsort1(Suf, r);
	// Recursively sort the subarray [c, d) at the right end
    r = d - c; docsort1(Suf + n - r, r);
}

void ssort1(char *Text, int *Idx, int *Suf, int n, int depth) 
{   
    int    a, b, c, d, r, v;
    int    i;

    if (n <= 1)
		return;
    a = rand() % n;
    swap(0, a);
    v = i2c(0);
    a = b = 1;
    c = d = n - 1;
    for (;;) {
		while (b <= c && (r = i2c(b) - v) <= 0) {
			if (r == 0) { swap(a, b); a++; }
			b++;
		}

		while (b <= c && (r = i2c(c) - v) >= 0) {
			if (r == 0) { swap(c, d); d--; }
			c--;
		}
		if (b > c) break;
		swap(b, c);
		b++;
		c--;
    }
    r = min(a, b - a);     vecswap(0, b - r, r, Suf);
    r = min(d - c, n - d - 1); vecswap(b, n - r, r, Suf);
    r = b - a; ssort1(Text, Idx, Suf, r, depth);
    if (i2c(r) == DOC_SEP)
		docsort1(Suf + r, a + n - d - 1);
    else
		ssort1(Text, Idx, Suf + r, a + n - d - 1, depth + 1);
    r = d - c; ssort1(Text, Idx, Suf + n - r, r, depth);
}

void ssort1main(char *Text, int *Idx, int *Sary, int n)
{ ssort1(Text, Idx, Sary, n, 0); }

//
// ssort2 -- Faster Version of Multikey Quicksort
//

void vecswap2(int *Suf, int *b, int n)
{   while (n-- > 0) {
	int t = *Suf;
	*(Suf++) = *b;
	*(b++) = t;
}
}

#define swap2(a, b) { t = *(a); *(a) = *(b); *(b) = t; }

int *docmed3func(int *a, int *b, int *c)
{   int va, vb, vc;
 if ((va=*a) == (vb=*b))
	 return a;
 if ((vc=*c) == va || vc == vb)
	 return c;
 return va < vb ?
	 (vb < vc ? b : (va < vc ? c : a ) )
	 : (vb > vc ? b : (va < vc ? a : c ) );
}
#define docmed3(a, b, c) docmed3func(a, b, c)

void docinssort(int *Suf, int n)
{   
    int *pi, *pj, t;
    for (pi = Suf + 1; --n > 0; pi++)
        for (pj = pi; pj > Suf; pj--) {
			if (*(pj - 1) < *pj)
				break;
            swap2(pj, pj - 1);
		}
}

void docsort2(int *Suf, int n)
{
    int d, r, partv;
    int  *pa, *pb, *pc, *pd, *pl, *pm, *pn, t;

    if (n < 10) {
        docinssort(Suf, n);
        return;
    }
    pl = Suf;
    pm = Suf + (n/2);
    pn = Suf + (n - 1);
    if (n > 30) { // On big arrays, pseudomedian of 9
        d = (n/8);
        pl = docmed3(pl, pl + d, pl + 2*d);
        pm = docmed3(pm - d, pm, pm + d);
        pn = docmed3(pn - 2*d, pn - d, pn);
    }
    pm = docmed3(pl, pm, pn);
    swap2(Suf, pm);
    partv = *Suf;
    pa = pb = Suf + 1;
    pc = pd = Suf + n - 1;
    for (;;) {
        while (pb <= pc && (r = *pb - partv) <= 0) {
            if (r == 0) { swap2(pa, pb); pa++; }
            pb++;
        }
        while (pb <= pc && (r = *pc - partv) >= 0) {
            if (r == 0) { swap2(pc, pd); pd--; }
            pc--;
        }
        if (pb > pc) break;
        swap2(pb, pc);
        pb++;
        pc--;
    }
    pn = Suf + n;
    r = min(pa - Suf, pb - pa);    vecswap2(Suf,  pb - r, r);
    r = min(pd - pc, pn - pd - 1); vecswap2(pb, pn - r, r);
    if ((r = pb - pa) > 1)
        docsort2(Suf, r);
    if ((r = pd - pc) > 1)
        docsort2(Suf + n - r, r);
}

#define ptr2char(i) (Text[Idx[*(i)] + depth])

int *med3func(char *Text, int *Idx, int *a, int *b, int *c, int depth)
{   int va, vb, vc;
 if ((va=ptr2char(a)) == (vb=ptr2char(b)))
	 return a;
 if ((vc=ptr2char(c)) == va || vc == vb)
	 return c;       
 return va < vb ?
	 (vb < vc ? b : (va < vc ? c : a ) )
	 : (vb > vc ? b : (va < vc ? a : c ) );
}
#define med3(Text, Idx, a, b, c) med3func(Text, Idx, a, b, c, depth)

void inssort(char *Text, int *Idx, int *Suf, int n, int d)
{   
    int *pi, *pj, s, t;
    for (pi = Suf + 1; --n > 0; pi++)
        for (pj = pi; pj > Suf; pj--) {
            // Inline strcmp: break if &Text[Idx[*(pj-1)]] <= &Text[Idx[*(pj)]])
            for (s=Idx[*(pj - 1)] + d, t=Idx[*pj] + d; 
				 Text[s]==Text[t] && Text[s]!=DOC_SEP; s++, t++)
                ;
            if (Text[s] < Text[t])
                break;
			if (Text[s] == Text[t] && s < t)
				break;
            swap2(pj, pj - 1);
		}
}

void ssort2(char *Text, int *Idx, int *Suf, int n, int depth)
{
    int d, r, partval;
    int  *pa, *pb, *pc, *pd, *pl, *pm, *pn, t;

    //    fprintf(stderr, "  %d  ", depth);   
    if (n < 10) {
        inssort(Text, Idx, Suf, n, depth);
        return;
    }
    pl = Suf;
    pm = Suf + (n/2);
    pn = Suf + (n - 1);
    if (n > 30) { // On big arrays, pseudomedian of 9
        d = (n/8);
        pl = med3(Text, Idx, pl, pl + d, pl + 2*d);
        pm = med3(Text, Idx, pm - d, pm, pm + d);
        pn = med3(Text, Idx, pn - 2*d, pn - d, pn);
    }
    pm = med3(Text, Idx, pl, pm, pn);
    swap2(Suf, pm);
    partval = ptr2char(Suf);
    pa = pb = Suf + 1;
    pc = pd = Suf + n - 1;
    for (;;) {
        while (pb <= pc && (r = ptr2char(pb) - partval) <= 0) {
            if (r == 0) { swap2(pa, pb); pa++; }
            pb++;
        }
        while (pb <= pc && (r = ptr2char(pc) - partval) >= 0) {
            if (r == 0) { swap2(pc, pd); pd--; }
            pc--;
        }
        if (pb > pc) break;
        swap2(pb, pc);
        pb++;
        pc--;
    }
    pn = Suf + n;
    r = min(pa - Suf, pb - pa);    vecswap2(Suf,  pb - r, r);
    r = min(pd - pc, pn - pd - 1); vecswap2(pb, pn - r, r);
    if ((r = pb - pa) > 1)
        ssort2(Text, Idx, Suf, r, depth);
    if (ptr2char(Suf + r) == 0)
		//docsort2(Suf + r, pa - Suf + pn - pd - 1);
		; /* do nothing; entire document is considered */
    else
        ssort2(Text, Idx, Suf + r, pa - Suf + pn - pd - 1, depth+1);
    if ((r = pd - pc) > 1)
        ssort2(Text, Idx, Suf + n - r, r, depth);
}

void ssort2main(char *Text, int *Idx, int *Sary, int n) { 
    ssort2(Text, Idx, Sary, n, 0); }


//===============================================//
// QSort
//===============================================//

int *QSmed3func(int *a, int *b, int *c)
{   int va, vb, vc;
 if ((va=*a) == (vb=*b))
	 return a;
 if ((vc=*c) == va || vc == vb)
	 return c;       
 return va < vb ?
	 (vb < vc ? b : (va < vc ? c : a ) )
	 : (vb > vc ? b : (va < vc ? a : c ) );
}
#define QSmed3(a, b, c) QSmed3func(a, b, c)

void QSinssort(int *IAry, int n)
{   
    int *pi, *pj, t;
    for (pi = IAry + 1; --n > 0; pi++)
        for (pj = pi; pj > IAry; pj--) {
            if (*(pj - 1) < *pj)
                break;
			if (*(pj - 1) == *pj)
				break;
            swap2(pj, pj - 1);
		}
}

void QSort(int *IAry, int n)
{
    int r, partval, d;
    int  *pa, *pb, *pc, *pd, *pl, *pm, *pn, t;
    if (n < 10) {
        QSinssort(IAry, n);
        return;
    }
    pl = IAry;
    pm = IAry + (n / 2);
    pn = IAry + (n - 1);
    if (n > 30) { // On big arrays, pseudomedian of 9
        d = (n/8);
        pl = QSmed3(pl, pl + d, pl + 2*d);
        pm = QSmed3(pm - d, pm, pm + d);
        pn = QSmed3(pn - 2*d, pn - d, pn);
    }
    pm = QSmed3(pl, pm, pn);
    swap2(IAry, pm);
    partval = *IAry;
    pa = pb = IAry + 1;
    pc = pd = IAry + n - 1;
    for (;;) {
        while (pb <= pc && (r = *pb - partval) <= 0) {
            if (r == 0) { swap2(pa, pb); pa++; }
            pb++;
        }
        while (pb <= pc && (r = *pc - partval) >= 0) {
            if (r == 0) { swap2(pc, pd); pd--; }
            pc--;
        }
        if (pb > pc) break;
        swap2(pb, pc);
        pb++;
        pc--;
    }
    pn = IAry + n;
    r = min(pa - IAry, pb - pa);    vecswap2(IAry,  pb - r, r);
    r = min(pd - pc, pn - pd - 1); vecswap2(pb, pn - r, r);
    if ((r = pb - pa) > 1)
        QSort(IAry, r);
    //ssort2(Idx, Suf + r, pa - Suf + pn - pd - 1, depth+1);
    if ((r = pd - pc) > 1)
        QSort(IAry + n - r, r);
}
 
