/*
 * ap-carray.h
 * $Id: ap-carray.h,v 1.1.1.1 2006/07/20 12:24:20 arim Exp $
 */

#ifndef INCLUDED_AP_CARRAY
#define INCLUDED_AP_CARRAY

/******************************************************************
 * Macros
 ******************************************************************/

#ifndef _REPO_DEFINED_
#define  REPO_CA(ANAME)  ({printf("\t" #ANAME ":");  ca_report(ANAME);})
#define _REPO_DEFINED_
#endif

/******************************************************************
 * Types
 ******************************************************************/

typedef struct _cha_array {
  char *val;  /* array of chars */
  int  len;   /* the length of the array */
  int  maxlen; /* the length of the allocated array */
} *ChaArray, *Charray;
 
/* Note: Intarray is a pointer to a struct. */

/******************************************************************
 * Functions
 ******************************************************************/
extern ChaArray ca_alloc(void); 
extern void ca_free(ChaArray temp);
extern void ca_make_null(ChaArray tmp); 
extern void ca_realloc(ChaArray ca, int size); 

extern void ca_fill_random(ChaArray ca, char low, char high, int len);
extern void ca_fill_random_alpha(ChaArray ca, int len);
extern void ca_fill_random_digit(ChaArray ca, int len);
extern void ca_fill_random_genome(ChaArray ca, int len);
extern int ca_is_equal(ChaArray ca, ChaArray da);

extern void ca_push_back(ChaArray ca, char c);
extern void ca_add(ChaArray ca, char c); 
extern char ca_last(ChaArray ca); 
extern int ca_tail_index(ChaArray ca); 
extern void ca_append(ChaArray ca, ChaArray da); 
extern void ca_copy(ChaArray ca, ChaArray cb); 
extern void ca_copy_org(ChaArray ca, ChaArray cb); 

extern int  ca_top(ChaArray ca);
extern int  ca_is_empty(ChaArray ca);
extern void ca_push(ChaArray ca, char c); 
extern char ca_pop(ChaArray ca); 

extern void ca_print(ChaArray ca);
extern void ca_print_nl(); 
extern char printable_char(char c); 
extern void ca_report(ChaArray ca); 
extern void ca_print_code(ChaArray ca);
extern void ca_report_code(ChaArray ca);
extern void ca_int_print(ChaArray ca);  //for compatibility
extern void ca_int_report(ChaArray ca); //for compatibility

extern int ca_write_disk(ChaArray ca, char *outname); 
extern int ca_read_disk(ChaArray ca, char *inname); 
extern int ca_remove_disk(char *filename);
extern int ca_veryfy_disk(ChaArray ca, char *file_name); 

extern ChaArray ca_append_str(ChaArray ca, char *str); 
extern ChaArray ca_copy_str(ChaArray ca, char *str); 
extern void ca_write_to_str(ChaArray ca, char *str, int len); 
extern int ca_remove_disk(char *filename);

/******************************************************************
 * Comments
 ******************************************************************/

#endif

