/* awap-chtable.c 
 * - A character type table with O(1) membership test
 * - created by arim@ist (15JUL06)
 */

#include <stdlib.h>
#include <assert.h>
#include "awap.h"
#include "awap-chtable.h"

/****************************************
 * Global definitions
 ****************************************/

#undef DEBUG_DELIM

/****************************************
 * basic Routines
 ****************************************/

Chtable cht_alloc() {
  Chtable tmp;
  if ((tmp = (Chtable) malloc(sizeof(struct _ch_table))) == NULL)
    error_exit("cht_alloc: cannot allocate memory!\n");
  cht_make_null(tmp);
  return tmp;
}

void cht_free(Chtable tmp) {
  free(tmp);
}

void cht_make_null(Chtable tmp) {
  assert(tmp != NULL);
  assert(tmp->_array != NULL);
  int i;
  for (i = 0; i < MAXBYTE; i++) 
	tmp->_array[i] = 0;
}

void cht_add_letters(Chtable cht, char *s) {
  assert(cht->_array != NULL);
  int len = strlen(s);
  while (*s != '\0') {
	char c = *s;
	cht->_array[(int)c] = 1;
#ifdef DEBUG_DELIM
	printf("#cht_add_letters: add %d [%c]:%d\tflag=%d\n",
		   cht, c, c, cht->_array[(int)c]);
#endif
	s++;
  }
}

#ifdef COMMENT
void _cht_initialize(Chtable cht) {
  assert(cht->_array != NULL);
  //hard coded delimitors
  cht->_array[' '] = 1;
  cht->_array[DOC_SEP] = 1;

  //user-defined delimitors
  if (cht->delim_letters != NULL) {
	cht_add_letters(cht, cht->delim_letters);
  }
}
#endif

int cht_get(Chtable cht, unsigned char c) {
  assert(cht->_array  != NULL);
  return cht->_array[c];
}

void cht_put(Chtable cht, unsigned char c, int value) {
  assert(cht != NULL);
  assert(cht->_array  != NULL);
  cht->_array[c] = value;
#ifdef DEBUG_DELIM
	printf("#cht_put: add %d [%c]:%d\tflag=%d\n",
		   cht, c, c,
		   cht->_array[(int)c]);
#endif
}

/****************************************
 * Routines
 ****************************************/ 

/* EOF */

