/* awap-visit-frq.c
 * - created by arim@ist (17JUL06)
 */

#include "awap.h"
#include "awap-ctable.h"
#include "awap-misc.h"
#include "awap-visit-func.h"

//#define DEBUG_TRACE

/****************************************
 * Global definitions
 ****************************************/

void (*vf_visit_node_func) (int, int, int, int, DocSet, Query, PatSet);

void get_visit_func_pointer(int func_type) {
  switch (func_type) {
  case VF_FUNC_FRQ:
    vf_visit_node_func = visit_node_frq;
    break;
  case VF_FUNC_OPT:
    vf_visit_node_func = visit_node_opt;
    break;
  }
}


/****************************************
 * Utilities
 ****************************************/

int pattern_is_frequent_frq(Ctable ctable, Query query) {
  return (ctable_count_pos(ctable) + ctable_count_neg(ctable)
          > query->min_sup);
}

/****************************************
 * Routines
 ****************************************/

//Main work: process the current node
void visit_node_frq(
                int L, int R, int H, int H0,  //The current node
                DocSet docset,
                Query query,
                PatSet patset //Other parameters
                ) {
  Pattern pattern;
  double measure;
  PosList poslist;
  long int pid = 0; //the pattern id

#ifdef DEBUG_TRACE
  printf("@visit %d:%d:%d:%d ", L, R, H, H0);
#endif

  Ctable ctable = compute_ctable(docset, L, R);

  //Pruning by minimum support constraint
  if (!pattern_is_frequent_frq(ctable, query)) {
#ifdef DEBUG_TRACE
    printf("\n");
#endif
    return; //prune
  }

#ifdef DEBUG_TRACE
  printf(" @F");
#endif

#ifdef COMMENT
  //Pruning by left branching property
  int *SA = docset->Sary;
  if (isLeftExtensible(docset, SA, L, R)) {
#ifdef DEBUG_TRACE
    printf("\n");
#endif
    return; //prune
  }
#endif

#ifdef DEBUG_TRACE
  printf(" @L");
#endif

  //pattern = pattern_create(L, H, ctable, measure);
  pattern = pattern_create(L, H, ctable_copy(ctable), measure);

  if (IS_FLAG_ON(query, FLAG_SHOW_COUNTS)) {
      printf("%d ", ctable_count_pos(ctable) + ctable_count_neg(ctable));
  }

  pattern_print(pattern, pid, query);
  ctable_init(ctable);
  pid++;
  //Warning: ctable structure is not copied and
  //just passed to the subroutines

#ifdef DEBUG_TRACE
  printf(" @SUCCESS! ");
  printf("\n");
#endif

#ifdef DEBUG_WORDMODE
  vs_debug_report_trimming(docset, L, R, H, H0);
#endif
  return;
}

/****************************************
 * Routines
 ****************************************/

/* EOF */

