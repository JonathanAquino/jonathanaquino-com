/* talk.h
 * 29 JUL 05, Hiroki Arimura (arim@ist.hokudai.ac.jp)
 */
#ifndef _included_talk_
#define _included_talk_

#include <stdio.h>

#define TALK_ON  (1) 
#define TALK_OFF (0) 
#define BUFLEN (256)

extern void setPipeMode(int flag); 
extern int getPipeMode(); 
extern void setPipeModeON();
extern void setPipeModeOFF();

extern void talk_prompt(); 

extern char *get_line(char *line); 

extern int get_a_word(char *line, char *command); 

//extern void talk_printf(char *fmt, ...); 

extern void talk_session_end(); 

//

extern void prompt(); 

extern void sentence_beg(FILE *fp); 
extern void sentence_end(FILE *fp); 
extern void session_end(FILE *fp); 
extern void printerr(char *fmt, ...); 

extern void talk_printf_msg(char *fmt, ...);
extern void talk_send_msg();


/* EOF */

#endif

