/* 
 * awap-sort.t.c -- test file for awap-sort.c
 */

#include <stdio.h>
#include "ap-carray.h"
#include "ap-util.h"

#define MAXNAME (128)

int main(int argc, char *argv[])
{
	char infile[MAXNAME];
	if (argc == 2) {
		strcpy(infile, argv[1]);
		printf("infile: %s\n", infile);
	}
	else {
		error_exit("error: too few or many arguments: %d", argc);
	}
	

	exit(0);
}
