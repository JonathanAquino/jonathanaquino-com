#ifndef ___visit_opt___
#define ___visit_opt___

/**************************************** 
 * awap-visit-opt.h -- 
 * - created by arim@ist (17JUL06)
 ****************************************/

//#include "awap.h"
#include "awap-docset.h"
#include "awap-query.h"
#include "awap-patset.h"

/****************************************
 * Macros
 ****************************************/

/****************************************
 * Types 
 ****************************************/ 

/****************************************
 * Externs: functions and global varialbles 
 ****************************************/ 

extern void visit_node_opt(int L, int R, int H, int H0, 
					   DocSet docset, Query query, PatSet patset); 

extern void visit_node_frq(int L, int R, int H, int H0, 
					   DocSet docset, Query query, PatSet patset); 

#endif 
