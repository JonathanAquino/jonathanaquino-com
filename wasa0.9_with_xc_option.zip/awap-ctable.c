/* 
 * awap-ctable.c -- contingency table (02/09/2005)
 */

#include <stdlib.h>
#include "awap-ctable.h"
#include "awap.h"

Ctable ctable_alloc() {
  Ctable tmp;
  if ((tmp = (struct _ctable *) malloc(sizeof(struct _ctable))) == NULL)
	error_exit("ctable_alloc: cannot allocate memory!\n");
  return tmp;
}

void ctable_init(Ctable tmp) {
  tmp->P0 = tmp->P1 = 0;
  tmp->N0 = tmp->N1 = 0;
}

int ctable_count_pos(Ctable ctable) {
	return ctable->P1; 
}

int ctable_count_neg(Ctable ctable) {
	return ctable->N1; 
}

double ctable_ratio_pos(Ctable ctable) {
	return RATIO(ctable->P1, ctable->P1 + ctable->P0);
}

double ctable_ratio_neg(Ctable ctable) {
	return RATIO(ctable->N1, ctable->N1 + ctable->N0);
}


Ctable ctable_copy(Ctable ctable0) {
	Ctable ctable;
	ctable = (Ctable)malloc(sizeof(struct _ctable));
	if (ctable == NULL)
		ERREXIT("ctable_copy: memory cannot be alocated!");
	ctable->P1 = ctable0->P1;
	ctable->P0 = ctable0->P0;
	ctable->N1 = ctable0->N1;
	ctable->N0 = ctable0->N0;
	return ctable;
}
						  
