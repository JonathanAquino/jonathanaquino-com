// Constants defined by arim
#define LINEBUFLEN 256  //for command
#define MAXWORD 64	//for command

