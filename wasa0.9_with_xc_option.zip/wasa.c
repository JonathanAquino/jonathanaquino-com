/*
 * wasa.c -- word-based saffix array
 * A substring enumerator for texts
 */

/*
 * modified by arim
 * 29JULO05: Start the modification for combining with Python GUI module
 using pipe2 communication.
 * awap-discovery.v2: -can filter out in-complete subwords.
 * v2: a phrase is allowed for the first pattern.
 * v1: interactive shell (display of patterns) is modified
 */

//#define DEBUG_TRACE
#undef DEBUG_PRINT
#undef DEBUG_ISHELL

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <limits.h>
#include <ctype.h>
#include <assert.h>

#include "awap.h"
#include "awap-pattern.h"
#include "awap-query.h"
#include "awap-docset.h"
#include "awap-sort.h"
#include "awap-ishell.h"
#include "awap-commands.h"
#include "awap-discover.h"
#include "awap-visit-func.h"
#include "ev-print.h"
#include "talk.h"

/****************************************
 * Global definitions
 ****************************************/

#define USAGE_STR \
"wasa - a program for finding substrings using word-based suffix arrays\n" \
" 1999 - 2006, Hiroki Arimura, Toru Kasai. All right reserved. \n" \
"USAGE: \n" \
" wasa OPTIONS file1 ... fileN                          (freq mode)\n" \
" wasa OPTIONS -p posfile1 ...  -n negfile1 ... OPTIONS (opt mode)\n" \
" default setting: -k 400 -m 2 -w -q +1 -u 1 -d \" -\'\" -s \",:;.?!|\\\"()[]{}<>\" \n" \
"OPTIONS\n" \
" -p <files> \t pos:  specify positive file names (opt mode) \n" \
" -n <files> \t neg:  specify negative file names (opt mode) \n" \
" -k <int>\t topk: specify the number of top-K patterns (opt mode)\n" \
" -m <int>\t minsup: specify minimum support (frq and opt mode)\n" \
" -w      \t word mode  : build word-based suffix arrays (default)\n" \
" -c      \t letter mode: surpress word-mode\n" \
" -q <int>\t side: specify the target side: +1 (pos), 0 (both), -1 (neg) \n" \
" -f      \t frqmode: insist frequency mode even with -p and -n\n" \
" -u <int>\t letter conversion: 0 no conv, 1 lowercase (default) \n" \
" -d \"<string>\"\t set the word delimtors as string (-s is included in -d) \n" \
" -s \"<string>\"\t set the sentence delimtors as string, e.g., -s \":,.!?()\"\n" \
"    all sentence delimitors are automatically included in word delimitors. \n" \
" -v <level> \t verbose: set the printing level (default 0)\n" \
"OPTIONS (experimental)\n" \
" -xc \t print counts (frq mode)\n" \
" -xd \t print the statistics of arrays/docset\n" \
" -xq \t print the query setting\n" \
" -xo \t print options (to put at the beginning of options) \n" \
" -xi \t print the input texts stored in an internal docset\n" \
" -xs \t print all suffices stored in an internal docset\n" \
" -xp \t quote output patterns by a pair of \" \n" \
" -xe <name>\t output three event files: name.{pat,seq,tat} \n" \
" -e <int>\t eval: specify the evaluation function (opt mode) \n" \
"     0 : shannon entropy (*default) \t 1 : binary error\n" \
"     2 : gini index measure         \t 3 : stochastic complexity\n" \
"EXAMPLES \n" \
" wasa -k 400 -p posfile -n negfile \n" \
" wasa -m 20  doc1.txt doc2.txt doc3.txt \n" \
""

int pre_FLAG_OPTIMIZE_MODE_FREQ = 0; //for lazy setup of FLAG_OPTIMIZE_MODE

/****************************************
 * Read Options
 ****************************************/

/** Global variables:
 * The array argv[0..argc-1] is the array of the command line arguments.
 * argv[0] contains the name of the command.
 * argv[iarg] (i=1,...,argc-1) contains an argument.
 */
int   g_argc;
char  **g_argv;
int   g_iarg = 1; //the index of the current cmd line argument

void opt_set_cmdline_args(char *argv[], int argc) {
  g_argc = argc; //the length of cmd line
  g_argv = argv; //the array of cmd line
  g_iarg = 0;    //the index of the 1st cmd line argument.
}

char *nextToken() {
  if (g_iarg < g_argc)
    return g_argv[++g_iarg];
  else
    return NULL;
}

char *getToken() {
  if (g_iarg < g_argc)
    return g_argv[g_iarg]; //note: do not increment the index
  else
    error_exit("getToken: no argument remain!: %d %d\n", g_iarg, g_argc);
}

int isOptName(char *token) {
  /* note: a token T is an optname iff T = "-name", where
   * name does not start with a digit.
   * e.g., T = "-a", "-ab" are proper options, but "-", "-1" are not.
   */
  assert(token != NULL);
  return (token[0] == '-' && !isdigit(token[1]));
}

int isNumArg(char *token) {
  /* note: a token T is an numarg iff T = "[0-9]name".
   * e.g., T = "0", "12" are proper options, but "-c", "file.txt" are not.
   */
  assert(token != NULL);
  return (isdigit(token[0]));
}

int isOptArg(char *token) {
  return !isOptName(token);
}

int hasToken() {
  return (g_iarg < g_argc);
}

int hasOptArg() {
  return (g_iarg < g_argc && !isOptName(g_argv[g_iarg]));
}

int hasOptNumArg() {
  return (g_iarg < g_argc && isdigit(g_argv[g_iarg][0]));
}

void option_err(char *opt)
{
    talk_printf_msg("error: no such an option: %s\n" USAGE_STR, opt);
    talk_send_msg();
    exit(1);
}

void read_option(char *argv[], int argc,
                 Query query, DocSet docset,
                 Intarray posfiles, Intarray negfiles)
{
  char optname[64], infile[64], *token;
  opt_set_cmdline_args(argv, argc);
  nextToken(); //note: read the first argument

  while( hasToken() && isOptName((token = getToken())) ){
    //note: token is an option name like "-c"
    strcpy(optname, token);

    if (IS_FLAG_ON(query, FLAG_PRINT_OPTION))
      printf("@option: get %s\n", optname);

    nextToken();
    //note: move the pointer to the next token, which can be
    //either an argument or the next optname.

    if ( strlen(optname) == 2 ) {

      /********************
       * 1st switch: "-c" for exactly one option letters c
       ********************/
      switch( optname[1] ) {
        //note: the current token points either an argument or
        //the next optname.

      case 'p': case 'P':
        while (hasOptArg()) {
          FLAG_SET_ON(query, FLAG_OPTIMIZE_MODE);
          char *str = strdup(getToken());   //next argument: infile
          ia_push_back(posfiles, (int)str); //cast from pointer to int
          nextToken();
          if (IS_FLAG_ON(query, FLAG_PRINT_OPTION))
            printf("@option: posfile: %s\n", str);
        }
        break;

      case 'n': case 'N':
        while (hasOptArg()) {
          FLAG_SET_ON(query, FLAG_OPTIMIZE_MODE);
          char *str = strdup(getToken());   //next argument: infile
          ia_push_back(negfiles, (int)str); //cast from pointer to int
          nextToken();
          if (IS_FLAG_ON(query, FLAG_PRINT_OPTION))
            printf("@option: negfile: %s\n", str);
        }
        break;

      case 'q'://oneside occ
        if (hasOptArg()) {
          query->occ_side = atoi(getToken());
          nextToken();
        } else
          query->occ_side = +1; //default: positive side
        if (IS_FLAG_ON(query, FLAG_PRINT_OPTION))
          printf("@option: q: occ_side: %d\n", query->occ_side);
        break;

      case 'k'://top_k
        if (hasOptArg()) {
          query->top_k = atoi(getToken());
          nextToken();
        } else //default
          query->top_k = DefaultTopk;
        break;

      case 'e'://eval
        FLAG_SET_ON(query, FLAG_OPTIMIZE_MODE);
        if (hasOptNumArg()) {
          query->eval = atoi(getToken());
          nextToken();
        } else //default
          query->eval = DefaultEval;
        if (IS_FLAG_ON(query, FLAG_PRINT_OPTION))
          printf("@option: eval: %d\n", query->eval);
        break;

      case 'm'://minsup
        if (hasOptArg()) {
          query->min_sup = atoi(getToken());
          nextToken();
        } else //default
          query->min_sup = DefaultMinsup; //default
        break;

      case 'M'://minsup
        FLAG_SET_OFF(query, FLAG_FREQ_MODE);
        if (hasOptArg()) {
          query->min_sup = atoi(getToken());
          nextToken();
        } else //default
          query->min_sup = DefaultMinsup; //default
        break;

      case 'd'://word delimitors
        if (hasOptArg()) {
          char *word_dels = strdup(getToken());
          cht_add_letters(docset->word_sep_list, word_dels);
          nextToken();
        }
        break;

      case 's'://sentence delimitors
        if (hasOptArg()) {
          char *sent_dels = strdup(getToken());
          cht_add_letters(docset->sent_sep_list, sent_dels);
          nextToken();
        }
        break;

      case 'u'://encoding
        if (hasOptArg()) {
          query->encoding = atoi(getToken()); //0: no conversion, 1: all lowercase
          nextToken();
        }
        break;

      case 'v'://verbose level
        if (hasOptArg()) {
          query->print_level = atoi(getToken());
          nextToken();
        }
        break;

      case 'f': //option f: freq mode (vs. opt mode)
        pre_FLAG_OPTIMIZE_MODE_FREQ = TRUE;
        //FLAG_SET_OFF(query, FLAG_OPTIMIZE_MODE);
        //note: no need for calling nextToken()
        break;

      case 'w': //option w: wordmode (default)
        FLAG_SET_ON(query, FLAG_WORD_MODE);
        //note: no need for calling nextToken()
        break;

      case 'c': //option c: letter mode (vs. wordmode)
        FLAG_SET_OFF(query, FLAG_WORD_MODE);
        //note: no need for calling nextToken()
        break;

      case 'x': //auto echo
        FLAG_SET_ON(query, FLAG_AUTOECHO_MODE);
        //note: no need for calling nextToken()
        break;

      case 'z': //python talk version (popen2)
        FLAG_SET_ON(query, FLAG_TALKPIPE_MODE);
        //note: no need for calling nextToken()
        break;

      default:
        option_err(optname);
        break;
      } // switch
    } //if
    else {

      /********************
       * 2nd switch: more than one option letters "-abc"
       ********************/
      switch( optname[1] ) { //1st option letter
        //note: the current token points either an argument or
        //the next optname.

      case 'x':
        /* Option -xy: Experimental functions
         */
        switch( optname[2] ) { //2nd option letter

        case 'c': //option xc: show counts
          FLAG_SET_ON(query, FLAG_SHOW_COUNTS);
          //note: no need for calling nextToken()
          break;

        case 'd': //option xd: print docset
          FLAG_SET_ON(query, FLAG_PRINT_DOCSET);
          //note: no need for calling nextToken()
          break;

        case 'e': //option xe: printing event data (experimental)
          FLAG_SET_ON(query, FLAG_PRINT_EVENTS);
          if (hasOptArg()) {
            query->ev_name = strdup(getToken());
            nextToken();
          }
          else {
            query->ev_name = DefaultEventFile;
          }
          break;

        case 'q': //option xq: print query
          FLAG_SET_ON(query, FLAG_PRINT_QUERY);
          //note: no need for calling nextToken()
          break;

        case 'o': //option xo: print options
          FLAG_SET_ON(query, FLAG_PRINT_OPTION);
          //note: no need for calling nextToken()
          break;

        case 'i': //option xi:
          FLAG_SET_ON(query, FLAG_PRINT_INFILE);
          //note: no need for calling nextToken()
          break;

        case 's': //option xs: print all virtual nodes
          FLAG_SET_ON(query, FLAG_PRINT_SUFFIX);
          //note: no need for calling nextToken()
          break;

        case 'p': //option xs: decoration for pattern output
          FLAG_SET_ON(query, FLAG_PRINT_PATTERN_DEBUG);
          //note: no need for calling nextToken()
          break;

        default:
          option_err(optname);
          break;
        } //switch for option x
        break;

      default:
        option_err(optname);
        break;
      } //switch

    } //else
  } //while - main loop

  /********************
   * Reading ramining arguments
   ********************/

  while( hasToken() ) {
    //note: token is any string (expected as file names)
    strcpy(infile, getToken());

    if (IS_FLAG_ON(query, FLAG_PRINT_OPTION))
      printf("@option: infile %s\n", infile);

    char *str = strdup(infile);   //next argument: infile
    ia_push_back(posfiles, (int)str); //cast from pointer to int
    nextToken();
  }

  /********************
   * Additional Setup
   ********************/

  //talk.c: python pipe2 mode
  if (IS_FLAG_ON(query, FLAG_TALKPIPE_MODE))
    setPipeModeON();
  else
    setPipeModeOFF();

  //encoding: conversion function
  switch (query->encoding) {
  case 0:
    docset->char_convert_func = ds_convert_no_conversion;
    break;
  case 1:
    docset->char_convert_func = ds_convert_downcase_char;
    break;
  default:
    error_exit("error: no such convert_func: %d\n", query->encoding);
    break;
  } //switch

  if (pre_FLAG_OPTIMIZE_MODE_FREQ)
    FLAG_SET_OFF(query, FLAG_OPTIMIZE_MODE);
}

/****************************************
 * Main
 ****************************************/


int main(int argc, char *argv[])
{
    Intarray posfiles = ia_alloc();
    Intarray negfiles = ia_alloc();

#ifdef DEBUG_TRACE
    printf("#ALLOCATE QUERY\n");
#endif

    //Allocate global data structures
    Query query   = query_alloc();

#ifdef DEBUG_TRACE
    printf("#ALLOCATE DOCSET\n");
#endif

    DocSet docset = ds_alloc();         //Initializing docset

#ifdef DEBUG_TRACE
    printf("#READ OPTION\n");
#endif

    //Reading Options
    if (argc > 1)
      read_option(argv, argc, query, docset, posfiles, negfiles);
    else {
      printf(USAGE_STR);
      exit(0);
    }

    if (IS_FLAG_ON(query, FLAG_PRINT_QUERY)) {
#ifdef DEBUG_PRINT
      printf("@debug: FLAG_PRINT_QUERY\n");
#endif
      query_print(query);
      exit(0);
    }

#ifdef DEBUG_TRACE
    printf("#READ BUILD\n");
#endif
    //Reading Text
    ds_build(docset, query, posfiles, negfiles);

    if (IS_FLAG_ON(query, FLAG_PRINT_DOCSET)) {
#ifdef DEBUG_PRINT
      printf("@debug: FLAG_PRINT_DOCSET\n");
#endif
      ds_print(docset, stdout);
      exit(0);
    }

    if (IS_FLAG_ON(query, FLAG_PRINT_INFILE)) {
#ifdef DEBUG_PRINT
      printf("@debug: FLAG_PRINT_INFILE\n");
#endif
      ds_print_text(docset, stdout);
      ds_free(docset);
      exit(0);
    }

    if (IS_FLAG_ON(query, FLAG_PRINT_SUFFIX)) {
#ifdef DEBUG_PRINT
      printf("@debug: FLAG_PRINT_SUFFIX\n");
#endif
      ds_print_suffices(docset, query, stdout);
      ds_free(docset);
      exit(0);
    }

#ifdef DEBUG_TRACE
    printf("#DISCOVER\n");
#endif
    //Mining
    PatSet patset = NULL;
    if (IS_FLAG_ON(query, FLAG_OPTIMIZE_MODE))
      patset = discover(docset, query, visit_node_opt);
    else
      patset = discover(docset, query, visit_node_frq);


    //Output

    if (IS_FLAG_ON(query, FLAG_PRINT_EVENTS)) {
#ifdef DEBUG_TRACE
      printf("#PRINT EVENTSET\n");
#endif
      ev_print_dataset(patset, query->ev_name);
    }
    else {
#ifdef DEBUG_TRACE
      printf("#PRINT PATSET\n");
#endif
      patset_print(patset);
    }

    // Cleaning
    ds_free(docset);
    exit(0);
}

/* EOF */

