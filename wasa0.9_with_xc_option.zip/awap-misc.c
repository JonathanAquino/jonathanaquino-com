/* awap-misc.c 
 * - created by arim@ist (17UL06)
 * - subroutines called from awap-visit-opt.c and awap-visit-freq.c 
 */

#include "awap-misc.h"

/****************************************
 * Global definitions
 ****************************************/

/****************************************
 * Routines: Helper routines for contingency tables
 ****************************************/ 

/*----------------------------------------*
 * Contingency table
 *----------------------------------------*/
//          | TRUE   FALSE |
// ---------+--------------+-----         
//   MATCH  |  P1      N1  |  pm
//          |              |
//  UNMATCH |  P0      N0  |  nm
// ---------+--------------+-----
//          |  pn      nn  |

/*********************
 * Global definitions
 *********************/

static Ctable _ctable = NULL;
static int *Nary = NULL;  //Integer List sorted by QSort

/*********************
 * Implementation
 *********************/

Ctable compute_ctable(DocSet docset, int L, int R) 
{
  Ctable ctable; 
  int *Sary;
  int *Doc;
  char *ObjC;  
  Sary = docset->Sary;
  Doc  = docset->Doc;
  ObjC = docset->ObjC;

  //alloc Nary if it is empty
  if (Nary == NULL) {
	if ((Nary = (int *) malloc(docset->Num * sizeof(int))) == NULL)
	  error_exit("compute_ctable: cannot allocate Nary!\n");
  }

  //Ensure
  if (_ctable == NULL) 
    _ctable = ctable_alloc();

  ctable = _ctable;
  ctable_init(ctable);

  int i, j;
  int last;

  for(i = L, j = 0; i<=R; i++, j++)
    Nary[j] = Doc[Sary[i]]; //Irregal reuse of Nary. 
  QSort(Nary, j);

  //Compute P1 and N1: Counting unique document id's
  ctable->P1 = ctable->N1 = 0;
  last = -1;
  for(i=0; i<j; i++) 
    if (Nary[i] != last) { //Irregal reuse of Nary.
	  int cat_id = ObjC[Nary[i]];
      if (cat_id  == DS_CATID_POS )
		  ctable->P1++;
      else if (cat_id == DS_CATID_NEG )
		  ctable->N1++;
	  else
		error_exit("compute_ctable: no such a cat_id: %d\n", cat_id);
      last = Nary[i]; //Irregal reuse of Nary. 
    }

  //Compute P0 and N0 
  ctable->P0 = docset->Posnum - ctable->P1;
  ctable->N0 = docset->Negnum - ctable->N1;
  return ctable;
}    

/****************************************
 * binary search (1/20/99)     
 ****************************************/ 

int stringcmp(char *key, char *text)
{
    int i;
    for (i=0; i < strlen(key); key++, text++) 
	if (*key != *text)
	    return (*key) - (*text);
    return 0;
}

int find_left(char *Text, int *A, int *Sary, char *key, int LEFT, int RIGHT)
{
    int L,R,M;
    if (stringcmp(key, &Text[A[Sary[LEFT]]]) <= 0)
	return LEFT;
    if (stringcmp(key, &Text[A[Sary[RIGHT]]]) > 0)
	return RIGHT+1;
    L = LEFT; R = RIGHT;
    while(R-L > 1) {
	M = (L+R) / 2;
	if (stringcmp(key, &Text[A[Sary[M]]]) <= 0)
	    R = M;
	else 
	    L = M;
    }
    return R;
}

int find_right(char *Text, int *A, int *Sary, char *key, int LEFT, int RIGHT)
{
    int L,R,M;
    if (stringcmp(key, &Text[A[Sary[LEFT]]]) < 0)
	return LEFT-1;
    if (stringcmp(key, &Text[A[Sary[RIGHT]]]) >= 0)
	return RIGHT;
    L = LEFT; R = RIGHT;
    while(R-L > 1) {
	M = (L+R) / 2;
	if (stringcmp(key, &Text[A[Sary[M]]]) >= 0)
	    L = M;
	else 
	    R = M;
    }
    return L;
}

void binary_itrval_search(char *Text, int *A, int *Sary, 
			  char *key, int n, int *L, int *R)
{
  if (strncmp(key, "", 1)==0) { 
    *L = 0; *R = n-1;
  } else {
    *L = find_left(Text, A, Sary, key, 0, n-1);
    *R = find_right(Text, A, Sary, key, 0, n-1);
  }
}

/****************************************
 * Routines
 ****************************************/ 

void vs_debug_report_trimming(DocSet docset, int L, int R, int H, int H0) {
  static Charray ca = NULL;
  static Charray da = NULL;
  if (ca == NULL)		ca = ca_alloc();
  if (da == NULL)		da = ca_alloc();
  ca_make_null(ca);
  ca_make_null(da);
  ds_retrieve_substr(docset, ca, L, H);
  ds_retrieve_substr(docset, da, L, H0);
  printf("@insert %d:%d:%d:%d", L, R, H, H0);
  printf("\t[%.*s] <- [%.*s]\n", ca->len, ca->val, da->len, da->val);
}


/* EOF */

