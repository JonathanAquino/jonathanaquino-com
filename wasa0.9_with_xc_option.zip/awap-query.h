#ifndef ___query___
#define ___query___

/****************************************
 * awap-query.c -- patterns and queues
 * - created by arim@ist (15JUL06)
 * - modified based on awap-pat.c on 30 JUL 2005 by arim@ist
 ****************************************/

#include "awap-ctable.h"
//#include "awap-eval.h"

/****************************************
 * Macros
 ****************************************/

// Default values for Query
#define MAXBYTE 256	//for STRBUF
#define ON   (1)
#define OFF  (0)

//Encoding
#define ENCODE_NONE    (0)
#define ENCODE_LOWER   (1)

#define DefaultTopk   400
#define DefaultEval   2
#define DefaultMinsup 5 //Minsup
#define DefaultSide  +1  //Target side
#define DefaultFlgW  ON  //Proper Word boundary: on
#define DefaultFlgB  ON //Both Branching: on
#define DefaultFlgL  OFF //Both Branching: on
#define DefaultEncoding ENCODE_LOWER //Encoding Conversion of characters
#define DefaultEventFile ("_out") //

/* flags */
#define IS_FLAG_ON(Q, FLAG)  (((Q)->flag & (FLAG)) > 0)
#define FLAG_SET_ON(Q, FLAG)  ((Q)->flag = ((Q)->flag | (FLAG)))
#define FLAG_SET_OFF(Q, FLAG) ((Q)->flag = ((Q)->flag & ~(FLAG)))

#define FLAG_NULL  (0)
#define FLAG_WORD_MODE (1 << 0)	//Option: conserving word boundary
#define FLAG_BOTH_SIDE (1 << 1)	//Option: branching word both sides
#define FLAG_PRINT_LOC (1 << 2)	//Option: printing location lists
#define FLAG_AUTOECHO_MODE (1 << 3)	//Option: useAutoEchoMode
#define FLAG_TALKPIPE_MODE (1 << 4)	//Option: useTalkPipe (python talk mode)
#define FLAG_PRINT_INFILE (1 << 5)	//Option: printing input files and stop
#define FLAG_PRINT_SUFFIX (1 << 6)	//Option: printing all suffixes and stop
#define FLAG_PRINT_QUERY  (1 << 7)	//Option: printing input files and stop
#define FLAG_PRINT_DOCSET (1 << 8)	//Option: printing the statistics of docset
#define FLAG_FREQ_MODE (1 << 9)	//Option: output all substrings satisfying minsup
#define FLAG_PRINT_OPTION (1 << 10)	//Option: printing options
#define FLAG_PRINT_PATTERN_DEBUG (1 << 11)	//Option: decorate pattern output
#define FLAG_OPTIMIZE_MODE (1 << 12)	//Option: use optimization (default off)
#define FLAG_PRINT_EVENTS (1 << 13)	//Option: print a event data for further processing
#define FLAG_SHOW_COUNTS (1 << 14)	//Option: display counts (frq mode)

/* */
#define IS_DELIMITOR_CHAR(Q, C) ((Q)->_delim_array[(C)])

/****************************************
 * Types
 ****************************************/

/** struct Query. A set of parameter values specifying a user query for pattern discovery.
 */

typedef struct _Query {

    //Boolean flag. See above macros
    int flag;

    ///Evaluation function type
    int eval;

    ///Maximum number of answers
    int top_k;

    /// A minimum support threshold for the frequecy
    int min_sup;

    /// A flag determining if output only positive patterns
    int occ_side;

    /// specify the level of output
    int print_level;

    /// specify the conversion
    int encoding;

    /// specify the matrix name for evfile-mode
    char *ev_name;


} QUERY, *Query;

/****************************************
 * Externs: functions and global varialbles
 ****************************************/

extern QUERY *query_alloc();
extern void query_free(QUERY *);
extern void query_print(Query query);
extern void query_set_boolean_flag(Query query, int flag, int value);

#endif
