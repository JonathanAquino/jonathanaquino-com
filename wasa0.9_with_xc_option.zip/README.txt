#README.txt  17 JULY 2006, arim@ist.hokudai.ac.jp

wasa.exe
- a text mining program using suffix arrays for finding substrings
(word phrases) in collections of positive and negative documents 
...............................................................
INSALL 

Requirements:
on linux/unix: gcc, make 
on windows   : cygwin, gcc, make 

Compilation: 
To compile, just type the following at the top directory:
% make all
To run, Just type: 
%  awap -p data/ship_pos1000.txt -n data/ship_neg1000.txt -w -e
To invoke python GUI, type on cygwin
% python ashell.py

...............................................................
HELP

wasa: a text mining program using suffix arrays for finding
substrings (phrases) in collections of documents.
2001 - 2006, Hiroki Arimura, Toru Kasai. All right reserved. 

wasa.exe	- a text mining program 

USAGE: frequent substring mining
 wasa OPTIONS file1 ... fileN 

USAGE: optimal substring mining minimizing the eval-function (e.g.,entropy)
 wasa OPTIONS -p posfile1 ...  -n negfile1 ... OPTIONS
 default setting: -k 400 -m 2 -w -q +1 -u 1 -d " -'" -s ",:;.?!|\"()[]{}<>" 

OPTIONS
 -p <files> 	 pos:  specify positive file names (opt mode) 
 -n <files> 	 neg:  specify negative file names (opt mode) 
 -k <value> 	 topk: specify the number of top-K patterns (opt mode)
 -m <value> 	 minsup: specify minimum support (frq and opt mode)
 -w         	 word mode  : build word-based suffix arrays (default)
 -c         	 letter mode: surpress word-mode
 -q <int>   	 side: specify the target side: +1 (pos), 0 (both), -1 (neg) 
 -f         	 frqmode: insist frequency mode even with -p and -n
 -u <int> 	 set the conversion mode for input characters
     0	 no conversion, 1	 lowercase(default)
 -d "<string>"	 set the word delimtors as string. e.g., -d "-+_" 
 -s "<string>"	 set the sentence delimtors as string, e.g., -s ":,.!?()"
    all sentence delimitors are automatically included in word delimitors. 
 -v <level> 	 verbose: set the printing level (default 0)

OPTIONS (experimental)
 -e <int>   	 eval: specify the evaluation function (opt mode) 
     0 : shannon entropy (*default) 	 1 : binary error
     2 : gini index measure         	 3 : stochastic complexity
     4 : (inverse) frequency
 -xc     print counts (frq mode)
 -xd 	 print the statistics of arrays/docset
 -xq 	 print the query setting
 -xo 	 print options (to put at the beginning of options) 
 -xi 	 print the input texts stored in an internal docset
 -xs 	 print all suffices stored in an internal docset
 -xp 	 quote output patterns by a pair of " 

 EXAMPLES 
 wasa -k 400 -p posfile -n negfile 
 wasa -m 20  doc1.txt doc2.txt doc3.txt 

...............................................................
For details, to see Makefile
Let's enjoy!
Hiroki Arimura
---


Added -xc option [Jon Aquino 2009-05-25]