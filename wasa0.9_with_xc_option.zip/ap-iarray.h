/*
 * ap-iarray.h
 * $Id: ap-iarray.h,v 1.1.1.1 2006/07/20 12:24:20 arim Exp $
 */

#ifndef INCLUDED_AP_IARRAY
#define INCLUDED_AP_IARRAY

/******************************************************************
 * Macros
 ******************************************************************/

#ifndef _REPO_IA_DEFINED_
#define REPO_IA(ANAME)  ({printf("\t" #ANAME ":");  ia_report(ANAME);})
#define _REPO_IA_DEFINED_
#endif

/******************************************************************
 * Types
 ******************************************************************/

typedef 
struct _int_array {
  int *val;  /* array of integers */
  int  len;  /* the length of the array */
  int  maxlen;  /* the length of the allocated array */
} *IntArray, *Intarray;

/* Note: Intarray is a pointer to a struct. */

typedef
IntArray Intstack; 

/******************************************************************
 * Functions
 ******************************************************************/

extern IntArray ia_alloc(void); 
extern void ia_free(IntArray temp);
extern void ia_make_null(IntArray tmp); 
extern void ia_realloc(IntArray ia, int size); 
extern void ia_assert_defined(IntArray ia); 

extern int ia_get(IntArray ia, int i);
extern int ia_put(IntArray ia, int i, int value);
extern int  ia_last_val(IntArray ia); 
extern void ia_add(IntArray ia, int x); 
extern void ia_append(IntArray ia, IntArray ib); 

extern void ia_copy(IntArray ia, IntArray ib); 
extern void ia_ncopy(IntArray ia, IntArray ib, int len); 
extern void ia_copy_slice(IntArray ia, IntArray ib, int beg, int end); 
extern int  ia_is_equal(IntArray ia, IntArray ib); 
extern int ia_is_null(Intstack ia);

extern void ia_fill(IntArray ia, int len, int x); 
extern void ia_fill_inc(IntArray ia, int len); 
extern void ia_fill_random(IntArray ia, int len); //wrapper 

extern void ia_print(IntArray ia);
extern void ia_print_nl(); 
extern void ia_report(IntArray ia); 
extern void ia_report_colwidth(IntArray ia, int colwidth); 

/* Counting */
extern void ia_map(IntArray ia, IntArray ib); 
extern void ia_count(IntArray ia, IntArray count, int num_labels); 
extern void ia_scalar_add(IntArray ia, int x); 

/* Stack */
extern Intstack ia_stack_alloc(void);
extern void ia_stack_free(Intstack tmp);
extern void ia_push(Intstack ia, int x);
extern int ia_pop(Intstack ia);
extern int ia_top(Intstack ia);
extern int ia_is_empty(Intstack ia);

/* Disk I/O */
extern int ia_write_disk(IntArray ia, char *outname); 
extern int ia_read_disk(IntArray ia, char *inname); 
extern int ia_remove_disk(char *filename);
extern int ia_veryfy_disk(IntArray ia, char *file_name); 

/* Interface to C-int-array */
extern IntArray ia_append_C_int_append(IntArray ia, int *array, int len); 
extern IntArray ia_import_from_C_int_array(IntArray ia, int *array, int len); 
extern void ia_export_to_C_int_array(IntArray ia, int *array, int len); 

/******************************************************************
 * Comments
 ******************************************************************/

#endif

