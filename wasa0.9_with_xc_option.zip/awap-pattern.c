/* awap-pattern.c
 * - created by arim@ist (15JUL06)
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "awap.h"
#include "awap-docset.h"
#include "awap-pattern.h"
#include "awap-poslist.h"
#include "talk.h"

#undef DEBUG_SIDE

/****************************************
 * Global definitions
 ****************************************/

static DocSet g_docset = NULL;

void pattern_initialize(DocSet docset) {
  g_docset = docset;
}

/****************************************
 * Pattern:
 ****************************************/

/** Create an empty pattern
    @author arim@ist.hokudai.ac.jp
 */
Pattern pattern_alloc() {
    Pattern tmp = NULL;
    if ((tmp = (Pattern) malloc(sizeof(struct _pattern))) == NULL)
        error_exit("pattern_create: cannot allocate memory.\n");
    tmp->L     = -1;
    tmp->H     = -1;
    tmp->str   = NULL;
    tmp->eval  = 1.0L; //maximum
    tmp->ctable= NULL;
    tmp->list  = NULL;
    tmp->next  = NULL;
    return tmp;
}

/** Create a new pattern from the environment variables of awap-discover
    @param words the list of substrings in a text
    @param D     the maximum number of substrings
    @param dim   the current number of substrings
    @param ctable the contingency table (frequecy table) of the pattern
    @param eval  the score of the pattern
    @return the created pattern
    @author arim@ist.hokudai.ac.jp
 */
Pattern pattern_create(int L, int H, Ctable ctable, double eval)
{
    Pattern tmp = pattern_alloc();
    tmp->L = L;
    tmp->H = H;
    tmp->ctable = ctable;
    tmp->eval   = eval;
    tmp->next   = NULL;
    return tmp;
}

/** Delete a pattern
    @author arim@ist.hokudai.ac.jp
 */
void pattern_free(Pattern pat) {
  free((Pattern) pat);
}


/****************************************
 * Routines
 ****************************************/

double pattern_ratio_pos(Pattern pat) {
    return ctable_ratio_pos(pat->ctable);
}

double pattern_ratio_neg(Pattern pat) {
    return ctable_ratio_neg(pat->ctable);
}


void pattern_print_axis(Query query) {
  if (query->print_level >= 2) {
    talk_printf_msg("@stat %3s %5s %4s %5s %4s %5s %s\n",
                    "id", "eval", "P1", "N1", "p1\%", "n1\%", "<pattern>");
    talk_send_msg();
  }
}

/** Print the information of a pattern with pid
    @param pat the pattern to print
    @param pid the specified id of the pattern
    @param docset the underlying docset
    @author arim@ist.hokudai.ac.jp
 */

void pattern_print(Pattern pat, int pid, Query query) {
    int pnum, nnum;
    static Charray ca = NULL;
    if (ca == NULL)
      ca = ca_alloc();
    ds_retrieve_substr(g_docset, ca, pat->L, pat->H);

    pnum = pat->ctable->P1 + pat->ctable->P0;
    nnum = pat->ctable->N1 + pat->ctable->N0;

    //output
    if (query->print_level >= 2) {
      talk_printf_msg("@patt %3d %6.5f ",
                      pid, pat->eval);
    }

    if (query->print_level >= 1) {
      talk_printf_msg("%d:%d:%.1f:%.1f:",
                    pat->ctable->P1,
                    pat->ctable->N1,
                    pattern_ratio_pos(pat)*100.0,
                    pattern_ratio_neg(pat)*100.0);
      talk_printf_msg("%d:", pat->H);
// 	  talk_printf_msg("%4d:%4d:%4.1f:%4.1f:",
// 					pat->ctable->P1,
// 					pat->ctable->N1,
// 					pattern_ratio_pos(pat)*100.0,
// 					pattern_ratio_neg(pat)*100.0);
    }

    if (IS_FLAG_ON(query, FLAG_PRINT_PATTERN_DEBUG)) {
      talk_printf_msg("\"%.*s\"\n", ca->len, ca->val);// pattern string
    }
    else {
      talk_printf_msg("%.*s\n", ca->len, ca->val);// pattern string
    }

    talk_send_msg();

    //option: usePosList
    if (IS_FLAG_ON(query, FLAG_PRINT_LOC)) {
      if (pat->list == NULL)
        return;
      PosList list = pat->list;
      talk_printf_msg("@list ");
      int i;
      for (i = 0; i < list->len; i++) {
        talk_printf_msg("%d ", list->val[i]);
      }
      talk_printf_msg("\n");
      talk_send_msg();
    }
}

int pattern_isPosSide(Ctable ctable, Query query) {
    int side = query->occ_side;
    //side is +1, 0, or -1
    double delta
        = ctable_ratio_pos(ctable) - ctable_ratio_neg(ctable);
#ifdef DEBUG_SIDE
    printf("debug: pattern_isPosSide: side=%d delta=%f, OK=%d\n",
           side, delta, (delta * side > 0));
#endif
    return (delta * side > 0);
}


/* EOF */

