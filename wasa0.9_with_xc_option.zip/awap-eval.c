

//===============================================//
//                                                //
//   Evaluation   (1/17/99)                      //
//                                              //
//===============================================//

#include <stdlib.h>
#include "awap-eval.h"

int eval_get_eid(char *name) {
	int eid = FUNC_ENTROPY; //eval id

	if (is_cmd_match(name, "bin") ||
		is_cmd_match(name, "class"))
		eid = FUNC_BINERR;
	else if (is_cmd_match(name, "ent") ||
			 is_cmd_match(name, "entropy"))
		eid = FUNC_ENTROPY;
	else if (is_cmd_match(name, "gini")||
			 is_cmd_match(name, "giniidx"))
		eid = FUNC_GINIIDX;
	else if (is_cmd_match(name, "sc")||
			 is_cmd_match(name, "mdl"))
		eid = FUNC_SC;
	else if (is_cmd_match(name, "freq")||
			 is_cmd_match(name, "invfreq"))
		eid = FUNC_INVFREQ;
	else 
		ERREXIT("eval_get_eid: no such eval name\n");
	return eid; 
}

double eval_compute(QUERY *Query, Ctable CTABLE) {
	double measure; 
	if (Query->eval == FUNC_BINERR)        
		measure = minimum_class_err(CTABLE);
	else if (Query->eval == FUNC_ENTROPY)
		measure = minimum_entropy(CTABLE);
	else if (Query->eval == FUNC_GINIIDX) 
		measure = minimum_gini(CTABLE);              
	else if (Query->eval == FUNC_INVFREQ)
		measure = minimum_invfreq(CTABLE); 
	else if (Query->eval == FUNC_SC)   
		measure = minimum_sc(CTABLE);
	else
		ERREXIT("discover: no such eval\n");
	return measure;
}    



/* 
 * Minimum inberse frequency
 * - new version: zero-division error is fixed (?), 17 May 99 by arim.
 */

static void get_counts(Ctable ctable, int *_n, int *_n1, int *_n0, int *_m0, int *_m1) {
	int n, n1, n0, m0, m1;
	n1 = ctable->P1 + ctable->N1;		/* examples in S_1 */
	n0 = ctable->P0 + ctable->N0;		/* examples in S_0 */
	n  = n1 + n0;	                	/* all examples */

	m1 = ctable->P1;	/* positive examples in S_1 */
	m0 = ctable->P0;	/* positive examples in S_0 */
	*_n = n;
	*_n1 = n1;
	*_n0 = n0;
	*_m0 = m0;
	*_m1 = m1;
}

static void make_smooth(int *_n1, int *_n0, int *_m0, int *_m1) {
	int n1 = *_n1, n0 = *_n0, m0 = *_m0, m1 = *_m1;
	if (m1 == 0) {
		m1 = m1 + 1;
		n0 = n0 - 1;
	}
	if (m0 == 0) {
		m0 = m0 + 1;
		n1 = n1 - 1;
	}
	*_n1 = n1;
	*_n0 = n0;
	*_m0 = m0;
	*_m1 = m1;
}

double minimum_invfreq(Ctable ctable)
{
  int n, n1, n0, m0, m1;
  double measure;

  get_counts(ctable, &n, &n1, &n0, &m0, &m1);

  make_smooth(&n1, &n0, &m0, &m1);

  if (n <= 0) {
    printf("error: minimum_entropy\n");
    exit(1);
  }
  if (n1<= 0) 
    measure = 1.0;
  else {
    measure = (double)1.0 /(double) n1;
  }
  return measure;
}

/* 
 * Minimum class error
 * - new version: zero-division error is fixed (?), 17 May 99 by arim.
 */
double class_err_term(int m, int n) 
{ /* Def: class_err_term(M_i,N_i) = N_i*psi(M_i/N_i)
   *      = N_i* min(M_i/N_i, 1-M_i/N_i)
   *      = M_i (if M_i/N_i <= 1/2) and N_i - M_i if (if M_i/N_i > 1/2).
   */
  if (m <= 0 || n - m <= 0) return 0;
  else {
    if (2*m <= n)	/* (M_i/N_i <= 1/2) */
      return m;
    else        	/* (M_i/N_i > 1/2) */
      return n - m;
  }
}

double minimum_class_err(Ctable ctable)
{
  int n, n1, n0, m0, m1;
  double class_error;

  get_counts(ctable, &n, &n1, &n0, &m0, &m1);

  make_smooth(&n1, &n0, &m0, &m1);

  if (n <= 0) {
    printf("error: minimum_entropy\n");
    exit(1);
  } else {
    class_error = (class_err_term(m0,n0) + class_err_term(m1,n1))/(double) n;
    return class_error;
  }
}

/* 
 * Minimum entropy: 
 * - new version: zero-division error is fixed (?), 17 May 99 by arim.
 */
double ent_term(int m, int n) 
{ /* Def: entterm(M,N) = N*psi(M/N)
   *      = N*(-(M/N) log (M/N) -((N - M)/N) log ((N - M)/N))
   *      = -M log (M/N) + -(N-M) log ((N-M)/N))
   *      = M (log N - log M) + (N-M) (log N - log (N-M))
   */
    double ent;
	double pos_ent, neg_ent; 
    if (m <= 0 || n - m <= 0) {
		ent = 0;
	}
    else {
		pos_ent = (double) m * (log(n) - log(m));
		neg_ent = (double) (n-m) * (log(n) - log(n-m));
		ent = pos_ent + neg_ent;
	}
    /* else return m * (log(n) - log(m)); */
    return ent;
}


double minimum_entropy(Ctable ctable)
{
  int n, n1, n0, m0, m1;
  double entropy;

  get_counts(ctable, &n, &n1, &n0, &m0, &m1);

  //smoothing
  make_smooth(&n1, &n0, &m0, &m1);

  if (n <= 0) {
    printf("error: minimum_entropy\n");
    exit(1);
  } else if (n1 <= 0) {
      return 1.0L; 
  }
  else {
    entropy = (ent_term(m0,n0) + ent_term(m1,n1)) /(double) n;
    return entropy;
  }
}

/* 
 * Minimum gini index
 * - new version: zero-division error is fixed (?), 17 May 99 by arim.
 */
double gini_term(int m, int n) 
{ /* Def: entterm(M_i,N_i) = N_i*psi(M_i/N_i)
   *      = N_i*(-(M_i/N_i) log (M_i/N_i))
   */
  if (m <= 0 || n - m <= 0) return 0;
  else return 2* (n - m)* m /n;
}

double minimum_gini(Ctable ctable)
{
  int n, n1, n0, m0, m1;
  double gini_index;

  get_counts(ctable, &n, &n1, &n0, &m0, &m1);

  make_smooth(&n1, &n0, &m0, &m1);

  if (n <= 0) {
    printf("error: minimum_entropy\n");
    exit(1);
  } else {
    gini_index = (gini_term(m0,n0) + gini_term(m1,n1))/(double) n;
    return gini_index;
  }
}

/* SC: stochastic complexity of Rissanen */

#define PI (3.141516)

double sc_term(int m, int n) 
{
    return ent_term(m, n) + 0.5*(log(n) - log(2*PI)) + log(PI);
}

double minimum_sc(Ctable ctable)
{
  int n, n1, n0, m0, m1;
  double sc;

  get_counts(ctable, &n, &n1, &n0, &m0, &m1);
  make_smooth(&n1, &n0, &m0, &m1);

  int m_all, m_plus, ms1, ms1_plus, ms0, ms0_plus;
  m_all    = n;       //num of all documents (pos docs + neg docs)
  m_plus   = m0 + m1; //num of positive documents
  ms1      = n1;      //num of matched docs
  ms1_plus = m1;      //num of matched positive docs
  ms0      = n - ms1; //num of un-matched docs
  ms0_plus = m_plus - ms1_plus; //num of unmatched positive docs

  //smoothing

  if (n <= 0) {
    printf("error: minimum_sc\n");
    exit(1);
  } else if (n1 <= 0) {
      return 1.0L; 
  }
  else {
	  sc = (sc_term(ms1_plus, ms1) + sc_term(ms0_plus, ms0))/(double) n;
	  return sc;
  }
}

/* EOF */
