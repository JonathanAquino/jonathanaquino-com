#ifndef ___file___
#define ___file___

/* 
 * awap-file.c -- template for awap programs
 * - modified based on awap-pat.c on 30 JUL 2005 by arim@ist
 * - created by arim@i (06/09/2005)
 */

#include "awap.h"
#include "awap-docset.h"

/*
 * Macros
 */

/*
 * Types 
 */ 

/*
 * Externs: functions and global varialbles 
 */ 

/** Reading an input file into an existing docset.
	After all input files are read, ds_build must be explictly
	called for docset.
	@param docset
	@param input file name
	@param category id (1 and 0 for pos and neg, resp.)
	@retern none
	@author arim@ist.hokudai.ac.jp
 */
extern void tx_read_text(DocSet docset, char *infile, int cid);
extern void tx_print_suffix(DocSet docset, int idx, int maxlen);

#endif 
