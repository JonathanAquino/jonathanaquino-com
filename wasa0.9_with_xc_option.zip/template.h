#ifndef ___templ___
#define ___templ___

/* 
 * awap-templ.c -- template for awap programs
 * - modified based on awap-pat.c on 30 JUL 2005 by arim@ist
 * - created by arim@i (dd/mm/yy)
 */

#include "awap.h"

/*
 * Macros
 */

/*
 * Types 
 */ 

/*
 * Externs: functions and global varialbles 
 */ 

#endif 
