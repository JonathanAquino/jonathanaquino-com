#ifndef ___cmds___
#define ___cmds___

/* 
 * awap-cmds.c -- template for awap programs
 * - modified based on awap-pat.c on 30 JUL 2005 by arim@ist
 * - created by arim@i (dd/mm/yy)
 */

#include "awap.h"
#include "awap-patset.h"

/*
 * Macros
 */

/*
 * Types 
 */ 

/*
 * Externs: functions and global varialbles 
 */ 

extern void command_find(int argc, char *argv[], DocSet docset, QUERY *query, PatSet *patset_ptr); 
extern void command_side(int  argc, char *argv[], DocSet docset, Query query); 
extern void command_print(int  argc, char *argv[], DocSet docset, QUERY *query); 

extern void command_show_doc(int  argc, char *argv[], DocSet docset); 
extern void command_context_pat(int  argc, char *argv[], DocSet docset, PatSet *patset_ptr); 
extern void command_context_doc(int  argc, char *argv[], DocSet docset); 

#endif 
