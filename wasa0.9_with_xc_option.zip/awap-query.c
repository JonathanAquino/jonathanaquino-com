/*
 * awap-query.c -- patterns and queues
 * - modified based on awap-pat.c on 30 JUL 2005 by arim@ist
 * - created by arim@i (24/05/99)
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "awap.h"
#include "awap-query.h"
#include "awap-pattern.h"

/*----------------------------------------*
 * Query
 *----------------------------------------*/

#undef  DEBUG_COMM
#undef DEBUG_DELIM

//  char *first_word;
//  int d; 	//Dimension (the maximum number of subwords)
//  int k;	//Proximity (the maximum gap length)
//  int eval;	//Evaluation function type
//  int flag_propword; //Option: complete word boundary
//  int flag_exactdim; //Option: complete word boundary

Query query_alloc()
{
  Query query;
  if ((query = (Query) malloc(sizeof(struct _Query))) == NULL)
    error_exit("query_create: cannot allocate memory!\n");

  query->eval     = DefaultEval; 		// Evaluation type in {0, 1, 2, ...}
  query->top_k    = DefaultTopk;   	// max number of best answers
  query->min_sup  = DefaultMinsup;  //default
  query->occ_side = DefaultSide;    //default: positive
  query->print_level = 0;
  query->flag     = FLAG_NULL;      //empty bit flag
  query->encoding = ENCODE_LOWER;   //default: lowercase
  query->ev_name  = DefaultEventFile;

  //default flags
  query_set_boolean_flag(query, FLAG_WORD_MODE, ON);
  query_set_boolean_flag(query, FLAG_BOTH_SIDE, ON);
  query_set_boolean_flag(query, FLAG_PRINT_LOC, OFF);
  query_set_boolean_flag(query, FLAG_PRINT_INFILE, OFF);
  query_set_boolean_flag(query, FLAG_PRINT_SUFFIX, OFF);
  query_set_boolean_flag(query, FLAG_AUTOECHO_MODE, OFF);
  query_set_boolean_flag(query, FLAG_TALKPIPE_MODE, OFF);
  query_set_boolean_flag(query, FLAG_OPTIMIZE_MODE, OFF);

  return query;
}

void query_free(Query query)
{
  free(query);
}

void query_print(Query query) {
    printf("query:\t#%d\n", query);
    printf("  eval  \t%d\n", query->eval);
    printf("  top_k  \t%d\n", query->top_k);
    printf("  min_sup\t%d\n", query->min_sup);
    printf("  occ_side\t%d\n", query->occ_side);
    printf("  print_level\t%d\n", query->print_level);
    if (query->ev_name != NULL)
      printf("  ev_name\t%s\n", query->ev_name);
    //printf("  delim_letters\t%d\n", query->delim_letters);
    printf("  FLAG_WORD_MODE\t%d\n", IS_FLAG_ON(query, FLAG_WORD_MODE));
    printf("  FLAG_BOTH_SIDE\t%d\n", IS_FLAG_ON(query, FLAG_BOTH_SIDE));
    printf("  FLAG_PRINT_LOC\t%d\n", IS_FLAG_ON(query, FLAG_PRINT_LOC));
    printf("  FLAG_PRINT_INFILE\t%d\n", IS_FLAG_ON(query, FLAG_PRINT_INFILE));
    printf("  FLAG_PRINT_SUFFIX\t%d\n", IS_FLAG_ON(query, FLAG_PRINT_SUFFIX));
    printf("  FLAG_AUTOECHO_MODE\t%d\n", IS_FLAG_ON(query, FLAG_AUTOECHO_MODE));
    printf("  FLAG_TALKPIPE_MODE\t%d\n", IS_FLAG_ON(query, FLAG_TALKPIPE_MODE));
    printf("  FLAG_PRINT_EVENTS\t%d\n", IS_FLAG_ON(query, FLAG_PRINT_EVENTS));
    printf("\n");
}

void query_set_boolean_flag(Query query, int flag, int value) {
  if (value > 0)
    FLAG_SET_ON(query, flag);
  else if (value == 0)
    FLAG_SET_OFF(query, flag);
  else
    error_exit("no such a flag value!: flag=%d value=%d\n", flag, value);
}

/* EOF */
