#ifndef ___estack___
#define ___estack___ 

/**************************************** 
 * awap-estack.h -- 
 * - created by arim@ist (15JUL06)
 ****************************************/

#include "awap-docset.h"

/****************************************
 * Macros
 ****************************************/

#define UNDEF (-1)

#define MAKENULL(S) {(S)->top = -1;}
#define TOP(S) (&((S)->val[(S)->top]))
#define POP(S) {(S)->top--;}
#define PUSH(S, e) {(S)->val[++((S)->top)] = e;}

/****************************************
 * Types 
 ****************************************/ 

typedef struct _intpair {
    int left; //L
    int hgt;  //H
} IntPairCell, *IntPair;

typedef struct _estack {
  int maxlen; //number of allocated cells
  int top;    //top index
  IntPairCell *val; //an array of elements (not pointers of elements)
} *Stack;

/****************************************
 * Externs: functions and global varialbles 
 ****************************************/ 

extern IntPair ip_alloc(void); 
extern IntPair ip_create(int left, int hgt); 


extern Stack stack_alloc(int maxlen); 
extern int stack_is_empty(Stack s); 
extern IntPair stack_top(Stack s); 
extern void stack_pop(Stack s); 
extern void stack_push(Stack s, IntPair ip); 
extern void stack_makenull(Stack s); 

#endif 


