#ifndef ___strarray___
#define ___strarray___

/* 
 * awap-strarray.c -- a wrapper class for IntArray as array of strings
 * where a pointer to string is treated as an int value.
 * created by arim@i (dd/mm/yy)
 */

#include "awap.h"
#include "ap-iarray.h"

/*
 * Macros
 */

/*
 * Types 
 */ 
typedef IntArray StrArray;

/*
 * Externs: functions and global varialbles 
 */ 

extern char *sa_get(StrArray sa, int index); 

extern void sa_add(StrArray sa, char *str); 

extern void sa_put(StrArray sa, int index, char *str); 

#endif 
