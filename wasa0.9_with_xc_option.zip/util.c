/******************************************************************
 * 20 SEP 99 by arim@i.kyushu-u.ac.jp.
 * ap-util.c
 * -- general utilities 
 * $Id: util.c,v 1.1.1.1 2006/07/20 12:24:20 arim Exp $
 ******************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <limits.h>
#include <math.h>   /* for pow() and log() */
#include <assert.h> 
#include "ap-util.h"
#include "ap-iarray.h" /* for stack operators */

int    g_rptctr;
int    g_printflg = 0, g_rept = 1;
time_t g_starttime, 
       g_time;

/*
 * debug print
 */
static
Intstack g_debug_stack = NULL; /* The stack for debugging flags */

/******************************************************************
 * General utilities
 ******************************************************************/

/* replacement for ERREXIT by Kasai */
void error_exit(char *fmt, ...)
{ /* modification of minprintf in K&R. See pp307 of K&R 2nd in detail. */
  /* this is exactly same as printf() builtins except exit when called */
  va_list ap;
  char *p, *sval;
  int ival;
  double dval;

  fprintf(stdout, "@error: ");
  /* simulate printf function using minprintf() from K&R */
  va_start(ap, fmt);
  vfprintf(stdout, fmt, ap);	/* processing argumnt list */
  va_end(ap);			/* clean up when finished */
  fflush(stdout);
  exit(1);
}

void old_error_exit(char *message)
{
    fprintf(stdout, "@error: %s\n", message);
    exit(1);
}

/*
 * A debugging utilities: debug()
 * - a replacement of printf() with a debugging switch g_debug, which has
 *   either ON or OFF as its state flag. 
 */

/* 
 * debugging flag
 */

extern void debug_off(void); 

void debug_init(void)
{   /* initialize a global stack */
    if (g_debug_stack == NULL)
      g_debug_stack = ia_stack_alloc();
    ia_make_null(g_debug_stack);
    ia_push(g_debug_stack, OFF); 
}

void debug_free(void)
{   /* initialize a global stack */
    ia_stack_free(g_debug_stack);
}

void debug_push(int newval) {
    ia_push(g_debug_stack, newval);
}
int debug_pop(void)
{
    return ia_pop(g_debug_stack);
}

void debug_on(void)
{
    debug_init();
    debug_push(ON);
}
void debug_off(void)
{
  debug_init();
  debug_push(OFF);
}

int  debug_get(void)
{
  assert(! ia_is_empty(g_debug_stack));
  return ia_top(g_debug_stack);
}

int  debug_report(void)
{
  printf("g_debug_stack: "); ia_report(g_debug_stack);
}

/* 
 * print routine
 */

void debug(char *fmt, ...)
{ /* - prints its arguments as by printf only when debug flag is ON.
   * with appending prefix "@debug: " in the beginning of a line. 
   * - this routine is a modification of minprintf in the textbook K&R C 
   * ("program languages C", Kernighan and Ritchie, 2nd edition, pp. 307).
   */

  va_list ap;
  char *p, *sval;
  int ival;
  double dval;

  if (debug_get() == ON) {
      /* Add a prefix */
      fprintf(stdout, "@debug: ");

      /* The following code simulate printf function as in minprintf() of K&R
       */
      va_start(ap, fmt);
      vfprintf(stdout, fmt, ap); /* processing argumnt list */
      va_end(ap);	 /* clean up when finished */
      fflush(stdout);
      
  } else {
      /* Non-debugging */
      ;	/* do nothing */
  }
}

void debug_printf(char *fmt, ...)
{ /* modification of minprintf in K&R. See pp307 of K&R 2nd in detail. */
  /* this is exactly same as printf() builtins except executed only when debug flag is on. */
  va_list ap;
  char *p, *sval;
  int ival;
  double dval;

  if (debug_get() == ON) {
      /* Debugging */
      va_start(ap, fmt);
      vfprintf(stdout, fmt, ap); /* processing argumnt list */
      va_end(ap);	 /* clean up when finished */
      fflush(stdout);

  } else {
      /* Non-debugging */
      ;	/* do nothing */
  }
}

void talk_printf(char *fmt, ...)
{ /* modification of minprintf in K&R. See pp307 of K&R 2nd in detail. */
  /* this is exactly same as printf() builtins except executed only when debug flag is on. */
  va_list ap;
  char *p, *sval;
  int ival;
  double dval;

  va_start(ap, fmt);
  vfprintf(stdout, fmt, ap); /* processing argumnt list */
  va_end(ap);	 /* clean up when finished */
  fflush(stdout);
}

void printerr(char *fmt, ...)
{ /* modification of minprintf in K&R. See pp307 of K&R 2nd in detail. */
  /* this is exactly same as printf() builtins except executed only when debug flag is on. */
  va_list ap;
  char *p, *sval;
  int ival;
  double dval;

  va_start(ap, fmt);
  vfprintf(stdout, fmt, ap); /* processing argumnt list */
  va_end(ap);	 /* clean up when finished */
  fflush(stderr);
}

/******************************************************************
 * Pretty print
 ******************************************************************/

int ap_numdigit(int x)  /* replacement of ap...length */
{  /* - return the length of x written in decimal (ascii) */
   if (x > 0)
      return (int) log10(x) + 1; /* the number of the digits to write x */
    else
      return 1;
}

int ap_util_decimal_length(int x)
{  return ap_numdigit(x); 
}

void print_nl(void)
{
  printf("\n");
}

void print_nchar(int n, char c)
{
    int i;
    for (i = 0; i < n; i++)
      putchar(c);
}

/******************************************************************
 * Memory utilities
 ******************************************************************/

/*
 * Subroutines for ca_realloc and ia_realloc
 * - guiding the new length of an array
 * - which is to be the power of two
 */

#define EXPANSION_RATIO 2

int smallest_power(int base, int x)
{ /* returns the smallest number that is a power of base
   * larger than x */
  int ans = 1;
  while (ans < x) 
    ans = ans * base;
  return ans;
}

int ap_expansion_length(int len)
{
  return smallest_power(EXPANSION_RATIO, len);
}


/*
 * Checking the size of the physical memory
 * installed on a computer
 */

int mem_test(int max)
{
    char *tmp; /* Note: Intarray is a pointer to a struct. */
    int n;  /* number of BLOCK */

    if (max <= 0)
      max = LONG_MAX; 

    /* initialization: each cell in the array is initialized to zero */
    debug("mem_test: start initialization\n", n / MEGA);
    if ((tmp = (char *) malloc(1 * sizeof(char))) == NULL)
      error_exit("mem_test: failed\n");
    debug("mem_test: end initialization\n", n / MEGA);
    /* expansion: each cell in the array is not initialized */
    n = BLOCKSIZE * sizeof(char);
    while (n <= max && (tmp = (char *) realloc(tmp, n * sizeof(char))) != NULL) {
	n = n + BLOCKSIZE * sizeof(char);
	debug("mem_test: memory allocated = %d MB\n", n / MEGA);
    }

    free(tmp);
    return n;
}


