#include "ap-strarray.h"

char *sa_get(StrArray sa, int index) {
	return (char *)sa->val[index];
}

void sa_push_back(StrArray sa, char *str) {
	ia_add(sa, (int) str);
}

void sa_add(StrArray sa, char *str) {
	ia_add(sa, (int) str);
}

void sa_put(StrArray sa, int index, char *str) {
	sa->val[index] = (int) str);
}


