#ifndef ___patset___
#define ___patset___

/**************************************** 
 * awap-tmpl.h -- 
 * - created by arim@ist (15JUL06)
 ****************************************/

#include "awap-pattern.h"
#include "awap-docset.h"
#include "awap-query.h"

/****************************************
 * Macros
 ****************************************/

//For debug
#define MAX_OUT_PATTERN 1000000 //an upperbound

/****************************************
 * Types 
 ****************************************/ 

/** struct PatSet.
  A collection of patterns as a priority queue of bounded size.
  It is implemented as a linked list structure sorted by its keys
  combined with an array index from pattern id to pattern entries. 
 */
struct _patset {

	/// a linked list of patterns
	Pattern head;

	/// the tail pointer (the last pattern in the queue)
	Pattern tail;

	/// the predeterined maximum length of the queue. A user-specified value.
	int max;

	/// the current legnth of the queue
	int num;

	/// the array of patterns indexed with pat_id
	Pattern *dict;

	///Once finalized, the patset cannot be modified
	int isFinal;    

	// the pointer to the corresponding docset object 
	DocSet docset;

	// the pointer to the corresponding query object 
	Query query;

};

/** A type for struct PatSet. 
 */
typedef struct _patset *PatSet;

/****************************************
 * Externs: functions and global varialbles 
 ****************************************/ 

extern PatSet patset_create(DocSet docset, Query query);
extern void patset_free(PatSet patset);

extern void patset_insert(PatSet pset, Pattern new_pat);
extern void patset_finalize(PatSet patset);
extern Pattern patset_get_pattern(PatSet patset, int pid);
extern Pattern patset_iter_begin(PatSet patset);
extern Pattern patset_iter_next(Pattern pat);

extern void patset_print(PatSet patset); 
extern void ev_patset_print_events(PatSet patset);
extern void ev_patset_print(PatSet patset);
extern int patset_isTopK(PatSet patset, double eval);

#endif 
