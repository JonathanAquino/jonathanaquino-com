/******************************************************************
 * ap-iarray.c
 * - integer array module 
 * 20 SEP 99: created by arim@i.kyushu-u.ac.jp.
 * 21 SEP 99: ia_write_disk() and ia_readJ_disk() are added.
 * 22 SEP 99: - Replacing old K&R read and write routines based on fd 
 *   with ANSI fread and fwrite routines based on fp. This is only for
 *   the upper compatibility for g++. 
 * $Id: ap-iarray.c,v 1.1.1.1 2006/07/20 12:24:20 arim Exp $
 ******************************************************************/

#include <assert.h>
#include <stdio.h>  /* for BUFSIZ */
#include <stdlib.h>  
#include <string.h> /* for memcpy */
#include "ap-util.h" /* for ap_expansion_length */
#include "ap-iarray.h"

#define ASSERT_ON
//#undef ASSERT_ON

/******************************************************************
 * Basic routiens
 ******************************************************************/

IntArray ia_alloc_len(int len)
{
  IntArray tmp; /* Note: Intarray is a pointer to a struct. */
  int *tmpval;

  if ((tmp = (IntArray) malloc(sizeof(struct _int_array))) == NULL)
    error_exit("ia_alloc: cannot allocate memory\n");

  len = max(len, DEFAULT_ARRAY_LEN); /* for efficiency with realloc() */
  if ((tmpval = (int *) calloc(len, sizeof(int))) == NULL)
    error_exit("ia_alloc: cannot allocate memory\n");
  tmp->val    = tmpval;
  tmp->len    = 0;      /* A new array is always empty */
  tmp->maxlen = len;
  return tmp;
}

/* ia_free:
 * This should be followed by the assignment of NULL for safeness
 * unless it is the end of program file.
 * # ia_free(Pointer);
 * # Pointer = NULL;
 */
void ia_free(IntArray temp)
{
  if (temp == NULL) return;
  free(temp->val);
  /* do nothing for tmp->len */
  /* do nothing for tmp->maxlen */
  free(temp);
}

IntArray ia_alloc(void) {
  return ia_alloc_len(0);
}

void ia_make_null(IntArray tmp)
{
#ifdef ASSERT_ON
  assert(tmp != NULL);
#endif
  tmp->len = 0; 
  /* do nothing for tmp->val */
  /* do nothing for tmp->maxlen */
}

/* Inport ap_expansion_length() from ap-util.h */

void ia_realloc(IntArray ia, int size)
{ /* - expands the maxlen of Intarray ia if maxlen > size.
   * /
  /* Note: Here, we cannot use debug() routines because this ia_realloc()
   * itself used in the definition of debug() routines */
  int maxlen;
  int *tmpval;

  //#ifdef ASSERT_ON
  assert(ia != NULL); 
  //#endif
  if (ia->maxlen >= size)
    return; /* do nothing */

#ifdef DEBUG
  printf("ia_realloc: called with ia=%d, size=%d\n", ia, size);
  fflush(stdout);
#endif
  maxlen = ap_expansion_length(size);
#ifdef DEBUG
  printf("ia_realloc: expanding from %d to %d...\n", ia->maxlen, maxlen); fflush(stdout); 
#endif
  if ((tmpval = (int *) realloc(ia->val, maxlen * sizeof(int))) == NULL)
    error_exit("ia_alloc: cannot reallocate memory\n");
  ia->val    = tmpval;
  ia->maxlen = maxlen; 
  /* do nothing with ia->len */
#ifdef ASSERT_ON
  assert(ia->maxlen >= size);
#endif
}

void ia_assert_defined(IntArray ia)
{
    assert(ia != NULL);
    assert(ia->val != NULL);
    assert(ia->maxlen >= 0);
    assert(ia->len <= ia->maxlen);
}

/*****************************************************************
 * Push and Append
 *****************************************************************/

int ia_get(IntArray ia, int i) {
  assert(i < ia->len);
  return ia->val[i];
}

int ia_put(IntArray ia, int i, int value) {
  int n;
  if (i >= ia->len) {
    ia_realloc(ia, i+1);
    for (n = ia->len; n < i+1; n++) 
	  ia->val[n] = 0;
  }
  ia->val[i] = value;
  ia->len = i+1;
}

int ia_last_val(IntArray ia)
{ /* - returns the value of the last cell */
#ifdef ASSERT_ON
  assert(ia != NULL);
  assert(ia->len > 0); 
#endif 
  return ia->val[ia->len - 1];
}


//inline /* inline cannot used for g++ due to undefined refenrece at ld */
void ia_push_back(IntArray ia, int x)
{ /* - append a character with the end of ca. 
   * - expands the array if it is full. 
   */
  int len;
#ifdef ASSERT_ON
  assert(ia != NULL);
#endif
  len = ia->len; 
  ia_realloc(ia, len + 1);
  ia->val[len] = x;
  ia->len = len + 1;
}

void ia_add(IntArray ia, int x) {
  ia_push_back(ia, x);
}

void ia_append(IntArray ia, IntArray ib)
{ /* - append the contents of ib with the end of ia
   * - ia is reallocated if it has enough memory to have ib. 
   */
  int n, m; 

#ifdef ASSERT_ON
  assert(ia != NULL);
  assert(ib != NULL); 
#endif
  ia_realloc(ia, (ia->len + ib->len));  /* expand ia when it is too small */

  for (m = ia->len, n = 0; n < ib->len; m++, n++) {
    ia->val[m] = ib->val[n];
  }
  ia->len = m; 
}

/*****************************************************************
 * Copy routines
 *****************************************************************/

void ia_copy_fast(IntArray ia, IntArray ib)
{ /* - copies to ia the contents of ib
   * - optimized version
   * - this is as fast as ia_copy below. Please use ia_copy() */
  int n;
  int *val_a, *val_b, *val_b_tail; 
  
#ifdef ASSERT_ON
  assert(ia != NULL);
  assert(ib != NULL); 
#endif
  ia_realloc(ia, ib->len);
  val_a = ia->val; 
  val_b = ib->val; 
  val_b_tail = val_b + ib->len; 
  while (val_b < val_b_tail) 
    *(val_a++) = *(val_b++);
  ia->len = ib->len;
}

void ia_copy(IntArray ia, IntArray ib)
{ /* - formally called ia_copy_memcopy/2
   * - copies to ia the contents of ib
   * - implemented using memcpy() builtin function*/

#ifdef ASSERT_ON
  assert(ia != NULL);
  assert(ib != NULL); 
#endif
  ia_realloc(ia, ib->len);
  memcpy(ia->val, ib->val, ib->len * sizeof(int));
  ia->len = ib->len; 
}

void ia_copy_org(IntArray ia, IntArray ib)
{ /* - copies to ia the contents of ib
   * - this small program with simple loop is as fast as ia_copy() above!
   */
  int n;

#ifdef ASSERT_ON
  assert(ia != NULL);
  assert(ib != NULL); 
#endif
  ia_realloc(ia, ib->len);
#ifdef ASSERT_ON
  assert(ia->maxlen >= ib->len);
#endif
  for (n = 0; n < ib->len; n++)
    ia->val[n] = ib->val[n];
  ia->len = n; 
}

void ia_copy_slowest(IntArray ia, IntArray ib)
{ /* - copies to ia the contents of ib */
  int n;

#ifdef ASSERT_ON
  assert(ia != NULL);
  assert(ib != NULL); 
  assert(ia->maxlen >= ib->len);
#endif
  ia_make_null(ia);
  for (n = 0; n < ib->len; n++)
    ia_add(ia, ib->val[n]);
}

void ia_ncopy(IntArray ia, IntArray ib, int len)
{ /* - copies to ia the initial len letters in ib. 
   * - Already tuned as in ia_copy. 
   */
  int n;

#ifdef ASSERT_ON
  assert(ia != NULL && ib != NULL); 
#endif
  ia_realloc(ia, len);
  for (n = 0; n < len; n++)
    ia->val[n] = ib->val[n];
  ia->len = n; 
}

void ia_copy_slice(IntArray ia, IntArray ib, int beg, int end)
{ /* - formally called ia_copy_memcopy/2
   * - copies to ia the contents of the subarray ib[beg,end)
   * - implemented using memcpy() builtin function
   * - Note: [beg,end) is left-closed right-open interval. */

  int len; 
#ifdef ASSERT_ON
  assert(ia != NULL);
  assert(ib != NULL); 
  assert(0 <= beg);
  assert(beg < ib->len);
  assert(0 <= end);
  assert(end <= ib->len);
#endif
  len = max(0, end - beg); 
  ia_realloc(ia, len);
  memcpy(ia->val, ib->val + beg, len * sizeof(int));
  ia->len = len; 
}

int ia_is_equal(IntArray ia, IntArray ib)
{ /* checks if ia and ib are same intarrays
   */
  int n;
#ifdef ASSERT_ON
  assert(ia != NULL && ib != NULL); 
  assert(ia->maxlen >= ib->len);
#endif
  if (ia->len != ib->len)
    return 0;
  for (n = 0; n < ia->len; n++)
    if (ia->val[n] != ib->val[n])
      return 0;
  return 1;
}

int ia_is_null(Intstack ia)
{
#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
    return (ia->len == 0);
}


/******************************************************************
 * Array filling routines: creating sequences
 ******************************************************************/

void ia_fill(IntArray ia, int len, int x)
{   /* re-initialize and fill the contiguous
     * len cells of ia with integer x */
    int n;

#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
    ia_realloc(ia, len);
    for (n = 0; n < len; n++) {
	ia->val[n] = x;
	//printf("%d:%d ", n, x);
    }
    //putchar('\n');
}

void ia_fill_inc(IntArray ia, int len)
{   /* fill ia with the increasing integers 0, 1, ..., len-1.
     */
  int n;
  
#ifdef ASSERT_ON
  assert(ia != NULL);
#endif
  ia_realloc(ia, len);
  for (n = 0; n < len; n++) {
      ia->val[n] = n; 
  }
  ia->len = n;
}

void ia_fill_random_len(IntArray ia, int range, int len)
{   /* fill ia with len random elements whose values take
       the range from 0 to range */
    int n; 

#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
    ia_make_null(ia);
    for (n = 0; n < len; n++) {
	ia_add(ia, (rand() % range)); 
    }
    ia->len = n;
}

void ia_fill_random(IntArray ia, int len) {
  ia_fill_random_len(ia, len, len);
}

/******************************************************************
 * sorting: quick sort
 ******************************************************************/

/* for performance comparison */
int ia_intcmp(const void *xv, const void *yv)
{
    int *x, *y;
    x = (int *) xv;
    y = (int *) yv; 
    if (*x < *y)      return -1;
    if (*x > *y)      return 1;
    else	      return 0;
}

//inline /* inline cannot used for g++ due to undefined refenrece at ld */
void ia_int_sort_unix(IntArray ia)
{   /* A wrapper routine for unix qsort */
    qsort(ia->val, ia->len, sizeof(int),  ia_intcmp);
}




/******************************************************************
 * stack: service routines for stacks
 ******************************************************************/

Intstack ia_stack_alloc(void)
{
    Intstack tmp;

    tmp = ia_alloc();
    ia_make_null(tmp);
    return tmp;
}

void ia_stack_free(Intstack tmp)
{
    ia_free(tmp);
}

void ia_push(Intstack ia, int x)
{ /* - inserts an element at the end of ca. 
   * - expands the array if it is full. 
   */
#ifdef ASSERT_ON
  assert(ia != NULL);
#endif
  ia_add(ia, x); 
}

int ia_pop(Intstack ia)
{   /* - retrieve and delete the last element of ia */
    int x;

#ifdef ASSERT_ON
    assert(ia != NULL);
    assert(ia->len > 0); /* critical */
#endif
    x = ia->val[ia->len - 1];
    ia->len--;
}

int ia_top(Intstack ia)
{   /* - returns the last element of ia */
#ifdef ASSERT_ON
    assert(ia != NULL); 
    assert(ia->len > 0); /* critical */
#endif
    return (ia->val[ia->len - 1]);
}

int ia_is_empty(Intstack ia)
{
#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
    return (ia->len == 0);
}

/******************************************************************
 * print
 ******************************************************************/

void ia_print(IntArray ia)
{
  int n;
#ifdef ASSERT_ON
  assert(ia != NULL);
  assert(ia->len <= ia->maxlen);
#endif
  if (ia == NULL) {
    printf("NULL");
    return;
  }
  for (n = 0; n < ia->len; n++)
    printf("%d:", ia->val[n]);
}

void ia_report(IntArray ia)
{
    int maxlen = DEFAULT_COLWIDTH; 
    if(ia == NULL) {
      printf("\t ia\t == NULL!\n");
      return;
    }
    //printf("\t ia\t len=%d\t maxlen=%d\n", ia->len, ia->maxlen);
    printf("\t ia\t len=%d\t maxlen=%d (%.3f MB)\n",
	   ia->len,
	   ia->maxlen, 
	   ((double) ia->maxlen)* (double) sizeof(int) / MEGA
	   );
    if (ia->len <= maxlen) {
      printf("\t["); ia_print(ia); printf("]\n");
    } else {
      printf("\tthe output skipped\n");
    }
}

void ia_report_colwidth(IntArray ia, int colwidth)
{
    int maxlen = DEFAULT_COLWIDTH / colwidth; 
    if(ia == NULL) {
      printf("\t ia\t == NULL!\n");
      return;
    }
    printf("\t ia\t len=%d\t maxlen=%d\n", ia->len, ia->maxlen);
    if (ia->len <= maxlen) {
      printf("\t "); ia_print(ia); print_nl();
    } else {
      printf("\t skipping the output... \n");
    }
}

#ifdef COMMENT
void ia_report(Intarray ia)
{
    int maxlen = DEFAULT_COLWIDTH * 2; 
    if(ia == NULL) {
      printf("\t ia\t == NULL!\n");
      return;
    }
    debug_printf("\t ia\t len=%d\t maxlen=%d\n", ia->len, ia->maxlen);
    if (ia->len <= maxlen) {
      debug_printf("\t "); ia_print(ia); print_nl();
    } else {
      debug_printf("\t skipping the output... \n");
    }
}
#endif

/******************************************************************
 * Interface to C-int-array
 ******************************************************************/

/* ca_append_str:
 * - appends a C-string to the tail of ca. 
 */
IntArray ia_append_C_int_array(IntArray ia, int *array, int len)
{
#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
    int n = 0;

    while (n < len) {
	ia_add(ia, array[n]);
	n++; 
    }
    return ia; 
}

/* ia_copy_array:
 * - overwrite a C-int-array to the tail of ia.
 */

IntArray ia_import_from_C_int_array(IntArray ia, int *array, int len)
{
#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
    int n = 0;

    ia_make_null(ia);
    return ia_append_C_int_array(ia, array, len);
}

/* ia_copy_array:
 * - copy the contents of ca into a C-int-array. 
 */
void ia_export_to_C_int_array(IntArray ia, int *array, int len)
{
  int n;
#ifdef ASSERT_ON
  assert(ia != NULL);
#endif
  len = min(len, ia->len); 
  for (n = 0; n < len; n++)
    array[n] = ia->val[n]; 
}

/******************************************************************
 * Disk Input/Output
 ******************************************************************/

#define PERMS 0666
#define WRITABLE(n, nmax) (min(IOBUFSIZE, nmax - n))
/* IOBUFSIZE == 1024 in stdio.h on Solaris2.6 */

int ia_write_disk(IntArray ia, char *outname)
{   /* - writes the contents of ia to a binary file on a disk. 
     * - returns the number of bytes written if succeeded and
     * NULL otherwise. */
    FILE *fp;
    int n   = 0, /* the number of bytes written so far*/
    n_int = 0;	 /* the number of bytes written at once */
    int *buf;	 /* IOBUFSIZE == 1024 in stdio.h on Solaris2.6 */

#ifdef DEBUG
    debug_push(ON);
#else
    debug_push(OFF);
#endif
    debug("ia_write_disk: opening output file: %s\n", outname);
    if ((fp = fopen(outname, "wb")) == NULL) { /* to open with 666 */
	/* Warning: this mode should be binary */
	printf("ia_write_disk: cannot open %s\n", outname);
	return FALSE; 
    }

#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
    debug("ia_write_disk: writing an int array...\n");
    buf = ia->val;
    n   = 0;
    while ((n_int = WRITABLE(n, ia->len)) > 0) {
      debug("ia_write_disk: n=%d, buf-%d, written=%d ints\n", n, buf, n_int);
	if (fwrite(buf, sizeof(int), n_int, fp) != n_int)
	  error_exit("ia_write_disk: write error at %dth letter on %s\n",
		     n, outname);
	buf = buf + n_int;
	n   = n   + n_int;
    }
    debug("ia_write_disk: closing output file...\n");
#ifdef DEBUG
    debug_pop();
#else
    debug_pop();
#endif
#ifdef ASSERT_ON
    assert(n == ia->len);
#endif
    fclose(fp);
    return n; 
}

int ia_read_disk(IntArray ia, char *inname)
{ /* - reads the contents of ia from a binary file on a disk.  
   * - returns the number of bytes written if succeeded and
   * NULL otherwise. */
    FILE *fp;
    //int *buf; 
    int buf[IOBUFSIZE+1]; 
    int n   = 0,		/* the number of letters written */
    n_int = 0;			/* the number of letters to be written */

#ifdef DEBUG
    debug_push(ON);
#else
    debug_push(OFF);
#endif
    debug("ia_read_disk: opening input file: %s\n", inname);
    if ((fp = fopen(inname, "rb")) == NULL) {
	/* Warning: the mode should be binary to correct reading */
	debug("ia_read_disk: cannot open %s\n", inname);
	return FALSE; 
    }
    
#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
    debug("ia_read_disk: reading an int array...\n");
    n   = 0;
    debug("ia_read_disk: init: n=%d, ia->len %d, read=%d ints\n",
	  n, ia->len, n_int);
    while ((n_int = fread(buf, sizeof(int), IOBUFSIZE, fp)) > 0) { 
	//debug("ia_read_disk: n=%d, buf %d, read=%d ints\n", n, buf, n_int);
	ia_append_C_int_array(ia, buf, n_int);
	n   = n   + n_int;
    }
    if (ferror(fp)) {	/* error of some kind */
	printf("ia_read_disk: read error on file %s\n", inname);
	return FALSE;
    }
    debug("ia_read_disk: letter read %d\n", n);
    debug("ia_read_disk: closing input file...\n");
    fclose(fp);
#ifdef DEBUG
    debug_pop();
#else
    debug_pop();
#endif
    return n; 
}

int ia_remove_disk(char *filename) {
  int n = 1;
  if ((n = remove(filename)) == EOF) {
	printf("ca_remove_disk: cannot remove file %s\n", filename);
	return FALSE;
  }
}

/*
 * verification: 24 SEP 99 by arim
 */

int ia_veryfy_disk(IntArray ia, char *file_name)
{ /* - Verify if the original ia and its copy on a disk  file_name are
   * identical.
   * - returns TRUE if identical and FALSE otherwise. */
  IntArray iac;
  int n;
  
#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
  iac = ia_alloc_len(ia->len); /* temporary */
  if (ia_read_disk(iac, file_name) == FALSE)  {
      printf("ia_verify: cannot read the file: %s\n", file_name);
      return FALSE;
  }
  debug("ia_verify: the length of the original and the copy: %d, %d\n",
	ia->len, iac->len);
  for (n = 0; n < iac->len; n++) {
      //if (1) 
      //  debug("equiv: n=%d: %d!=%d\n", n, ia->val[n], iac->val[n]);
      if (ia->val[n] != iac->val[n]) {
	  printf("ia and iac differ at %d-th cell!\n", n);
	  return FALSE; 
      }
  }
  debug("ia_verify: verification suceeded. \n");  
  return TRUE;
}


/*
 * Service routines: examples of array operations
 */

/* Code optimization */
void ia_map(IntArray ia, IntArray ib)
{   /* - replace each value x of ia with ib->val[x] */
    int n, x;
    int *val, *ibval, len; /* pointer for code optimization */
    
#ifdef ASSERT_ON
    assert(ia != NULL);
    assert(ib != NULL);
#endif
    ibval = ib->val;
    len   = ia->len; 
    n = 0;
    val = ia->val;
    while (n < len) {
	x = *val;
	*val = ibval[x];
	val++; 
	n++;
    }
    /* ia-len is not changed */
}

void ia_map_slow(IntArray ia, IntArray ib)
{   /* - replace each value x of ia with ib->val[x] */
    int n, x;
    
#ifdef ASSERT_ON
    assert(ia != NULL);
    assert(ib != NULL);
#endif
    for (n = 0; n < ia->len; n++) {
	x = ia->val[n];
	ia->val[n] = ib->val[x];
    }
    /* ia-len is not changed */
}

void ia_count(IntArray ia, IntArray count, int num_labels)
{
    int n;
    int *val, *tail, *iaval; 
    
#ifdef ASSERT_ON
    assert(ia != NULL);
    assert(count != NULL);
#endif
    /* fill count with num_labels zeros */
    ia_realloc(count, num_labels);
    count->len = num_labels; 
    val = count->val;
    tail = val + num_labels; 
    while (val < tail)
        *(val++) = 0; /* count is zero */
    val = count->val;
    iaval = ia->val; 
    for (n = 0; n < ia->len; n++) {
	val[*(iaval++)]++;
  }
}

void ia_count_slow(IntArray ia, IntArray count, int num_labels)
{
    int n;
    
#ifdef ASSERT_ON
    assert(ia != NULL);
    assert(count != NULL);
#endif
    ia_make_null(count); 
    for (n = 0; n < num_labels; n++)
      ia_add(count, 0);  /* count is zero */
    for (n = 0; n < ia->len; n++) {
	assert(ia->val[n] < count->len);
      count->val[ia->val[n]]++;
  }
}

void ia_scalar_add(IntArray ia, int x)
{
    int n;

#ifdef ASSERT_ON
    assert(ia != NULL);
#endif
    for (n = 0; n < ia->len; n++) {
	ia->val[n] = ia->val[n] + x;
    }
}

/******************************************************************
 * End
 * 
 ******************************************************************/
