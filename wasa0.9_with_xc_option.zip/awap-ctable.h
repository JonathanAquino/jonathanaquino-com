#ifndef ___ctable___
#define ___ctable___ 

// Contingency table:  
//          | TRUE   FALSE |
// ---------+--------------+-----         
//   MATCH  |  P1      N1  |  pm
//          |              |
//  UNMATCH |  P0      N0  |  nm
// ---------+--------------+-----
//          |  pn      nn  |

typedef struct _ctable {

    int P0, P1, N0, N1;

} *Ctable;

extern Ctable ctable_alloc();
extern void ctable_init(Ctable tmp);
extern double ctable_ratio_pos(Ctable ctable); 
extern double ctable_ratio_neg(Ctable ctable); 
extern int ctable_count_pos(Ctable ctable); 
extern int ctable_count_neg(Ctable ctable); 
extern Ctable ctable_copy(Ctable ctable0);

#endif 

