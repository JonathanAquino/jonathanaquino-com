/* awap-patset.c 
 * - created by arim@ist (15JUL06)
 */

#include <stdlib.h>
#include <assert.h>
#include "awap.h"
#include "awap-patset.h"

/****************************************
 * Global definitions
 ****************************************/

#define DEBUG_EVENT

/****************************************
 * basic 
 ****************************************/ 

/** Create a new empty patset.
	@return a new empty patset.
 */
PatSet patset_alloc()
{
  PatSet tmp;

  if ((tmp = (PatSet ) malloc(sizeof(struct _patset))) == NULL)
    error_exit("create_patset: cannot allocate patset!\n");

  tmp->head = pattern_alloc();
  tmp->tail = tmp->head;
  tmp->num = 0;		// The initial length of the queue
  tmp->dict    = NULL;	   // The empty array
  tmp->isFinal = FALSE;

  return tmp;
}

PatSet patset_create(DocSet docset, Query query)
{
  PatSet patset = patset_alloc();

  patset->docset  = docset; // The associated DocSet object
  patset->query   = query;  // The associated Query object
  if (query->top_k > 0)
	patset->max = query->top_k; 
  else 
	patset->max = DefaultTopk;   // Default value
  pattern_initialize(docset);
  return patset;
}

/** Delete a new empty patset.
	@param PatSet a patset.
 */
void patset_free(PatSet patset)
{
    Pattern head, tmp_pat;

	if (patset == NULL)
		return;

    head = patset->head;
    while(head->next != NULL) {	
	  tmp_pat = (head->next)->next;
	  free((Pattern) head->next);
	  head->next = tmp_pat;
    }
	free(patset->dict);
    head->next = NULL;
    free(patset);
}

/****************************************
 * Routines: Insert 
 ****************************************/ 

Pattern patset_iter_begin(PatSet patset) {
  return patset->head->next; 
}

Pattern patset_iter_next(Pattern pat) {
  return pat->next; 
}

/** Insert a pattern into a sorted list with linear search.
	@param pset the pattern set
	@param new_pat the pattern to be inserted
 */
void patset_insert(PatSet pset, Pattern new_pat)
{
	if (pset->isFinal)
		ERREXIT("error: no modification allowed since patset_insert_pattern: patset is final!\n");
	
	Pattern pat = pset->head; 
	Pattern *tailptr = &(pset->tail); 
	Pattern tail = pset->tail; 
	int num = pset->num;
	int max = pset->max;

    //search the insertion point
    while(pat->next != NULL) {
		if ( new_pat->eval <= pat->next->eval ) break;
		pat = pat->next;
    }

    //insert the new pattern 
    new_pat->next = pat->next; 
    pat->next = new_pat;

    //changing the tail pointer
    if (num == max) {
		//the queue is full
		while(pat->next->next != NULL)
			pat = pat->next; 
		free(pat->next);
		pat->next = NULL;
		tail = pat; /* pat->next is always tail */
    }
	else {
		//the queue is not full
		num++;
		if (pat==tail)
			tail = new_pat;
    }
	pset->num  = num;
	pset->tail = tail;
    /* return newpat; */
}

/****************************************
 * Routines: Access by Index (pid)
 ****************************************/ 

/** Compute and finalize the index for a newly created patset. After calling this function, no one can insert new pattern into the patset.
 */
void patset_finalize(PatSet patset) {
	int n, num_pat;
	Pattern pat = NULL; 

	//counting the number of patterns
	num_pat = 0;
	//pat = patset->head->next;
	pat = patset_iter_begin(patset);
	while (pat != NULL) {
		num_pat++; 
		pat = pat->next; 
	}

	//allocate array
	if ((patset->dict = (Pattern *)malloc(num_pat * sizeof(Pattern)))
		== NULL) 
	  error_exit("output_patset: cannot allocate memory to dict!\n");

	n = 0;
	pat = patset->head->next; 
	while (pat != NULL) {
		patset->dict[n] = pat; 
		pat = pat->next; 
		n++; 
	}
	assert(n == num_pat);
	patset->isFinal = TRUE;
}


/** Look up the pattern with the specified pattern id for a given patset.
	This can be called only after pattern set is finalized
	@param pset finalized patset.
	@param pid  pattern id
 */
Pattern patset_get_pattern(PatSet patset, int pid) {
	if (patset->dict == NULL) {
		patset_finalize(patset);
	}

	Pattern pat = NULL;
	if ((pat = patset->dict[pid]) == NULL)
	  error_exit("error: patset_get_pattern: null pattern!\n");
	return pat;
}

/****************************************
 * Routines: utilities
 ****************************************/ 


/** Print all patterns in a patset in the increasing order of their scores. 
 */
void patset_print(PatSet patset)
{

  int D, pid; 
  int pnum = -1, nnum = -1;
  int i; 
  Pattern pat;

  pattern_print_axis(patset->query);

  pid = 0; 
  pat = patset_iter_begin(patset);
  while (pat != NULL) {
	if (pid > MAX_OUT_PATTERN || pid >= patset->num)
	  error_exit("output_patset: LIM_OUTPUT reached!\n");
	pattern_print(pat, pid, patset->query);
	pat = pat->next;
	pid++; 
  }
}	

int patset_isTopK(PatSet patset, double eval) {
	if (patset->num < patset->max) //there is a room for a new member
		return TRUE;
	else if (eval < patset->tail->eval) //strictly better member
		return TRUE;
	else
		return FALSE;
}

/* EOF */

