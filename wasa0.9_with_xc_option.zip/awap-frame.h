#ifndef ___frame___
#define ___frame___ 

#include "awap-docset.h"

/* 
 * awap-frame.h
 */

/*
 * Stack
 */

typedef struct _element {
    int left;  //L
    int hgt;  //H
} *IntPair;

extern IntPair element_create(); 

/*
 * Frame
 */

typedef struct {
    int top;
    IntPair element;
} STACK;

#define MAKENULL(s) {(s).top = -1;}
#define TOP(s) (&((s).element[(s).top]))
#define POP(s) {(s).top--;}
#define PUSH(s, e) {(s).element[++((s).top)] = e;}

extern void stack_makenull(STACK s); 
extern IntPair stack_top(STACK s); 
extern void stack_pop(STACK s); 

// New: Global stack frame
typedef struct _frame {
  STACK Stack;  //Stacks
  int   *Sary;  //Suffix Arrays  
  int   *Hgt;   //Height Arrays
  int   n;      //Array length
} *Frame;

extern int Flag_frameinit; 

extern Frame Frame_alloc(DocSet docset, int D, int k); 

#endif 


