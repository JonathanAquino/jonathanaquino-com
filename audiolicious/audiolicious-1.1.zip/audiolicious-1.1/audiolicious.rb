# Audiolicious --- Convert an RSS feed of links into MP3 files
#
# Copyright (C) 2005 Jonathan Aquino
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


$rss_feed = "http://del.icio.us/rss/JonathanAquino/audiolicious-demo"
$output_dir = "output"

# Below are regular-expression filters, useful if you are turning your
# blog into a podcast and you want to filter out stuff before and
# after your actual post. For example:
#       $pattern_to_ignore_1 = /.*Valid W3C CSS/
#       $pattern_to_ignore_2 = /Leave a comment.*/
$pattern_to_ignore_1 = //
$pattern_to_ignore_2 = //

def lynx(url, options)
  Dir.chdir("ly283rel")
  begin
    return `lynx #{options} "#{url}"`  
  ensure
    Dir.chdir("..")
  end
end

def text(url)
  text = lynx(url, "-dump -nolist").gsub(/[\r\n\t]/, " ")
  # Strip out [...] links introduced by lynx [Jon Aquino 2005-04-06]
  text = text.gsub(/\[[^\]]+\]/, " ")
  # Strip out URLs [Jon Aquino 2005-04-06]
  text = text.gsub(/[A-Z]+:\/\/[^ ]+/i, " ")
  # Strip out repeated punctuation e.g. ======= [Jon Aquino 2005-04-06]
  text = text.gsub(/[^A-Z0-9.()" ][^A-Z0-9.()" ]+/i, ". ")
  # Strip out consecutive whitespace [Jon Aquino 2005-04-06]
  text = text.gsub(/ +/, " ")
  puts text
  text.gsub($pattern_to_ignore_1, "").gsub($pattern_to_ignore_2, "")
end

def run(command)
  puts command
  system(command)
end

def create_mp3_proper(text, filename)
  sentences = text.split(". ").collect {|sentence| sentence+"."}
  i = 0
  # Create 0-length file, whether it already exists or not [Jon Aquino 2005-04-06]
  File.open(filename, "w") {}
  sentences.each { |sentence|
    i += 1
    puts("#{i}/#{sentences.size}: #{sentence}")
    File.open("TextToWave/TextToWave.txt", "w") { |file| file.print(sentence) }
    run("cscript TextToWave\\TextToWave.vbs TextToWave\\TextToWave.txt")
    run("lame-3.96.1\\lame -b 32 TextToWave\\TextToWave.wav TextToWave\\TextToWave.mp3")
    run("copy /B \"#{filename}\"+TextToWave\\TextToWave.mp3 \"#{filename}\"")
  }
end

def create_mp3(title, url)
  create_mp3_proper(text(url), "#{$output_dir}\\#{title}.mp3")
end

def clean_title(title)
  title.gsub(/[^A-Z0-9]/i, " ").gsub(/ +/, " ")[0..40]
end

File.open("audiolicious.txt", "w") {} if not FileTest::exist?("audiolicious.txt")
old_urls = File.readlines("audiolicious.txt").each {|line|line.strip!}

require "rexml/document"
include REXML

# Use Net::HTTP.get to retrieve feed instead of lynx, which chokes on
# feedburner feeds for some reason (gets binary data back for some
# reason) [Jon Aquino 2005-04-22]
require 'net/http'
doc = Document.new(Net::HTTP.get(URI.parse($rss_feed)))
XPath.each(doc, "//item") { |element|
  begin
    url = element.elements["link"].text
    if old_urls.include?(url) then
      puts "Skipping #{url}"
      next
    end
    puts url
    create_mp3(clean_title(element.elements["title"].text), url)
    File.open("audiolicious.txt", "a") { |file| file.puts(url) }
  rescue => e
    puts "Exception: #{e.class}: #{e.message}\n\t#{e.backtrace.join("\n\t")}"
  end
}
