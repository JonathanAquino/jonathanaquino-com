Lynx is a text based web browser.

Win95/98/NT Lynx Installation Instructions (pre-compiled format):

Follow these simple instructions to get Lynx to work in Windows 95/98/NT:

1) Make certain that your "lynx_w32" folder is on your hard drive,
   probably the "C:" drive, and not within another
   directory. (C:\lynx_w32\)

2) Open Notepad. Notepad is a text editor program in Windows,
   normally found on the "Start" menu under "Accessories". If you do
   not know where it is, use the "Find File" option from the Start
   menu. If you are still unable to find it, use another word
   processor instead, making sure to save the file as plain text,
   "word processors" being prone to add formatting stuff. (but chances
   are that you do have Notepad).

3) Select "Open..." from the File menu. The "Open" window will
   appear. In this window there is a pop up menu entitled: "Files of
   type:".  From that pop up menu, change "Text Documents" to "All
   Files (*.*)".

4) In the "Open" window, navigate to your "lynx_w32" folder
   (remember, it should be in your C: drive!). Now got to into the
   "samples" folder, which is within the "lynx_w32" folder. Open the
   file "Lynx.bat" (it is in the "samples" folder;
   C:\lynx_w32\samples\Lynx.bat).  The following text should appear:

@ECHO OFF
set term=vt100
set home=d:\win32
set temp=d:\tmp
set lynx_cfg=d:\win32\lynx.cfg
d:\win32\lynx.exe %1 %2 %3 %4 %5

   Change the all the drive letters to the drive where you have Lynx.
   This is most likely "C:", but may be "D:" or "E:" or whatever.
   Change the directory names from win32 to where you have put Lynx.
   Like this:

@ECHO OFF
set term=vt100
set home=c:\lynx_w32
set temp=c:\tmp
set lynx_cfg=c:\lynx_w32\lynx.cfg
c:\lynx_w32\lynx.exe %1 %2 %3 %4 %5

   Once you have made those changes, save the document as
   "C:\lynx_w32\lynx.bat". Close Notepad.

5) Create a Shortcut to "lynx.bat" (C:\lynx_w32\lynx.bat) by doing
   "Right-Click => New => Shortcut" on your desktop. Double click this
   shortcut and Lynx will begin to load.

   Once you have a shortcut to a batch file that runs lynx.exe, you
   can then modify the properties of that shortcut to allow pasting by
   going to Misc->Other->Fast (Win98: Properties->Misc->FastPasting)
   pasting and turning it off.

Happy browsing!

These installation instructions were done by Scythe_X.
Date: Mon, 06 Sep 1999 16:09:48 PDT
From: Scythe X <scythe_x@hotmail.com>

Additional recommendations from Doug Kaufman:

1. Make a shortcut to your lynx.bat file (via right-click), and put
this either in your START menu or your desktop.

2. Change the properties of the shortcut to start with environment
memory of 4096, rather than the default (right click, then
properties).

3. Don't put lynx in a directory where the long name is different from
the short (DOS) name, unless you are quite careful with the paths in
your batch file.

========================================================================
Lynx distribution

Lynx is distributed under the GNU General Public License, which is
included in both the source and executable distributions. See the file
named "COPYING" for the complete text.

Copyrights held by the University of Kansas, CERN, and other
contributors.

========================================================================
[ leftover text from older readmes follows ]

originally from http://www.fdisk.com/doslynx/wlynx/
newer borland builds from http://www.jim.spath.com/lynx_win32/

readme.txt    This message.
lynx_w32.zip  A compiled Win32 Lynx.exe, lynx.cfg, mv.exe 
              along with some config info.

The 2-8-3rel1 version was compiled using Borland C++Builder.
The formerly included sendmail.exe has been set aside.
Here if you need it other URLs as available;
http://jim.spath.com/lynx_win32/SENDMAIL.TXT
http://jim.spath.com/lynx_win32/SENDMAIL.EXE
 
This version differs from Wayne Buttles 2-8-2 release in that it 
includes some patches created by Hiroyuki Senshu.

Full sources are available on http://lynx.isc.org/current/
and its mirrors.

For 283-release, I've updated the lynx.cfg file to the latest one.
Oh yeah, and the help files too.

To compile this program yourself, you should read the INSTALLATION
file, and one or more of makelynx.bat (for MingW32), makefile.bcb (for
Borland), or makefile.msc (for Microsoft).

The Win32 version will work on Win95/8 or WinNT using the standard winsock.
Win3.11 will NOT work -- not even with win32s and wolverine installed.
This is a console application meaning that it appears to run in a DOS box
within Windows, but it accesses the Windows network layer and other kernel
functions directly.

If you want to run helper apps then they *may* need to be in your path.  I
haven't tested this much yet.

lynx uses cp.exe to make a copy of a temp file when you download and then
choose a destination.  Don't delete it.  It works best when put in your
PATH. [ No longer needed, but here if you need a copy for whatever ].
http://jim.spath.com/lynx_win32/CP.EXE [ and MV.EXE as well ]

This version uses BLOCKING lookups and connects.  I wasn't ready to
butcher the code to install non-blocking calls yet.  The Win32 version
should now at least have non-blocking lookups.

This is NOT guaranteed to be a secure client.  Don't just slap it on an NT
server or DOS BBS and open it up to the public without testing it!!!

File access looks like this:

file:///c:/
file:///c:/dos
file:///c:/dos/command.com

Here are some useful environment variables which you should set up
in a lynx.bat file:

HOME         Where to keep the bookmark file and personal config files.
TEMP or TMP  Bookmarks are kept here with no HOME.  Temp files here.
USER         Tells Lynx you are real instead of an anonymous user(?)
LYNX_CFG     Where to find the lynx.cfg.

Look in SAMPLES for an idea on how to create a good lynx.bat.

43 line mode works fine in the Win32 version as long as you start it that
way.

I am sure there will be questions, opinions, flames...they should ALL be
sent to lynx-dev@sig.net since this is a real port.  If you are not
subscribed to lynx-dev then you can read responses from the web archive at
http://www.flora.org/lynx-dev/.

Happy browsing,
Wayne
... and Jim (et al)

----------------------------
See http://lynx.browser.org/
----------------------------
