<h2>Congratulations!</h2>
<br/>
<p>You've just created your own version of this app. Now you can set it up below. Once you are done, we'll send you to the homepage of your new app and you can start adding content.</p>
<br/>
<p><b>Tip:</b> You can change the color scheme by clicking Color Scheme in the nav bar above.</p>
<br>

<?php $this->form->display(); ?>

