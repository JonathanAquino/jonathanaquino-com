<h3>Application setup failed:</h3>
<h4><?php echo htmlentities($message, ENT_QUOTES, 'UTF-8'); ?></h4>
<?php $this->form->display(); ?>
