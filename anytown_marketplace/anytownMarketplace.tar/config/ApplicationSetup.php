<?php
/*
 * ApplicationSetup.php
 * version 20050922-001
 * - added support for using built-in QuickForm rules
 * version 20050913-001
 * - added support for "description" and "class"
 * - fixed code formatting
 * - added support for file uploads
 * 
 * version 20050901-001
 * - corrected variable name in check for turning off "required" rule
 *
 * version 20050829-001
 */
require_once 'config.php';
require_once 'HTML/QuickForm.php';
require_once 'HTML/QuickForm/Rule.php';


class ApplicationSetup {
    protected $form;
    protected $fields = array();

    public function __construct() {
        $this->form = new HTML_QuickForm('setupForm','POST',basename($_SERVER["SCRIPT_FILENAME"]));
        $renderer = $this->form->defaultRenderer();
        $renderer->setFormTemplate('<form{attributes}>{hidden}<dl>{content}</dl></form>');
        $renderer->setElementTemplate('
<dt><!-- BEGIN required --><span class="setupFormRequired">*</span><!-- END required -->{label}</dt>
<dd><!-- BEGIN error --><span class="setupFormError">Error: {error}</span><br /><!-- END error -->{element}</dd>
');
        
        foreach (get_declared_classes() as $class) {
            if (preg_match('/^ApplicationSetup_.*?([^_]+Rule)$/',
                           $class,$match)) {
                $this->form->registerRule($match[1],null,$class);
            }
        }
        
        $defaults = array();
        foreach ($this->fields as $fieldName => $fieldData) {
            if (isset(Config::${$fieldName})) {
                if ($this->fields[$fieldName]['type'] == 'boolean') {
                    $defaults[$fieldName] = (boolean) Config::${$fieldName};
                } else {
                    $defaults[$fieldName] = Config::${$fieldName};
                }
            }

            $attrs = array();
            if (isset($fieldData['class'])) {
                $attrs['class'] = $fieldData['class'];
            }
            
            if ($fieldData['type'] == 'text') {
                $type = 'text';
                $attrs['size'] = 25;
                $this->form->addElement('text',$fieldName,
                                        $fieldData['label'],
                                        $attrs);
            } elseif ($fieldData['type'] == 'boolean') {
                $this->form->addElement('select',$fieldName,
                                        $fieldData['label'],
                                        array(1 => 'yes', 0 => 'no'),
                                        $attrs);
                $this->form->addRule($fieldName,"$fieldName must be yes or no",'BooleanRule','client');
            } elseif ($fieldData['type'] == 'integer') {
                $attrs['size'] = 5;
                $this->form->addElement('text',$fieldName,$fieldData['label'],
                                        $attrs);
                $this->form->addRule($fieldName,"$fieldName must be a number",'numeric',null,'client');
            } elseif ($fieldData['type'] == 'select') {
                $this->form->addElement('select',$fieldName,$fieldData['label'],$fieldData['choices'],$attrs);
                $this->form->addRule($fieldName,"$fieldName must be picked from the list",'SelectRule',
                                     $fieldData['choices']);
            } elseif ($fieldData['type'] == 'multiselect') {
                $attrs['multiple'] = 'multiple';
                $this->form->addElement('select',$fieldName,$fieldData['label'],$fieldData['choices'],$attrs);
                $this->form->addRule($fieldName,"$fieldName must be picked from the list",'SelectRule',
                                     $fieldData['choices']);
            } elseif ($fieldData['type'] == 'file') {
                $this->form->addElement('file',$fieldName,
                                        $fieldData['label']);
                $this->form->addRule($fieldName,"$fieldName must be an uploaded file",'uploadedfile');
            }
            
            if (isset($fieldData['description'])) {
                $this->form->addElement('html', '<div class="setupDescription">'.$fieldData['description'].'</div>');
            }
            
            $required = true;
            
            if (isset($fieldData['rules']) && is_array($fieldData['rules'])) {
                foreach ($fieldData['rules'] as $rule => $ruleData) {
                    if (($rule == 'required') && ($ruleData == false)) {
                        $required = false;
                    } else {
                        list($msg,$val) = $ruleData;
                        $ruleName = ucfirst($rule).'Rule';
                        if (($ruleName == 'RegexRule') &&
                            ($fieldData['type'] == 'file')) {
                            $ruleName = 'filename';
                        }
                        if (! $this->form->isRuleRegistered($ruleName)) {
                            $ruleName = $rule;
                        }
                        $this->form->addRule($fieldName,"$fieldName $msg",$ruleName,$val);
                    }
                }
            }
            if ($required) {
                $this->form->addRule($fieldName,"$fieldName is required",'required',null,'client');
            }
        }
        $this->form->setDefaults($defaults);
        $this->form->addElement('submit','submit','Configure','class="button"');
    }
    
    public function saveConfig($data) {
        try {
            Config::save($data);
            return true;
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }
    
    protected function renameFiles($oldValue, $newValue, $files) {
        if ($oldValue == $newValue) { return true; }
        if (! is_array($files)) { $files = array($files); }
        foreach ($files as $file) {
            $oldFile = sprintf($file, $oldValue);
            $newFile = sprintf($file, $newValue);
            $res = @rename($oldFile,$newFile);
            if (! $res) {
                throw new Exception("Can't rename $oldFile to $newFile");
            }
        }
        return true;
    }
    
    public function go() {
        if (! XN_Profile::current()->isOwner()) {
            include '_setupRequired.php';
            exit();
        }
        
        if ($this->form->validate()) {
            $message = $this->form->process(array($this,'saveConfig'));
            if ($message == true) {
                include '_setupComplete.php';
            } else {
                include '_setupFailed.php';
            }
        } else {
            include '_setupDisplay.php';
        }
    }
}

class ApplicationSetup_BooleanRule extends HTML_QuickForm_Rule {
    function validate($value) {
        return (($value == '0') || ($value == '1'));
    }
}

class ApplicationSetup_MinimumRule extends HTML_QuickForm_Rule {
    function validate($value, $param) {
        return ($value >= $param);
    }
}

class ApplicationSetup_MaximumRule extends HTML_QuickForm_Rule {
    function validate($value, $param) {
        return ($value <= $param);
    }
}

class ApplicationSetup_ContentTypeRule extends HTML_QuickForm_Rule {
    function validate($value) {
        return (strpos($value, '/') === false);
    }
}

class ApplicationSetup_RegexRule extends HTML_QuickForm_Rule {
    function validate($value, $pattern) {
        return preg_match($pattern, $value);
    }
}

class ApplicationSetup_SelectRule extends HTML_QuickForm_Rule {
    function validate($value, $choices) {
        if (is_array($value)) {
            foreach ($value as $oneValue) {
                if (! array_key_exists($oneValue, $choices)) {
                    return false;
                }
            }
            return true;
        } else {
            return array_key_exists($value, $choices);
        }
    }
} 
