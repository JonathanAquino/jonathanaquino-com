<?php
require_once 'config/ApplicationConfig.php';

/**
 * The Config class holds application configuration information -- what kinds of
 * content the app is dealing with and other app-wide data like arrays for 
 * form choices, result page size, and so on. All of the configuration variables
 * should be declared as public static variables.
 */
class Config extends ApplicationConfig {   
    public static $reviewsOnFrontPage = 6;
    public static $postingsPerPage = 100;
    public static $tagsOnTopTagsPage = 50;
}

Config::load();

?>
