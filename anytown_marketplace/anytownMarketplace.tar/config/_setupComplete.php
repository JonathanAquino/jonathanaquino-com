<?php
  // If the app is cloned, off to the front page.
header("Location: http://{$_SERVER['HTTP_HOST']}/");
?>

