<?php
function include_in_backup($file) {
    if ($file == 'xn_private') { return false; }
    if ($file == 'convertAnytownListingsToAnytownMarketplace.php') { return false; }
    if (preg_match('/\.tar$/i', $file)) { return false; }
    return true;
}
$files = array();
foreach (dirList('/' . XN_Application::load()->relativeUrl) as $file) {
    if (! include_in_backup($file)) { continue; }
    if (is_dir($file)) { throw new Exception('Could not back up original files -- directory backup not supported: ' . $file); }        
    $files[] = $file;
}
if (file_exists('anytownListings.tar')) { throw new Exception('Could not back up original files -- anytownListings.tar already exists'); }
$tar = new Archive_Tar('anytownListings.tar');
if (! $tar->create($files)) { throw new Exception('Could not back up original files -- $tar->create($files) failed'); }
foreach (dirList('/' . XN_Application::load()->relativeUrl) as $file) {
    if (! include_in_backup($file)) { continue; }
    unlink($file);
}
?>
