<div id="main">
    <?php HTMLHelper::displayBreadcrumbs($category, $subcategory, $posting, true); ?>
    <p class="status">Showing <?php echo min(1, count($popularTagsAndCounts)) ?>-<?php echo count($popularTagsAndCounts) ?></p>
    <div id="map">
        <span class="tag">
            <?php echo XNC_HTML::buildMap($popularTagsAndCounts, array('link' => 'index.php?controller=posting&amp;action=list&amp;tag=%s', 'delimiter' => ' *')); ?>
        </span>
    </div>         
</div><!-- end #xn_main -->    

