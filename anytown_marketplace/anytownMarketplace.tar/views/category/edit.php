<?php DragDropHelper::initialize(array('subcategoryList')); ?>

<div id="main">

    <?php HTMLHelper::displayErrors($errors); ?>
    <h2>Edit Category</h2>
    <form id="form" name="form" method="POST" action="index.php?controller=category&amp;action=update&amp;id=<?php echo $category->id ?>">
        <dl>
            <?php include '_form.php' ?>
            <dt><?php echo $form->submit(null, 'Continue', 'class="button" onclick="extractSubcategoryIDs()"') ?></dt>  
        </dl>
    </form>
    
    <script type="text/javascript">
        document.form.xtitle.focus();
    </script>

</div>


