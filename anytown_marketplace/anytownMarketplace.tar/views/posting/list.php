<div id="main">
    <?php HTMLHelper::displayBreadcrumbs($category, $subcategory, $posting, strlen($_GET['query']) > 0); ?>
    <div id="searchCategory">
        <form action="index.php" method="get" id="search" name="form">
        <input type="hidden" name="controller" value="posting">
        <input type="hidden" name="action" value="list">
        <input type="hidden" name="categoryID" value="<?php echo $category->id ?>">            
            <dl>
                <dd>keywords: <input name="query" type="text" class="input-search" value="<?php echo htmlentities($_GET['query']); ?>" /> 
                    <?php
                    // Show the combobox even if there are no subcategories, so the user can tell that they are searching
                    // one category, not all categories. [Jon Aquino 2005-11-02]
                    if ($category) { ?>
                        in
                        <select name="subcategoryID">
                            <option value="">All <?php echo $category->my->h('xtitle') ?></option>            
                            <?php
                            // Call it $subcategoryForCombobox rather than $subcategory, as we check if $subcategory
                            // exists below [Jon Aquino 2005-10-31]
                            foreach (Category::subcategories($category) as $subcategoryForCombobox) { ?>
                                <option value="<?php echo $subcategoryForCombobox->id ?>" <?php if ($_GET['subcategoryID'] == $subcategoryForCombobox->id) { echo 'selected="selected"'; } ?>><?php echo $subcategoryForCombobox->my->h('xtitle') ?></option>
                            <?php
                            } ?>
                        </select>	    
                    <?php
                    } 
                    $secondLine = false; ?>
                    <?php
                    if ($category->my->postingsHavePrice == 'Y') {
                        echo $secondLine ? '<span style="margin-left:10px;"/>' : '<br /> ';
                        $secondLine = true; ?>                        
                        $ 
                        <input type="text" name="minPrice" value="<?php echo $_GET['minPrice'] ? htmlentities($_GET['minPrice']) : 'min'; ?>" size="5"/>
                        to
                        <input type="text" name="maxPrice" value="<?php echo $_GET['maxPrice'] ? htmlentities($_GET['maxPrice']) : 'max'; ?>" size="5"/>                            
                    <?php
                    } ?>        
                    <?php
                    if ($category->my->postingsHaveRatings == 'Y') { 
                        echo $secondLine ? '<span style="margin-left:10px;"/>' : '<br /> ';
                        $secondLine = true; ?>              
                        rating:
                        <select name="minRating">
                            <option value=""></option>                        
                            <option value="5" <?php if ($_GET['minRating'] == '5') { echo 'selected="selected"'; } ?>>5 stars</option>
                            <option value="4" <?php if ($_GET['minRating'] == '4') { echo 'selected="selected"'; } ?>>4 stars</option>
                            <option value="3" <?php if ($_GET['minRating'] == '3') { echo 'selected="selected"'; } ?>>3 stars</option>                
                            <option value="2" <?php if ($_GET['minRating'] == '2') { echo 'selected="selected"'; } ?>>2 stars</option>
                            <option value="1" <?php if ($_GET['minRating'] == '1') { echo 'selected="selected"'; } ?>>1 stars</option>
                        </select>
                        to
                        <select name="maxRating">
                            <option value=""></option>                        
                            <option value="5" <?php if ($_GET['maxRating'] == '5') { echo 'selected="selected"'; } ?>>5 stars</option>
                            <option value="4" <?php if ($_GET['maxRating'] == '4') { echo 'selected="selected"'; } ?>>4 stars</option>
                            <option value="3" <?php if ($_GET['maxRating'] == '3') { echo 'selected="selected"'; } ?>>3 stars</option>                
                            <option value="2" <?php if ($_GET['maxRating'] == '2') { echo 'selected="selected"'; } ?>>2 stars</option>
                            <option value="1" <?php if ($_GET['maxRating'] == '1') { echo 'selected="selected"'; } ?>>1 stars</option>
                        </select>                            
                    <?php
                    } ?>               
                    <?php
                    if ($category->my->postingsHaveAge == 'Y') { 
                        echo $secondLine ? '<span style="margin-left:10px;"/>' : '<br /> ';
                        $secondLine = true; ?>              
                        age:
                        <input type="text" name="minAge" value="<?php echo $_GET['minAge'] ? htmlentities($_GET['minAge']) : 'min'; ?>" size="5"/>
                        to
                        <input type="text" name="maxAge" value="<?php echo $_GET['maxAge'] ? htmlentities($_GET['maxAge']) : 'max'; ?>" size="5"/>                            
                    <?php
                    } ?>                         
                    <input value="Search" class="button" type="submit" />
                </dd>
            </dl>
        </form>
        <script type="text/javascript">
            document.form.query.focus();
        </script>        
    </div>     
    
    <table width="100%">
        <tr>
            <td>
                <?php
                if ($previousWeekURL) { ?>                    
                    <p class="status" style="text-align:left">
                        <a href="<?php echo $previousWeekURL ?>">&laquo; Previous Week</a>
                    </p>
                <?php
                } ?>
            </td>
            <td>
                <p class="status">
                    <?php PaginationHelper::displayPaginationHeader(Config::$postingsPerPage, $_GET['start'], $query->getTotalCount()); ?>    
                    / <a class="post" href="<?php echo $postURL ?>"><?php echo $postText ?></a>
                </p>
             </td>
         </tr>
    </table>
    
    <?php
    $ulOpen = false;
    // Hack to ensure current date is always shown [Jon Aquino 2005-11-06]
    $dummyPostings = array();    
    if (isset($_GET['date'])) {
        $dummyPosting = XN_Content::create('Posting');
        $dummyPosting->my->dummyDate = $_GET['date'];
        $dummyPostings[] = $dummyPosting;
    }    
    foreach (PHPHelper::concatenate(array($dummyPostings, $postings)) as $posting) {           
        $date = $posting->my->dummyDate ? $posting->my->dummyDate : ($postingsHaveDate ? $posting->my->date : $posting->createdDate);
        // $date will be null if user turned on postingsHaveDate for a category with existing postings [Jon Aquino 2005-10-27]
        if ($date) {
            $formattedDate = HTMLHelper::date(strtotime($date));
            if ($lastFormattedDate != $formattedDate) { 
                if ($ulOpen) { echo '</ul>'; } ?>                
                <p class="date"><?php echo $formattedDate; ?></p>
                <ul>
                <?php
                $ulOpen = true;
                $lastFormattedDate = $formattedDate;            
            }
        } ?>
        <?php if ($posting->my->dummyDate) { continue; } ?>
        <li>
            <a href="index.php?controller=posting&amp;action=show&amp;categoryID=<?php echo $posting->my->contentId('category') ?>&amp;subcategoryID=<?php echo $posting->my->contentId('subcategory') ?>&amp;id=<?php echo $posting->id ?>"><?php echo self::formattedTitle($posting); ?></a>
            <?php                        
            if ($categorySubcategoryLink = HTMLHelper::categorySubcategoryLink($posting, ! $category, ! $subcategory)) { echo ' in ' . $categorySubcategoryLink; }
            if ($posting->my->commentCount) { echo '<span>' . $posting->my->commentCount . ' ' . HTMLHelper::plural('comment', $posting->my->commentCount) . '</span>'; } 
            if ($posting->my->averageRating) { echo '<span><img src="images/stars' . $posting->my->averageRating . '.gif" /></span>'; }   
            if ($posting->my->photo1 || $posting->my->photo2 || $posting->my->photo3) { echo '<span>photo</span>'; }
            if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserContributed($posting))) { ?>
                <span>
                    <a class="editDelete" href="index.php?controller=posting&amp;action=edit&amp;categoryID=<?php echo $posting->my->contentId('category') ?>&amp;subcategoryID=<?php echo $posting->my->contentId('subcategory') ?>&amp;id=<?php echo $posting->id ?>">Edit</a> |
                    <a class="editDelete" href="index.php?controller=posting&amp;action=delete&amp;id=<?php echo $posting->id ?>&amp;targetURL=<?php echo htmlentities(urlencode(HTMLHelper::currentURL())) ?>" onclick="javascript:return confirm('Are you sure you want to delete this posting?')">Delete</a>
                </span>
            <?php
            }             
            ?>
        </li>        
    <?php    
    } 
    if ($ulOpen) { echo '</ul>'; } ?> 
    <?php PaginationHelper::displayPaginationFooter(Config::$postingsPerPage, $_GET['start'], $query->getTotalCount()) ?>
</div>
