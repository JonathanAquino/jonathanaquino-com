<script type="text/javascript">
    function appendURL() {
        document.getElementById('messageTextArea').value += "\n\n";
        document.getElementById('messageTextArea').value += "-- \nPosted by <?php echo XN_Profile::current()->screenName ?> \n";
        document.getElementById('messageTextArea').value += 'http://<?php echo NingHelper::application()->relativeUrl ?>.ning.com/index.php?controller=posting&action=show&categoryID=<?php echo $posting->my->contentId('category') ?>&subcategoryID=<?php echo $posting->my->contentId('subcategory') ?>&id=<?php echo $posting->id ?>';           
    }    
</script>

<div id="main">
    <h2>Reply Re: <span><?php echo PostingController::formattedTitle($posting) ?></span></h2>
    <xn:sendMessage to="${Profile['<?php echo $posting->contributorName ?>']}" targetPage="index.php?controller=posting&amp;action=show&amp;categoryID=<?php echo $posting->my->contentId('category') ?>&amp;subcategoryID=<?php echo $posting->my->contentId('subcategory') ?>&amp;id=<?php echo $posting->id ?> &amp;messageSent=yes">
         <input type="hidden" name="subject" value="Re: <?php echo htmlentities(PostingController::formattedTitle($posting)) ?>"/>
        <dl>
            <dt>From: <?php echo htmlentities(XN_Profile::current()->screenName) ?></dt>
            <dt>Message:</dt>
            <dd>
                <!-- Use "messageTextArea" - IE seems to have problems with "message" as an ID (won't set the value) [Jon Aquino 2005-11-04] -->
                <textarea name="message" id="messageTextArea" rows="6" class="input-field"></textarea>
            </dd>
            <dd><input type="submit" onclick="appendURL()" value="Send" class="button"/> </dd>
        </dl>
    </xn:sendMessage>         
</div>

<script type="text/javascript">
    document.getElementById('messageTextArea').focus();
</script>
