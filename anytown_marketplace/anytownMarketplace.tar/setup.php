<?php

require_once 'config/ApplicationSetup.php';

class Setup extends ApplicationSetup {
    // fields are required unless otherwise specified
    protected $fields = array(
        'reviewsOnFrontPage' => array(
            'label' => '<strong>Number of recent reviews on the front page</strong>',
            'type' => 'integer',
            'rules' => array('minimum' => array('must be at least 1', 1))),    
        'postingsPerPage' => array(
            'label' => '<strong>Number of postings per page</strong>',
            'type' => 'integer',
            'rules' => array('minimum' => array('must be at least 1', 1))),
        'tagsOnTopTagsPage' => array(
            'label' => '<strong>Number of tags on the Top Tags page</strong>',
            'type' => 'integer',
            'rules' => array('minimum' => array('must be at least 1', 1)))            
            );
}

$setup = new Setup($fields);
$setup->go();

?>
