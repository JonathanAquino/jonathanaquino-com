<?php
// TODO: Specify each test once, not twice. [Jon Aquino 2005-11-05]
require_once 'test/W_ContentTest.php';
require_once 'test/ValidationHelperTest.php';
require_once 'test/HTMLHelperTest.php';
require_once 'test/ColorSchemeHelperTest.php';
require_once 'test/PHPHelperTest.php';
require_once 'test/DateHelperTest.php';
require_once 'test/PostingTest.php';
require_once 'test/ApplicationTest.php';
require_once 'test/CategoryTest.php';
require_once 'test/PostingControllerTest.php';
require_once 'PHPUnit/GUI/HTML.php';
require_once 'PHPUnit.php';
$gui = new PHPUnit_GUI_HTML(array(
        new PHPUnit_TestSuite('ValidationHelperTest'),
        new PHPUnit_TestSuite('PostingControllerTest'),
        new PHPUnit_TestSuite('ColorSchemeHelperTest'),
        new PHPUnit_TestSuite('PostingTest'),
        new PHPUnit_TestSuite('ApplicationTest'),
        new PHPUnit_TestSuite('DateHelperTest'),        
        new PHPUnit_TestSuite('CategoryTest'),
        new PHPUnit_TestSuite('PHPHelperTest'),
        new PHPUnit_TestSuite('HTMLHelperTest'),        
        new PHPUnit_TestSuite('W_ContentTest')));
$gui->show();
?>
