<?php
require_once 'PHPUnit.php';
require_once 'helpers/HTMLHelper.php';

class HTMLHelperTest extends PHPUnit_TestCase {    
    
    public function testExtractNumber() {
        $this->assertEquals(null, HTMLHelper::extractNumber(null));
        $this->assertEquals(null, HTMLHelper::extractNumber('  '));
        $this->assertEquals(null, HTMLHelper::extractNumber('ABC'));
        $this->assertEquals(5, HTMLHelper::extractNumber('  5  '));
        $this->assertEquals(5, HTMLHelper::extractNumber('_5_'));
        $this->assertEquals(5.4, HTMLHelper::extractNumber('_5.4_'));
        $this->assertEquals(null, HTMLHelper::extractNumber('_5.4.3_'));
        $this->assertEquals(1234.56, HTMLHelper::extractNumber('$1,234.56'));
    }         
    
    public function testRemoveEvilTags() {
        $this->assertEquals('<a href="forbiddenalert(1);" target="_blank" forbidden = "alert(1)">test</a>', HTMLHelper::removeEvilTags('<a href="javascript:alert(1);" target="_blank" onMouseOver = "alert(1)">test</a>'));
    }
    
}

?>


