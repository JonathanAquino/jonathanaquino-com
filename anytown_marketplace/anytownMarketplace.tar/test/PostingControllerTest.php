<?php
require_once 'PHPUnit.php';
require_once 'controllers/PostingController.php';

class PostingControllerTest extends PHPUnit_TestCase {    
    
    public function testRemoveInitialDollarSign() {
        $this->assertEquals('123', PostingController::removeInitialDollarSign('$123'));
        $this->assertEquals('123 obo', PostingController::removeInitialDollarSign(' $123 obo '));        
        $this->assertEquals('', PostingController::removeInitialDollarSign(''));
        $this->assertEquals(null, PostingController::removeInitialDollarSign(null));
    }         
    
    public function testImport() {
        $posting = W_Content::create('Posting');
        $posting->import(array('x' => 'x'));
        $this->assertEquals(null, $posting->my->x);
    }            
    
    public function testAverageRating1() {
        $posting = XN_Content::create('Posting');
        $posting->my->set('rating', 3, XN_Attribute::NUMBER);
        $comments = array(XN_Content::create('Comment'), XN_Content::create('Comment'), XN_Content::create('Comment'));
        $comments[0]->my->set('rating', 5, XN_Attribute::NUMBER);
        $this->assertEquals(4, Posting::averageRating($posting, $comments));
    }
    
    public function testAverageRating2() {
        $posting = XN_Content::create('Posting');
        $comments = array(XN_Content::create('Comment'), XN_Content::create('Comment'), XN_Content::create('Comment'));
        $this->assertEquals(3, Posting::averageRating($posting, $comments));
    }    
    
    public function testAverageRating3() {
        $posting = XN_Content::create('Posting');
        $posting->my->set('rating', 2, XN_Attribute::NUMBER);
        $comments = array(XN_Content::create('Comment'), XN_Content::create('Comment'), XN_Content::create('Comment'));
        $this->assertEquals(2, Posting::averageRating($posting, $comments));
    }    
    
    public function testAverageRating4() {
        $posting = XN_Content::create('Posting');
        $comments = array(XN_Content::create('Comment'), XN_Content::create('Comment'), XN_Content::create('Comment'));
        $comments[0]->my->set('rating', 5, XN_Attribute::NUMBER);
        $comments[1]->my->set('rating', 1, XN_Attribute::NUMBER);
        $this->assertEquals(3, Posting::averageRating($posting, $comments));
    }    
    
    public function testAverageRating5() {
        $posting = XN_Content::create('Posting');
        $comments = array(XN_Content::create('Comment'), XN_Content::create('Comment'), XN_Content::create('Comment'));
        $comments[0]->my->set('rating', 5, XN_Attribute::NUMBER);
        $comments[1]->my->set('rating', 2, XN_Attribute::NUMBER);
        $this->assertEquals(4, Posting::averageRating($posting, $comments));
    }        
    
}

?>


