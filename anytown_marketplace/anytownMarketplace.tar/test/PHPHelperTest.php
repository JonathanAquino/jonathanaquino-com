<?php
require_once 'PHPUnit.php';
require_once 'helpers/PHPHelper.php';

class PHPHelperTest extends PHPUnit_TestCase {    
    
    public function testImplode() {
        $this->assertEquals('', implode(' ', array()));
    }         
    
    public function testRemoveValue() {
        $this->assertEquals('b c', implode(' ', PHPHelper::removeValue('a', array('a', 'b', 'c'))));
        $this->assertEquals('a b c', implode(' ', PHPHelper::removeValue('d', array('a', 'b', 'c'))));
        $this->assertEquals('', implode(' ', PHPHelper::removeValue('a', array())));
    }         
    
    public function testConcatenate() {
        $this->assertEquals('A B C a b c', implode(' ', PHPHelper::concatenate(array(array('A', 'B', 'C'), array('a', 'b', 'c')))));
    }          
    
    public function testInArrayStrict() {
        $a = XN_Content::create('Foo');
        $b = XN_Content::create('Foo');
        $array = array($a);
        $this->assertTrue(in_array($a, $array, true));
        $this->assertFalse(in_array($b, $array, true));
    }    
    
}

?>


