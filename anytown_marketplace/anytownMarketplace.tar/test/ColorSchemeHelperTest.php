<?php
require_once 'PHPUnit.php';

$colorSchemeChooserClassOnly = true;
require_once 'colorSchemeChooser.php';

class ColorSchemeHelperTest extends PHPUnit_TestCase {    
    
    public function testHexToRGBUppercase() {
        $RGB = ColorSchemeHelper::hexToRGB('FF0000');
        $this->assertEquals(255, $RGB[0]);
        $this->assertEquals(0, $RGB[1]);
        $this->assertEquals(0, $RGB[2]);        
    }         
    public function testRGBToHex() {
        $this->assertEquals('00ff00', ColorSchemeHelper::rgbToHex(array(0, 255, 0)));        
    }             
    public function testExpandHex() {
        $this->assertEquals('00ff00', ColorSchemeHelper::expandHex('00ff00'));
        $this->assertEquals('aabbcc', ColorSchemeHelper::expandHex('abc'));
    }
    public function testHexToRGBLowercase() {
        $RGB = ColorSchemeHelper::hexToRGB('0000ff');
        $this->assertEquals(0, $RGB[0]);
        $this->assertEquals(0, $RGB[1]);
        $this->assertEquals(255, $RGB[2]);        
    }         
    public function testCorrectOvershoot() {
        $this->assertEquals(123, ColorSchemeHelper::correctOvershoot(123));
        $this->assertEquals(0, ColorSchemeHelper::correctOvershoot(360));
        $this->assertEquals(359, ColorSchemeHelper::correctOvershoot(359));
        $this->assertEquals(0, ColorSchemeHelper::correctOvershoot(0));
        $this->assertEquals(359, ColorSchemeHelper::correctOvershoot(-1));
    }
    public function testScale() {
        $this->assertEquals(100, ColorSchemeHelper::scale(10, 10, 20, 100, 200));
        $this->assertEquals(200, ColorSchemeHelper::scale(20, 10, 20, 100, 200));
        $this->assertEquals(125, ColorSchemeHelper::scale(12.5, 10, 20, 100, 200));
        $this->assertEquals(150, ColorSchemeHelper::scale(15, 10, 20, 100, 200));
        $this->assertEquals(90, ColorSchemeHelper::scale(9, 10, 20, 100, 200));
        $this->assertEquals(210, ColorSchemeHelper::scale(21, 10, 20, 100, 200));
    }
    public function testAngleDifference() {
        $this->assertEquals(18, ColorSchemeHelper::angleDifference(342, 0));        
    }        
    public function testShadeOfGray() {
        $this->assertTrue(ColorSchemeHelper::shadeOfGray(5, 5, 5));
        $this->assertFalse(ColorSchemeHelper::shadeOfGray(5, 5, 4));        
    }            
}

?>


