<?php
require_once 'PHPUnit.php';
require_once 'models/Category.php';

class CategoryTest extends PHPUnit_TestCase {            
    
    public function testSerializeCategory() {
        $category = W_Content::create('Category');
        $category->my->xtitle = 'events & classes';
        $category->my->postingsHaveDate = 'Y';
        $category->my->postingsHavePrice = null;
        $category->my->postingsHaveLocation = 'Y';
        $category->my->postingsHaveAge = 'N';
        $category->my->postingsHaveComments = 'N';
        $category->my->postingsHaveMessaging = 'Y';
        $category->my->postingsHaveRatings = 'N';
        $this->assertEquals('<category><attribute name="xtitle">events &amp; classes</attribute><attribute name="postingsHaveDate">Y</attribute><attribute name="postingsHavePrice"></attribute><attribute name="postingsHaveLocation">Y</attribute><attribute name="postingsHaveAge">N</attribute><attribute name="postingsHaveComments">N</attribute><attribute name="postingsHaveMessaging">Y</attribute><attribute name="postingsHaveRatings">N</attribute></category>', Category::serialize($category));
    }    
    
    public function testSerializeSubcategory() {
        $subcategory = XN_Content::create('Subcategory');
        $subcategory->my->xtitle = 'karate & stuff';
        $this->assertEquals('<subcategory>karate &amp; stuff</subcategory>', Category::serializeSubcategory($subcategory));
    }
    
}

?>


