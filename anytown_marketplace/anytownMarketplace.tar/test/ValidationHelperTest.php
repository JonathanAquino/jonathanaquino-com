<?php

require_once 'helpers/ValidationHelper.php';

class Book {
    
   /**
    * @var XN_Attribute::STRING optional
    * @rule length ,10
    */
   public $author;        
   
   /**
    * @var XN_Attribute::STRING optional
    * @rule length(size not good) ,10
    */
   public $author2;     

}

class ValidationHelperTest extends PHPUnit_TestCase {

    public function testValid() {
        $book = W_Content::create('Book');
        $book->import(array('author' => 'Stephen K'));
        $this->assertEquals(0, count(ValidationHelper::validate($book)));
    }
    public function testDefaultErrorMessage() {
        $book = W_Content::create('Book');
        $book->import(array('author' => 'Stephen King'));
        $this->assertEquals(1, count($errors = ValidationHelper::validate($book)));
        $this->assertEquals('Author must have fewer than 10 characters', $errors[0]);
    }
    public function testCustomErrorMessage() {
        $book = W_Content::create('Book');
        $book->import(array('author2' => 'Stephen King'));
        $this->assertEquals(1, count($errors = ValidationHelper::validate($book)));
        $this->assertEquals('Author2 size not good', $errors[0]);        
    }    
    
}

?>
