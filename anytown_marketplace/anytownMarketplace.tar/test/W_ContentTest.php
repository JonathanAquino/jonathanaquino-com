<?php
require_once 'PHPUnit.php';
require_once 'lib/ShapedContent/W_Content.php';

class Film {

   /**
    * @var XN_Attribute::STRING optional
    */
   public $name;  
   
   /**
    * @var XN_Attribute::STRING optional
    */
   public $director;     
       
   /**
    * @var XN_Attribute::STRING
    */
   public $requiredString;   
   
   /**
    * @var XN_Attribute::STRING optional
    */
   public $optionalString;      
   
   /**
    * @var XN_Attribute::NUMBER optional
    */
   public $optionalNumber;      
   
   /**
    * @var XN_Attribute::NUMBER
    */
   public $requiredNumber;       

}

class Person {
   /**
    * @var XN_Attribute::NUMBER optional
    * @rule range 1,100
    */
   public $age;   

   /**
    * @var XN_Attribute::STRING optional
    * @rule choice 0,2
    */
   public $favouriteIceCream;
   public $favouriteIceCream_choices = array('chocolate', 'vanilla', 'strawberry'); 

   /**
    * @var XN_Attribute::STRING optional
    * @rule regex /^on$/
    */     
   public $cool;
   
   /**
    * @var XN_Attribute::DATE optional
    */
   public $birthday;      
}

class W_ContentTest extends PHPUnit_TestCase {
    public function testDateType() {
        $posting = W_Content::create('Person');
        $posting->import(array('birthday' => 'foo'));
        $this->assertEquals(XN_Attribute::DATE, $posting->my->attribute('birthday')->type);
    }        
    public function testCreate() {
        $film = W_Content::create('Film', 'The Burbs');
        $this->assertEquals('The Burbs', $film->title); 
    }
    public function testImport() {
        $film = W_Content::create('Film');
        $film->import(array('director' => 'John Doe', 'name' => 'Star Wars'));
        $this->assertEquals('John Doe', $film->my->director);
        $this->assertEquals('Star Wars', $film->my->name);        
    }    
    
    public function testExport() {
        $film = W_Content::create('Film');
        $film->import(array('requiredString' => 'x', 'requiredNumber' => '123', 'optionalString' => ''));
        $export = $film->export();    
        $this->assertEquals('x', $export['requiredString']);
        $this->assertEquals('123', $export['requiredNumber']);
        $this->assertEquals('', $export['optionalString']);
    }    

    public function testOptionalString() {
        $film = W_Content::create('Film');
        $film->import(array('requiredString' => 'x', 'requiredNumber' => '123', 'optionalString' => ''));
        $this->assertEquals(0, count($film->validate()));
    }
    
    public function testRequiredString() {
        $film = W_Content::create('Film');
        $film->import(array('requiredString' => '', 'requiredNumber' => '123', 'optionalString' => ''));
        $this->assertEquals(1, count($film->validate()));
    }    
    
    public function testOptionalNumber() {
        $film = W_Content::create('Film');            
        $film->import(array('requiredString' => 'x', 'requiredNumber' => '123', 'optionalNumber' => ''));
        $this->assertEquals(0, count($film->validate()));           
        $film->import(array('requiredString' => 'x', 'requiredNumber' => '123', 'optionalNumber' => '123'));
        $this->assertEquals(0, count($film->validate()));
        $film->import(array('requiredString' => 'x', 'requiredNumber' => '123', 'optionalNumber' => 'abc'));
        $this->assertEquals(1, count($film->validate()));     
        $film->import(array('requiredString' => 'x', 'requiredNumber' => '123', 'optionalNumber' => '   123   '));
        $this->assertEquals(1, count($film->validate()));        
    }
    
    public function testRequiredNumber() {
        $film = W_Content::create('Film');               
        $film->import(array('requiredString' => 'x', 'requiredNumber' => ''));
        $this->assertEquals(1, count($film->validate()));
        $film->import(array('requiredString' => 'x', 'requiredNumber' => '123'));
        $this->assertEquals(0, count($film->validate()));
        $film->import(array('requiredString' => 'x', 'requiredNumber' => 'abc'));
        $this->assertEquals(1, count($film->validate()));
        $film->import(array('requiredString' => 'x', 'requiredNumber' => '   123   '));
        $this->assertEquals(1, count($film->validate()));    
    }    
    
    public function testRange() {
        $person = W_Content::create('Person');
        $person->my->set('age', 1, XN_Attribute::NUMBER);
        $this->assertEquals(0, count($person->validate()));
        $person->my->set('age', 0, XN_Attribute::NUMBER);
        $this->assertEquals(1, count($person->validate()));        
        $person->my->set('age', 100, XN_Attribute::NUMBER);
        $this->assertEquals(0, count($person->validate()));        
        $person->my->set('age', 101, XN_Attribute::NUMBER);
        $this->assertEquals(1, count($person->validate()));                
    }    
    
    public function testChoice() {
        $person = W_Content::create('Person');
        $person->my->favouriteIceCream = 'chocolate';
        $this->assertEquals(0, count($person->validate()));
        $person->my->favouriteIceCream = 'rockyroad';
        $this->assertEquals(1, count($person->validate()));
    }        
    
    public function testNullOrEmptyString() {
        $this->assertTrue(null_or_empty_string(null));
        $this->assertTrue(null_or_empty_string(''));
        $this->assertFalse(null_or_empty_string(' '));
        $this->assertFalse(null_or_empty_string(0));
        $this->assertFalse(null_or_empty_string(0.0));
    }
    
    public function testRegex() {
        $person = W_Content::create('Person');
        $person->my->cool = 'on';
        $this->assertEquals(0, count($person->validate()));
        $person->my->cool = '';
        $this->assertEquals(0, count($person->validate()));
        $person->my->cool = null;
        $this->assertEquals(0, count($person->validate()));        
        $person->my->cool = 'blah';
        $this->assertEquals(1, count($person->validate()));        
    }       
    
}

?>


