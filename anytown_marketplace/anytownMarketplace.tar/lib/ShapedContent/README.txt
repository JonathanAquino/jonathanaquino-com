---------- Forwarded message ----------
From: david
To: phil, jon, briam
Date: Mon, 24 Oct 2005 17:44:16 -0400
Subject: shaped content update
Hey, Guys. Here are some docs as well as updated W_Content.php and
W_Shape.php classes. W_Content is made much simpler due to a decision
that Brian, Jon, and I made last week, which is that shaped content
objects get validated when they are saved (or on demand by the
developer) not each time a property is set.)

The Shaped-Content.txt doc is a more fleshed out description of how
W_Shape and W_Content work together. It also highlights various
outstanding issues, bugs, and things that still need to get done.

I'm working on a sample ex-app to have all this code running in it. It's
inactive now since I don't want random folks cloning and using the code
just yet. We'll obviously have to come up with a better way of
exchanging this and the other framework code, though.

David


The W_Shape and W_Content classes are responsible for managing a way
of expressing content shape in PHP and of integrating that content
shape with an XN_Content object.

The W_Shape class understands the PHP syntax for expressing content shape and exposes a programmatic interface to that shape: accessing attribute names, types, and constraints. It also generates PHP code representing a particular content shape.

The W_Content class is a shape-aware replacement for XN_Content. The differences between it and XN_Content are:

- It needs a defined shape class corresponding to the content type of each object it works with.

- Calling an instance method on a W_Content object does the following:
  - if a method with the matching name exists in the shape class, it is called
  - next, if a method with the matching name exists in XN_Content, it is called
  - if neither class contains a matching method, it throws an exception

- W_Content has the following methods that do not exist in XN_Content:
  - validate(): this validates the developer attributes in the object against the rules and constraints in the shape class. It returns an array of error message arrays. The keys in the returned array are attribute names, the values are arrays of error messages.
  - import(): this accepts an associative array of attribute name => value pairs and sets the corresponding developer attributes in the object.
  - export(): this returns an associative array of the developer attribute name/values in the object.

[ Current outstanding issues:
- how import() and export() should deal with multi-valued/array-valued attributes  as well as attribute types and providing arbitrary pack/unpack methods to transform atttribute values as they come out of the content store or before they are put into the content store.
- forcing validate() on save() ]

W_Shape handles building a programmatic representation of content shape given a PHP class. The PHP class that describes content shape looks something like this:

class Film {

    /**
     * The title of the film
     *
     * @var XN_Attribute::STRING
     * @rule length 10,100
     */
    public $title;

    /**
     * The director of the film
     *
     * @var Director
     */
    public $director;

    /**
     * A short description of the film, but one which captures the film's
     * majesty
     *
     * @var XN_Attribute::STRING optional
     * @label Film's Description but again one with majesty
     * @rule length 10,1000
     */
    public $description;

    /**
     * How much the film cost to make
     *
     * @var XN_Attribute::NUMBER
     */
    public $cost;

    /**
     * The Rating from the MPAA
     *
     * @var XN_Attribute::STRING
     * @label MPAA Rating
     * @rule choice 1,1
     */
    public $rating;
    public $rating_choices = array('G','PG','PG-13','R','NC-17','X','NR');

/** xn-ignore-start 2365cb7691764f05894c2de6698b7da0 **/
/** You can put any additional property definitions
 * anywhere you want but other code (other variables,
 * methods, etc.) should go below here */

    public function goodForKids() {
        return (($this->rating == 'G') ||
                ($this->rating == 'PG'));
    }

/** You can put any additional property definitions
 * anywhere you want but other code (other variables,
 * methods, etc.) should go above here */
/** xn-ignore-end 2365cb7691764f05894c2de6698b7da0 **/

}

The class name corresponds to the content type of the shaped object. Each public property of the class preceded by a docblock comment is considered an attribute of the shaped content object. The docblock comments should consist of a description, followed by a blank " * " line, followed by a number of docblock tags.

The only mandatory docblock tag is @var. It indicates the type of the property. Allowable values for @var are the various XN_Attribute::TYPE constants and content types. That is: "@var XN_Attribute::STRING" indicates that the variable is a string. "@var Elephant" indicates that the variable is a content object of type Elephant.

All properties are required by default. To make a property optional, add the word "optional" after the type: "@var XN_Attribute::STRING optional"

The optional @label tag allows specifying a display label different than the property name.

There can be an arbitrary number of @rule tags. Each @rule tag indicates a constraint on the value (if supplied). The general syntax of a @rule tag is:

@rule name argument

Rules generally have built-in error messages. If you want to specify your own custom error message, write the rule like this:

@rule name(error message) argument

The W_Content knows about the following rules:

length
range
regex
choice

The length rule indicates allowable length for the property value. The argument should be the minimum and maximum allowable length. More than 0 and less than 10 characters:

@rule length 0,10

More than 5 characters (no upper bound):

@rule length 5
@rule length 5,

Less than 100 characters (no lower bound):

@rule length ,100

Essentially the same thing:

@rule length 0,100

The range rule indicates allowable values for the property. It only makes sense (currently) for number properties. Greater than 0, less than 100:

@rule range 0,100

Greater than 10:

@rule range 10
@rule range 10,

Less than 100:

@rule range ,100

Greater than -40 and less than 212:

@rule range -40,212

The regex rule matches a regular expression. You probably want to specify a custom message with the regex rule:

@rule regex(should be only letters and numbers) /^[a-zA-Z0-9]+$/

The choice rule indicates that the value must be picked from a list.

Just 1 choice from the list:

@rule choice 0,2

At least one but less than 5 choices:

@rule choice 0,6

With the choice rule, you need to specify the list of allowable choices. Do that by including a public property in the class named $whatever_choices, where $whatever is the attribute that has the choice rule applied to it. For example:

    /**
     * The Rating from the MPAA
     *
     * @var string
     * @label MPAA Rating
     * @rule choice 0,2
     */
    public $rating;
    public $rating_choices = array('G','PG','PG-13','R','NC-17','X','NR');


[ Outstanding issues:
-- references to $this->rating like in the sample goodForKids() method won't actually work right now. They should, but we need to figure out how to properly distinguish between developer and system attributes
-- all vars in the shape class (even title and description) are considered to be developer attributes
-- The /** xn-ignore-start **/ and friends comments are necessary to indicate what should be kept as-is when the shape classes are re-written by setup tools that gather shape info from web-based tools. (Required by the generic reviews and generic social networking apps in development.) Should we get rid of the hashes to simplify things? (Might make matching more error-prone.)
-- Validation of content types doesn't work yet.
-- range rule and dates
-- Alternate rule syntax:

@rule maxlength 100
@rule minlength 10

instead of @rule length 10,100

This makes leaving out either endpoint look better.

-- How to indicate >= or <= instead of > and < with rules:

@rule length [10,100]

Something else? Should the rules be inclusive by default and you use additional syntax to exclude the endpoints?


]







