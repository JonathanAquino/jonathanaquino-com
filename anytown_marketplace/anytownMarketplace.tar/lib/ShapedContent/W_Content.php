<?php

/*
Note: This was an early version of the ShapedContent framework. It has since moved on
to be bigger and better. In this version, there are likely bugs in parts of the code that I'm not
using. So be sure to thoroughly test your code if it uses those parts. [Jon Aquino 2005-11-04]
*/

require_once 'W_Shape.php';
require_once 'XN/Content.php';
require_once 'XN/Debug.php';

function null_or_empty_string($x) {
    return is_null($x) || strlen($x) == 0;
}

class W_Content {
    public $_xn_content;
    
    /* Need to explicitly declare XN_Content's static methods here */
    public static function create($type, $title=null, $description=null){
        return new W_Content($type, $title, $description);
    }
    public static function load($content) {
        return new W_Content(XN_Content::load($content));
    }
    public static function delete($content) {
        return XN_Content::delete($content instanceof W_Content ? $content->_xn_content : $content);
    }
    public static function deleteCascade($content) {
        return XN_Content::deleteCascade($content instanceof W_Content ? $content->_xn_content : $content);
    }

    /* Build from XN_Content or type/title/description */
    public function __construct($type, $title = null, $description = null) {
        if ($type instanceof XN_Content) {
            W_ShapeCache::put($type->type);
            $this->_xn_content = $type;
        } else {
            W_ShapeCache::put($type);
            $this->_xn_content = XN_Content::create($type,$title,$description);
        }
    }
    
    public function __get($prop) {
        return $this->_xn_content->{$prop};
    }
    
    public function __set($prop, $value) {
        return $this->_xn_content->{$prop} = $value;
    }
    
    /* Pass method call on to method in shape object if it exists,
     * then try XN_Content object
     */
    public function __call($method, $args) {        
        $shapeObject = W_ShapeCache::get($this->type)->shape;
        if (is_callable(array($shapeObject,$method))) {
            return call_user_func_array(array($shapeObject, $method), $args);
        } elseif (is_callable(array($this->_xn_content, $method))) {            
            return call_user_func_array(array($this->_xn_content, $method), $this->unwrap($args));        
        } else {
            throw new Exception("Unknown method: $method");
        }
    }    
    
    private function unwrap($args) {
        $unwrappedArgs = array();
        foreach ($args as $arg) {
            $unwrappedArgs[] = $arg instanceof W_Content ? $arg->_xn_content : $arg;
        }
        return $unwrappedArgs;
    }

    public function import($newValues) {
        if (! is_array($newValues)) {
            throw new Exception("W_Content::import() expects an array");
        }
        // @todo pack/unpack?
        $attrs = W_ShapeCache::get($this->type)->attrs;
        foreach ($newValues as $name => $value) {      
            if ($attrs[$name]) {
                if ($attrs[$name]->type == XN_Attribute::NUMBER && $value == '') { $value = null; }
                $this->_xn_content->my->set($name, $value, $attrs[$name]->type);            
            }
        }
    }

    public function export() {
        $values = array();
        $attrs = W_ShapeCache::get($this->type)->attrs;
        // @todo pack/unpack
        foreach ($attrs as $attrName => $attr) {
            $values[$attrName] = $this->my->{$attrName};
        }
        return $values;
    }
    
    public function validate() {
        $errors = array();
        $attrs = W_ShapeCache::get($this->type)->attrs;        
        $shape = W_ShapeCache::get($this->type)->shape;        
        // @todo title vs. my->title
        foreach ($attrs as $attrName => $attr) {
            $err = self::validateAttribute($attr,$shape,$this->my->{$attr->name});
            if (count($err)) {
                $errors[$attrName] = $err;
            }
        }
        return $errors;
    }    
    
    public static function validateAttribute($attr, $shape, $value) {
        $errors = array();
        switch ($attr->type) {
        case XN_Attribute::NUMBER:
            if (!null_or_empty_string($value) && strval($value) != strval(doubleval($value))) {
                $errors[] = "must be a number";
            }
            break;
            // @todo: validation for other types
        }
        
        if (is_array($attr->rules)) {
            foreach ($attr->rules as $rule) {
                $ruleClass = "W_Content_Rule_{$rule->name}";
                if ((class_exists($ruleClass) &&
                     is_subclass_of($ruleClass,'W_Content_Rule'))) {
                    // @todo makes sure *_choices exists
                    $arg = ($rule->name == 'choice') ? array($rule->arg,
                                                             $shape->{$attr->name.'_choices'}) : $rule->arg;
                    $err = call_user_func_array(array('W_Content_Rule_'.$rule->name,'validate'),
                                                array($value, $arg, $rule->msg));
                    if (! is_null($err)) {
                        $errors[] = $err;
                    }
                }
            }
        }
        
        return $errors;
    }
}

abstract class W_Content_Rule {
    protected static $message;
    abstract public static function validate($value, $arg = null, $msg = null);
    protected function msg($msg, $default) { 
        return isset($msg) ? $msg : $default; 
    }
}

class W_Content_Rule_required extends W_Content_Rule {
    protected static $message = 'is required';
    public static function validate($value, $arg = null, $msg = null) {
	if ($arg && (! strlen($value))) {
	    return self::msg($msg, self::$message);
	}
    }
}

class W_Content_Rule_length extends W_Content_Rule {
    public static function validate($value, $arg = null, $msg = null) {
	list($min,$max) = explode(',',$arg);
	$minl = intval($min);
	$maxl = intval($max);
	$valuel = strlen($value);
	// @todo check that $min and $max are valid ints?
	if ($minl && $maxl) {
	    if (($valuel < $min) || ($valuel > $max)) {         
		return self::msg($msg,"must have more than $min and fewer than $max characters");
	    }
	} elseif ($minl) {
	    if ($valuel < $min) {
		return self::msg($msg,"must have more than $min characters");
	    }
	} elseif ($maxl) {
	    if ($valuel > $max) {
		return self::msg($msg,"must have fewer than $max characters");
	    }
	} else {
	    throw new Exception("Invalid length rule argument: $arg");
	}
    }
}

class W_Content_Rule_range extends W_Content_Rule {
    public static function validate($value, $arg = null, $msg = null) {
    if (null_or_empty_string($value)) { return; }
 	list($min,$max) = explode(',',$arg);
	$minl = strlen($min);
	$maxl = strlen(max);
	// @todo check that $min and $max are valid ints?	
	if ($minl && $maxl) {
	    if (($value < $min) || ($value > $max)) {
		return self::msg($msg,"must be more than $min and less than $max");
	    }
	} elseif ($minl) {
	    if ($value < $min) {
		return self::msg($msg,"must be more than $min");
	    }
	} elseif ($maxl) {
	    if ($value > $max) {
		return self::msg($msg,"must be less than $max");
	    }
	} else {
	    throw new Exception("Invalid range rule argument: $arg");
	}
    }
}

class W_Content_Rule_regex extends W_Content_Rule {
    protected static $message = 'must match pattern';
    public static function validate($value, $arg = null, $msg = null) {
    if (null_or_empty_string($value)) { return; }
	// @todo forbid /e in patterns?
	$match = @preg_match($arg, $value);
	if ($match === false) {
	    throw new XN_IllegalArgument_Exception("Can't match against bad pattern: $arg");
	} elseif ($match == 0) {
	    return self::msg($msg, self::$message);
	}
    }
}

class W_Content_Rule_choice extends W_Content_Rule {
    // how to get in both the number of choices and the choice list?
    public static function validate($value, $arg = null, $msg = null) {
       if (null_or_empty_string($value)) { return; }
       $choices = $arg[1];
       list($minc,$maxc) = explode(',',$arg[0]);
       $minl = strlen($minc);
       $maxl = strlen($maxc);
       $valuec = count($value);
       // @todo check that $min and $max are valid ints?       
       if ($minl && $maxl) {
           if (($minc == $maxc) && ($valuec != $minc)) {
               return self::msg($msg,"must be exactly one choice");
           } elseif (($valuec < $minc) || ($valuec > $maxc)) {
               return self::msg($msg,"must be more than $min choices and fewer than $max choices");
           }
       } elseif ($minl) {
           if ($valuec < $minc) {
               return self::msg($msg,"must be more than $minc choices");
           }
       } elseif ($maxl) {
           if ($valuec > $maxc) {
               return self::msg($msg,"must be fewer than $maxc choices");
           }
       } else {
           throw new Exception("Invalid choice rule argument: {$arg[0]}");
       }
       // Now that the number of choices has been verified, makes sure they're each valid
       // @todo there is probably a better way to do this with array_intersect or something
       if (!is_array($value)) {
           $value = array($value);
       }
       foreach ($value as $v) { if (! in_array($v, $choices)) { return self::msg($msg,"must be a valid choice"); } }
    }
}
