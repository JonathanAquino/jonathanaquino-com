<?php

/*
Note: This was an early version of the ShapedContent framework. It has since moved on
to be bigger and better. In this version, there are likely bugs in parts of the code that I'm not
using. So be sure to thoroughly test your code if it uses those parts. [Jon Aquino 2005-11-04]
*/

class W_Shape {
    public $_xn_shape;
    public $_xn_attrs;
    public $_xn_content_type;
    public $_xn_code;
    public $_xn_code_hash;
    protected $_xn_nl;
    protected $_xn_tokens = array();
    protected $_xn_source;

    const IGNORE_BLOCK_HEADER ='
/** You can put any additional property definitions
 * anywhere you want but other code (other variables,
 * methods, etc.) should go below here */
';

    const IGNORE_BLOCK_FOOTER = '
/** You can put any additional property definitions
 * anywhere you want but other code (other variables,
 * methods, etc.) should go above here */ 
';

    public function __construct($className) {
        $this->_xn_content_type = $className;
        // @todo Or load?
        $this->_xn_shape = new $className;
        $refl = new ReflectionClass($className);
        
        // Load source and tokenize
        $eol = ini_get('auto_detect_line_endings');
        ini_set('auto_detect_line_endings',true);
        $codeLines = file($refl->getFileName());
        ini_set('auto_detect_line_endings',$eol);
        preg_match("/[\r\n]+\$/",$codeLines[0],$matches);
        $this->_xn_nl = $matches[0];
        $this->_xn_source  = implode('',array_slice($codeLines,
                                                    $refl->getStartLine() - 1,
                                                    $refl->getEndLine() - $refl->getStartLine()));
        
        // Make sure we're in PHP mode when the tokenizer runs
        if (! preg_match('/^\s*<?php/',$this->_xn_source)) {
            $this->_xn_source = "<?php" . $this->_xn_nl .$this->_xn_source;
        }
        
        // Prepare whitespaceless token list
        foreach (token_get_all($this->_xn_source) as $token) {
            if (is_array($token)) {
                if ($token[0] != T_WHITESPACE) {
                    $this->_xn_tokens[] = $token;
                }
            } else {
                $this->_xn_tokens[] = array(T_STRING,$token);
            }
        }
        
        list($this->_xn_code_hash,
             $this->_xn_code) = self::getUserCode($this->_xn_source);

        foreach (self::getDocComments($this->_xn_tokens) as $comment) {
            $this->processDocComment($comment[0], $comment[1]);
        }
    }
    
    public function __get($prop) {
        switch ($prop) {
        case 'shape':
            return $this->_xn_shape;
            break;
        case 'attrs':                
            return $this->_xn_attrs;
            break;
        default:
            throw new Exception("Unknown property: $prop");
            break;
        }
    }
    
    public function toPHP() {
        $pfx = '    ';
        $php = $this->_xn_nl . "class {$this->_xn_content_type} {" . $this->_xn_nl;
        if (is_array($this->_xn_attrs)) {
            foreach ($this->_xn_attrs as $attrName => $attr) {
                $php .= $attr->toPHP($pfx, $this->_xn_nl);
            }
        }
        if (! $this->_xn_code_hash) {
            $this->_xn_code_hash = md5(uniqid());
        }
            $php .= $this->_xn_nl . "/** xn-ignore-start $this->_xn_code_hash **/";
            $php .= self::IGNORE_BLOCK_HEADER;
            if (isset($this->_xn_code)) { $php .= $this->_xn_code; }
            $php .= self::IGNORE_BLOCK_FOOTER;
            $php .= "/** xn-ignore-end $this->_xn_code_hash **/" . $this->_xn_nl;
        
        $php .= $this->_xn_nl . '}' . $this->_xn_nl;
        return $php;
    }


    protected static function getUserCode(&$code) {
        if (preg_match('@/\*\* xn-ignore-start ([a-f0-9]{32}) \*\*/'.str_replace("\n","(?:\n|\r|\r\n)",preg_quote(self::IGNORE_BLOCK_HEADER,'@')).'(.*)'.str_replace("\n","(?:\n|\r|\r\n)",preg_quote(self::IGNORE_BLOCK_FOOTER,'@')).'/\*\* xn-ignore-end \\1 \*\*/@s',$code,$matches)) {
            return array($matches[1],$matches[2]);
        } else {
            return array(null,null);
        }
    }


    // We must parse the doc comments ourself since PHP 5.0 doesn't have
    // ReflectionProperty::getDocComment.
    //
    // Build a whitespace-less array of regularized tokens
    protected static function getDocComments(&$tokens) {
        $comments = array();
        foreach ($tokens as $i => $token) {
            if (($token[0] == T_DOC_COMMENT) &&          // Doc comment 
            self::is_token($tokens, $i+1,T_PUBLIC) &&    // Followed by a public
            self::is_token($tokens, $i+2,T_VARIABLE) && // Variable
            ($tokens[$i+2][1]{1} != '_')) {               // That doesn't begin with _
                // Trim off the leading $
                $var = substr($tokens[$i+2][1], 1);
                $comments[] = array($var, $token[1]);
            }
        }
        
        return $comments;
    }
    
    protected function processDocComment($var, $text) {
        $attr = new W_Shape_Attribute();
        $attr->name = $var;
        list($description,$info) = self::parseDocComment($text);
        $attr->description = $description;
        
        if (isset($info['var'])) {
            list($attr->type,$typeOptions) = self::parseType($info['var']);
        }
        // If the type options indicate that this not optional, add a required rule to
        // the stack
        if (! $typeOptions['optional']) {
            $attr->rule('required',true);
        }
        if (isset($info['rule'])) {
            if (! is_array($info['rule'])) {
                $info['rule'] = array($info['rule']);
            }
            foreach ($info['rule'] as $rule) {
                $ruleObj = self::parseRule($rule);
                $attr->rule($ruleObj);
                if ($ruleObj->name == 'choice') {

                $choiceString = '';
                $i = 0; $done = false; $tokenCount = count($this->_xn_tokens);
                while (($i < $tokenCount) && (! $done)) {
                  if (self::is_token($this->_xn_tokens, $i,T_PUBLIC) &&      // public
                      self::is_token($this->_xn_tokens, $i+1,T_VARIABLE) && // variable
                      ($this->_xn_tokens[$i+1][1] == '$'.$var.'_choices')) {      // named $attr_choices
                      if ($this->_xn_tokens[$i+2][1] != '=') {
                         $done = true;
                      } else {
                         $i = $i+3; // skip past the =
                         while(($i < $tokenCount) && 
                               ($this->_xn_tokens[$i][0] != T_VAR) &&
                               ($this->_xn_tokens[$i][0] != T_PUBLIC) &&
                               ($this->_xn_tokens[$i][0] != T_PRIVATE) &&
                               ($this->_xn_tokens[$i][0] != T_PROTECTED) &&
                               ($this->_xn_tokens[$i][0] != T_FUNCTION) &&
                               ($this->_xn_tokens[$i][0] != T_STATIC) &&
                               ($this->_xn_tokens[$i][0] != T_DOC_COMMENT)) {
                               $choiceString .= $this->_xn_tokens[$i][1];
                               $i++;
                         }
                         $done = true;
                      }
                   } else { $i++; }
                } 
                // Trim the trailing ; off of $choiceString
                $attr->choices = substr($choiceString,0,-1);
            }
          }
        }
        if (isset($info['label'])) {
            // @todo validate array struct
            $attr->label = $info['label'];
        }
        $this->_xn_attrs[$var] = $attr;
    }
    
  protected static function parseType($typeString) {
      // defaults for type options
      $typeOptions = array('optional' => false);
      $typeDetails = explode(' ',$typeString);
      $type = array_shift($typeDetails);
      // Validate the type
      // Convert a string like "XN_Attribute::DATE" into the
      // constant value. Check for ^XN_Attribute::*$ here?
      if (defined($type)) {
          $type = constant($type);
      } else {
          // type must be a class
          // we could validate that here, too
      }
      foreach ($typeDetails as $detail) {
          if ($detail == 'optional') {
              $typeOptions['optional'] = true;
          }
      }
      return array($type, $typeOptions);             
  }
  
  protected static function parseRule($rule) {
      /* rules either look like
       rule-name<whitespace>arg
       rule-name(message)arg
       @todo support for nested parens
      */
      if (preg_match('/^([^()\s]+)\s+(.*)$/',$rule, $matches)) {
          return new W_Shape_Rule($matches[1], $matches[2], null);
      } elseif (preg_match('/^([^()\s]+)\((.+?)\)\s+(.*)$/',$rule,$matches)) {
          return new W_Shape_Rule($matches[1], $matches[3], $matches[2]);
      } else {
          throw new XN_IllegalArgumentException("Unparseable rule: $rule");
      }
  }
  
  protected static function is_token(&$tokens, $index, $token) {
      return (($index < count($tokens)) &&
              ($tokens[$index][0] == $token));
  }
  
  protected static function parseDocComment($comment) {
      $description = '';
      $tags = array();
      // Windows LB -> Unix LB
      $comment = str_replace("\r\n","\n",$comment);
      // Mac LB -> Unix LB
      $comment = str_replace("\r","\n",$comment);
      // Remove initial /** and trailing */
      $comment = preg_replace('@^/\*\*@','',$comment);
      $comment = preg_replace('@\*/$@','',$comment);
      // Remove leading and trailing whitespace
      $comment = trim($comment);
      // Remove whitespace-star-whitespace at the beginning of each line
      $comment = preg_replace('@^\s*\*[ \t]+@m','',$comment);
      // Everything up to the first @ is the description
      $firstAt = strpos($comment, '@');
      if ($firstAt === false) {
          // @todo Error here if no @props defined?
          $description = $comment;
          $comment = '';
      } else {
          $description = substr($comment,0,$firstAt);
          $comment = substr($comment,$firstAt);
      }
      // Clean trailing whitespace-star from $description and $comment
      $description = preg_replace('@\s+\*\s*$@','',$description);
      $comment = preg_replace('@\s+\*\s*$@','',$comment);        
      // Clean and remaining trailing whitespace from $description and $comment
      $description = rtrim($description);
      $comment = rtrim($comment);
      // Replace newlines in description with spaces, where necessary
      $description = preg_replace("@(\S)\n(\S)@",'\\1 \\2',$description);
      $description = str_replace("\n",' ',$description);
      // Replace newlines in comment with spaces where necessary
      $comment = preg_replace('/(\S)\n([^@\s])/','\\1 \\2',$comment);
      $comment = preg_replace('/(\s)\n([^@\s])/','\\1\\2',$comment);
      // Chop up $comment into pieces
      $parts = explode("\n", $comment);
      foreach ($parts as $part) {
          list($keyword, $arg) = explode(' ',$part,2);
          // Remove @ from keyword
          $keyword = substr($keyword,1);
          if (isset($tags[$keyword])) {
              if (is_array($tags[$keyword])) {
                  $tags[$keyword][] = $arg;
              } else {
                  $tags[$keyword] = array($tags[$keyword], $arg);
              }
          } else {
              $tags[$keyword] = $arg;
          }
      }
      return array($description,$tags);
  }
  
  protected static function print_tokens($tokens) {
      foreach ($tokens as $t) {
          printf("%15s -> %s\n",token_name($t[0]),$t[1]);
      }
  }
}

class W_Shape_Rule {
    public $name; public $arg; public $msg;
    public function __construct($name,$arg,$msg) {
        $this->name = $name;
        $this->arg = $arg;
        $this->msg = $msg;
    }
    
    public function toPHP($nl = "\n") {
        $ruleString = $this->name;
            if (isset($this->msg)) {
                $ruleString .= '(' . $this->msg .')';
            }
            if (isset($this->arg)) {
                $ruleString .= ' ' . $this->arg;
            }
            $php .= "{$pfx} * @rule $ruleString" . $nl;
            return $php;
    }
    
    public function defaultMsg($msg) {
        return isset($this->msg) ? $this->msg : $msg;
    }
}

class W_Shape_Attribute {
    protected $_info = array('name' => null, 'type' => null, 
                             'label' => null, 'description' => null,
                             'choices' => null);
    protected $_rules = array();
    
    public function __get($prop) {
        if ($prop == 'rules') {
            return $this->_rules;
        } elseif (array_key_exists($prop, $this->_info)) {
            return $this->_info[$prop];
        }
    }
    
    public function __set($prop, $value) {
        if (array_key_exists($prop, $this->_info)) {
            return $this->_info[$prop] = $value;
        }
    }
    
    public function rule($name, $arg = null, $msg = null) {
        if ($name instanceof W_Shape_Rule) {
            $this->_rules[] = $name;
        } else {
            $this->_rules[] = new W_Shape_Rule($name,$arg,$msg);
        }
    }
    
    public function toPHP($pfx, $nl = "\n") {
        // Build the PHP for rules
        // For the required rule, don't include a @rule line
        // But instead alter the $optional variable
        $rulePHP = '';
        $optional = ' optional';
        foreach ($this->rules as $rule) {
            if ($rule->name == 'required') {
                if ($rule->arg == true) {
                    $optional = '';
                }
            } else {
                $rulePHP .= "{$pfx}".$rule->toPHP($nl);
            }
        }
        $labelPHP = strlen($this->label) ?
            (wordwrap("{$pfx} * @label ".$this->label,75, "\n{$pfx} * ").$nl) : '';
        $description = wordwrap("{$pfx} * ".$this->description,75,"\n{$pfx} * ");

        $php ="
{$pfx}/**{$nl}{$description}{$nl}{$pfx} *{$nl}{$pfx} * @var {$this->type}$optional{$nl}$labelPHP$rulePHP{$pfx} */{$nl}{$pfx}public \${$this->name};{$nl}";
    if (strlen($this->choices)) {
        $php .= "{$pfx}public \${$this->name}_choices = {$this->choices};{$nl}";
    }
    
    return $php;
    }
}


/**
 * Cache for parsed content shape classes.
 */
 class W_ShapeCache {
    private static $cache;
    
    public static function get($class) {
        if (! isset(self::$cache[$class])) {
            self::put($class);
        }
        return self::$cache[$class];
    }

    public static function put($class) {
        // @todo No staleness checking for now
        self::$cache[$class] = new W_Shape($class);
    }        
}
    


