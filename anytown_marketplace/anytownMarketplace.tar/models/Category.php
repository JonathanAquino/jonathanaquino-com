<?php

class Category {

    /**
     * @var XN_Attribute::STRING
     * @rule length ,100
     */    
    public $xtitle;
    // Use "xtitle" while we are waiting for W_Content to properly handle "title" [Jon Aquino 2005-10-25]
    // Also waiting for the core to handle "my->title" -- see NING-921 [Jon Aquino 2005-11-02]

    /**
     * @var XN_Attribute::STRING
     * @rule regex /^[YN]$/
     */
    public $postingsHaveDate;    
    
    /**
     * @var XN_Attribute::STRING
     * @rule regex /^[YN]$/
     */
    public $postingsHavePrice;    
    
    /**
     * @var XN_Attribute::STRING
     * @rule regex /^[YN]$/
     */
    public $postingsHaveLocation;    
    
    /**
     * @var XN_Attribute::STRING
     * @rule regex /^[YN]$/
     */
    public $postingsHaveAge;
    
    /**
     * @var XN_Attribute::STRING
     * @rule regex /^[YN]$/
     */
    public $postingsHaveComments;    
    
    /**
     * @var XN_Attribute::STRING
     * @rule regex /^[YN]$/
     */
    public $postingsHaveMessaging;       
    
    /**
     * @var XN_Attribute::STRING
     * @rule regex /^[YN]$/
     */
    public $postingsHaveRatings;         
    
    public static function subcategories($category) {
        $subcategories = array();     
        foreach(self::subcategoryIDs($category) as $subcategoryID) {
            $subcategories[] = XN_Content::load($subcategoryID);
        }        
        return $subcategories;
    }
    
    public static function subcategoryIDs($category) { 
        return $category->my->subcategoryIDs ? explode(' ', $category->my->subcategoryIDs) : array();    
    }    
    
    public static function serialize($category) {
        $xml = '<category>';        
        foreach ($category->export() as $key => $value) {
            $xml .= '<attribute name="' . $key . '">' . htmlentities($value) . '</attribute>';
        }
        foreach (self::subcategories($category) as $subcategory) {
            $xml .= self::serializeSubcategory($subcategory);
        }
        $xml .= '</category>';
        return $xml;
    }
    
    public static function serializeSubcategory($subcategory) {
        return '<subcategory>' . htmlentities($subcategory->my->xtitle) . '</subcategory>'; 
    }
    
    public static function deserialize($categoryXML, $save = true) {
        $category = XN_Content::create('Category');
        foreach ($categoryXML->attribute as $attributeXML) {
            $category->my->set((string)$attributeXML['name'], (string)$attributeXML);
        } 
        $subcategories = array();
        foreach ($categoryXML->subcategory as $subcategoryXML) {
            $subcategory = XN_Content::create('Subcategory');
            $subcategory->my->xtitle = $subcategoryXML;
            if ($save) { $subcategory->save(); }            
            $subcategories[] = $subcategory;
        }
        $category->my->set('subcategoryIDs', implode(' ', Application::ids($subcategories)));
        if ($save) { $category->save(); }
        return $category;
    }    

}

?>
