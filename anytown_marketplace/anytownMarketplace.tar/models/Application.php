<?php

require_once 'helpers/PHPHelper.php';

class Application {

    public static function categoriesSortedByName() {        
        return NingHelper::sortByTitle(PHPHelper::concatenate(array(self::categoriesInColumn(1), self::categoriesInColumn(2), self::categoriesInColumn(3), self::categoriesInColumn(4))));        
    } 
    
    public static function categoriesInColumn($columnNumber) {
        $categories = array();     
        foreach(self::categoryIDsInColumn($columnNumber) as $categoryID) {
            $categories[] = XN_Content::load($categoryID);
        }        
        return $categories;
    }
    
    public static function categoryIDsInColumn($columnNumber) { 
        return self::categoryIDStringForColumn($columnNumber) ? explode(' ', self::categoryIDStringForColumn($columnNumber)) : array();    
    }
    
    public static function categoryIDStringForColumn($columnNumber) {
        return self::instance()->my->raw('column' . $columnNumber . 'CategoryIDs');
    }
    
    public static function ids($xnContentArray) {
        $ids = array();
        foreach ($xnContentArray as $xnContent) {
            $ids[] = $xnContent->id;
        }
        return $ids;
    }
    
    private static $instance;
    
    public static function instance() {
        if (! self::$instance) {
            self::$instance = XN_Query::create('Content')
                    ->filter('type', 'eic', 'Application')
                    ->filter('owner', '=')                                    
                    ->uniqueResult();
            if (! self::$instance) {
                $columns = self::deserialize();
                self::$instance = XN_Content::create('Application');
                self::$instance->my->originalApp = 'AnytownMarketplace';
                self::$instance->my->column1CategoryIDs = implode(' ', self::ids($columns[0]));
                self::$instance->my->column2CategoryIDs = implode(' ', self::ids($columns[1]));
                self::$instance->my->column3CategoryIDs = implode(' ', self::ids($columns[2]));
                self::$instance->my->column4CategoryIDs = implode(' ', self::ids($columns[3]));
                self::$instance->save();
            }
        }
        return self::$instance;
    }            
    
    /**
     * Saves the category/subcategory metadata to cloneable_application_metadata.xml so they
     * will be carried over to clones.
     */
    public static function serialize() {        
        @file_put_contents('cloneable_application_metadata.xml', self::serializeColumns(self::categoriesInColumn(1), self::categoriesInColumn(2), self::categoriesInColumn(3), self::categoriesInColumn(4)));        
    }
    
    public static function deserialize() {
        return self::deserializeColumns(@file_get_contents('cloneable_application_metadata.xml'));
    }
    
    public static function deserializeColumns($xmlString, $save = true) {
        $columns = array();
        $xml = simplexml_load_string($xmlString);
        foreach ($xml->column as $columnXML) {
            $column = array();            
            foreach ($columnXML->category as $categoryXML) {
                $column[] = Category::deserialize($categoryXML, $save);
            } 
            $columns[] = $column;
        }
        return $columns;
    }
    
    public static function serializeColumns($categoriesInColumn1, $categoriesInColumn2, $categoriesInColumn3, $categoriesInColumn4) {
        return '<application>' . self::serializeColumn($categoriesInColumn1) . self::serializeColumn($categoriesInColumn2) . self::serializeColumn($categoriesInColumn3) . self::serializeColumn($categoriesInColumn4) . '</application>'; 
    }
    
    private static function serializeColumn($categoriesInColumn) {        
        $xml = '<column>';
        foreach ($categoriesInColumn as $category) {            
            $xml .= Category::serialize(new W_Content($category));            
        }
        $xml .= '</column>';
        return $xml;
    }    

}

?>
