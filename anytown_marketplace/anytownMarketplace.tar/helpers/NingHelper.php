<?php

require_once 'helpers/AssertionHelper.php';
require_once 'helpers/PHPHelper.php';

class NingHelper {    

    public static function addTags($object, $tagString) {
        try {
            XN_Tag::addTags($object, $tagString);
        } catch (XN_Exception $e) {
            // Get here if one of the tags already exists. Not criticial, so eat it. [Jon Aquino 2005-10-14]
        }
    }        
    
    private static $application;
    
    public static function application() {
        if (self::$application == null) {
            self::$application = XN_Application::load();
        }
        return self::$application;
    }                
    
    public static function sortByTitle($contentArray) {                
        AssertionHelper::assert(usort($contentArray, 'compareByTitle'));
        return $contentArray;
    }        
    
    /**
     * Works around the 100-result limit. Do not use this for queries that return 
     * thousands of results!
     */
    public static function executeQueryWithoutLimit($query) {
        $query->alwaysReturnTotalCount(true);
        $resultArrays = array();             
        do {            
            $query->begin($start = count($resultArrays) == 0 ? 0 : $query->getResultTo());
            $query->end($start + 100);
            $resultArrays[] = $query->execute();
        } while ($query->getResultTo() < $query->getTotalCount());
        return PHPHelper::concatenate($resultArrays);
    }

    public static $cachedCategories = array();
    public static $cachedSubcategories = array();
    
    public static function cacheCategoriesAndSubcategories() {
        // Query all categories and subcategories to cause the PHP API to
        // cache them, thus preventing multiple database hits in calls to
        // XN_Content::load(id) and XN_AttributeContainer::content(name).
        // [Jon Aquino 2005-11-05]
        $query = XN_Query::create('Content')
            ->filter('type', 'eic', 'Category')        
            ->filter('owner', '=');
        self::$cachedCategories = self::executeQueryWithoutLimit($query);
        $query = XN_Query::create('Content')
            ->filter('type', 'eic', 'Subcategory')        
            ->filter('owner', '=');
        self::$cachedSubcategories = self::executeQueryWithoutLimit($query);
    }
    
    /** For debugging */
    public static function cached($object) {
        return in_array($object, self::$cachedCategories, true) || in_array($object, self::$cachedSubcategories, true);
    }    

}

function compareByTitle($a, $b) {
    $aValue = strtolower($a->my->xtitle);
    $bValue = strtolower($b->my->xtitle);
    if ($aValue == $bValue) {
        return 0;
    }
    return ($aValue < $bValue) ? -1 : 1;
}    

?>
