<?php

require_once 'helpers/NingHelper.php';
require_once 'models/Category.php';
require_once 'XNC/Image.php';

class HTMLHelper {              
    
    public static function categoryLink($category) {
        return '<a href="' . self::categorySubcategoryURL($category, null) . '">' . $category->my->h('xtitle') . '</a>';                         
    }
    
    public static function subcategoryLink($category, $subcategory) {
        return '<a href="' . self::categorySubcategoryURL($category, $subcategory) . '">' . $subcategory->my->h('xtitle') . '</a>';                         
    }    
    
    private static function categorySubcategoryURL($category, $subcategory) {
        if ($category->my->postingsHaveDate == 'Y') { 
            // Subtract 24 hours so it works with any timezone [Jon Aquino 2005-11-04]
            $timestamp = time() - (24 * 60 * 60);
            return 'index.php?controller=posting&amp;action=listForDate&amp;categoryID=' . $category->id . '&amp;subcategoryID=' . $subcategory->id . '&amp;date=' . date('Y-m-d', $timestamp);                    
        } else { 
            return 'index.php?controller=posting&amp;action=list&amp;categoryID=' . $category->id . '&amp;subcategoryID=' . $subcategory->id; 
        }             
    }
    
    public static function categorySubcategoryLink($posting, $showCategory, $showSubcategory) { 
        $categorySubcategoryLink = '';            
        if ($showCategory) { $categorySubcategoryLink = '<a class="subcat" href="' . self::categorySubcategoryURL($posting->my->content('category'), null) . '">' . $posting->my->content('category')->my->h('xtitle') . '</a>'; }        
        if ($showSubcategory && $posting->my->content('subcategory')) { $categorySubcategoryLink .= '<a class="subcat" href="' . self::categorySubcategoryURL($posting->my->content('category'), $posting->my->content('subcategory')) . '">' . ($categorySubcategoryLink ? ' &gt; ' : '') . $posting->my->content('subcategory')->my->h('xtitle') . '</a>'; }
        return $categorySubcategoryLink;
    }
    
    /**
     * Generate an HTML list of linked tag words
     *
     * @param array $items Array of tag words
     * @param string $link sprintf()-style link format string
     * @param string optional $delimiter Link delimiter
     * @return string
     */
    public static function tagLinkList($items, $link, $delimiter = ', ') {
        $html = array();        
        if (count($items) == 0) return "None";
        foreach($items as $item => $count) {
            $urlItem = urlencode($item);
            $htmlItem = htmlentities($item, ENT_QUOTES, 'UTF-8');
            $html[] = '<a class="tag" href="' . sprintf($link,$urlItem) . '"><span>' . $htmlItem . '</span></a>';
        }        
        return implode($html, $delimiter);
    }        
    
    public static function popularTagsHTML($content) {
        $popularTags = XN_Query::create('Tag_ValueCount')
            ->filter('content.id','=',$content->id)
            ->order('valuecount','desc')
            ->end(3)->execute();             
        if (count($popularTags) == 0) { return null; }
        return self::tagLinkList($popularTags, 'index.php?controller=' . strtolower($content->type) . '&amp;action=list&amp;tag=%s');            
    }        
    
    public static function cleanBoolean($x) {
        return $x == 'Y' ? 'Y' : 'N';
    }    
    
    /**
     * Set the given attribute of the content object to the image in the POST
     * variables. Does nothing if the image is not present in the POST variables
     * (that is, if the user did not specify an image file to upload).
     */    
    public static function processImage($attributeName, $content) {
        if (! $_POST[$content->type . ':' . $attributeName]) { return; }
        $image = new XNC_Image($content, $attributeName);
        if (! $image->willProcessForm()) { throw new Exception($image->lastError()); }
        if (! $image->processForm()) { throw new Exception($image->lastError()); }
    }          
    
    public static function displayImage($content, $attributeName, $thumbnail) {
        if ($content == null) { return; }
        $image = new XNC_Image($content, $attributeName);
        if (! $image->present()) { return; }
        if ($thumbnail) {
            echo $image->buildDisplay('thumbnail');
        } else {
            echo '<xn:out class="listing" value="${Content[' . $content->id . '].my.' . $attributeName . '}" />';
        }
    }        
    
    public static function removeEvilTags($source) {
        // Code by tREXX [www.trexx.ch], "strip_tags", http://ca3.php.net/manual/en/function.strip-tags.php
        // [Jon Aquino 2005-10-28]
        $allowedTags = '<a><br><b><h1><h2><h3><h4><i><img><li><ol><p><strong><table><tr><td><th><u><ul>';        
        $source = strip_tags($source, $allowedTags);
        return preg_replace('/<(.*?)>/ie', "'<'.self::removeEvilAttributes('\\1').'>'", $source);
    }
    
    private static function removeEvilAttributes($tagSource) {
        $stripAttrib = 'javascript:|onclick|ondblclick|onmousedown|onmouseup|onmouseover|'.
              'onmousemove|onmouseout|onkeypress|onkeydown|onkeyup';        
        return stripslashes(preg_replace("/$stripAttrib/i", 'forbidden', $tagSource));
    }        
    
    public static function extractNumber($string) {
        $x = preg_replace('/[^0-9.]/', '', $string);
        return is_numeric($x) ? floatval($x) : null;
    }    
    
    public static function date($timestamp) {
        return date('M j, Y', $timestamp);
    }
    
    public static function plural($word, $count = 100) {
        if ($word == 'person') { return ($count == 1) ? 'person' : 'people'; }
        return ($count == 1) ? $word : $word.'s';
    }                
    
    private static function linkIf($condition, $url, $text) {
        return $condition ? '<a href="' . $url . '">' . $text . '</a>' : $text;
    }
    
    public static function displayBreadcrumbs($category, $subcategory, $posting, $enableLastLink) { ?>
        <h4 class="breadcrumb">       
            <a href="index.php?controller=posting&action=list"><?php echo NingHelper::application()->name; ?></a>
            <?php 
            if ($category) { 
                echo ' &gt; ' . self::linkIf($enableLastLink || $subcategory || $posting, 
                        self::categorySubcategoryURL($category, null),
                        $category->my->h('xtitle')); 
            }        
            if ($subcategory) { 
                echo ' &gt; ' . self::linkIf($enableLastLink || $posting, 
                        self::categorySubcategoryURL($category, $subcategory),
                        $subcategory->my->h('xtitle'));                
            } 
            if ($posting) { 
                echo ' &gt; ' . self::linkIf($enableLastLink, 
                        'index.php?controller=posting&amp;action=show&amp;categoryID=' . $category->id . '&amp;subcategoryID=' . $subcategory->id . '&amp;id=' . $posting->id,
                        $posting->my->h('xtitle'));
            } 
            if ($_GET['tag']) {
                echo ' &gt; ' . '<a href="index.php?controller=tag&amp;action=list&amp;lastBreadcrumb=Top+Tags">Top Tags</a> &gt; ' . htmlentities($_GET['tag']);
            }            
            if ($_GET['lastBreadcrumb']) {
                echo ' &gt; ' . htmlentities($_GET['lastBreadcrumb']);
            } ?>
        </h4>        
    <?php
    }      
    
    public static function redirect($relative_url) {
        // Code from http://ca3.php.net/header [Jon Aquino 2005-09-09]
        header("Location: http://" . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['PHP_SELF']), '/\\') . "/" . $relative_url);	
    }    
    
    public static function currentURL() {
        // Code from Jennifer, "Getting the current URL with php", http://www.scriptygoddess.com/archives/2003/01/20/getting-the-current-url-with-php/
        // [Jon Aquino 2005-10-31]
        return 'index.php?'.$_SERVER['QUERY_STRING'];
    }
    
    public static function displayErrors($errors) {
        if($errors) { ?>
            <h4 class="systemMsg">
                <ul><li><?php echo implode('</li><li>',$errors) ?></li></ul>
            </h4>        
        <?php
        } 
    }
       
}

?>		       
