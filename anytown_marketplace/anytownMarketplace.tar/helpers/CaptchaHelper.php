<?php

require_once 'Text/CAPTCHA.php';

/**
 * Simply call displayHTML() inside your form, then check matches() inside your form-processing code.
 */
class CaptchaHelper {
    
    // Based on code by Marcus Whitney, "Using PEAR's Text_CAPTCHA to Secure Web Forms",
    // http://phpsec.org/articles/2005/text-captcha.html   [Jon Aquino 2005-10-28]    
    
    public static function displayHTML() { ?>
        Please enter the phrase in the image below:<br />
        <img src="<?php echo createImage() ?>" /><br />        
        <input type="text" name="captcha_phrase" /><br />    
    <?php
    }
    
    public static function matches() {
        return $_POST['captcha_phrase']  == $_SESSION['captcha_phrase'];
    }
    
    private static function createImage() {
        $captcha = Text_CAPTCHA::factory('Image');
        $captcha->init(150, 150);
        $_SESSION['captcha_phrase'] = $captcha->getPhrase();        
        $image = $captcha->getCAPTCHAAsJPEG();
        $filename = 'images/captcha/' . mt_rand() . '.jpg';        
        file_put_contents($filename, $image);
        return $filename;
    }

    /**
     * Deletes captcha images older than 5 minutes. Run this periodically.
     */
    public static function deleteOldImages() {
        // Based on code by Olivier Plathey, "FPDF FAQ",
        // http://www.math.uic.edu/scripts/fpdf153/FAQ.htm   [Jon Aquino 2005-10-28]
        $dir = 'images/captcha';
        $t=time();
        $h=opendir($dir);
        while($file=readdir($h)) {
            $path=$dir.'/'.$file;
            if($t-filemtime($path)>5*60) {
                @unlink($path);
            }
        }
        closedir($h);        
    }
}

?>
