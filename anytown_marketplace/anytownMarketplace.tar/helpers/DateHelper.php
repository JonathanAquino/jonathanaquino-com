<?php

class DateHelper {
    
    public static function dateValid($yyyy, $mm, $dd) {
        return ctype_digit($yyyy) && ctype_digit($mm) && ctype_digit($dd)
              && 1000 <= $yyyy && $yyyy <= 9999
              && 1 <= $mm && $mm <= 12
              && 1 <= $dd && $dd <= 31;
    }         

    public static function addDay($timestamp) {
        // 25 hours, to sidestep DST issues [Jon Aquino 2005-10-27]
        return self::stripHoursMinutesSeconds($timestamp + (25 * 60 * 60));
    }    
    
    public static function stripHoursMinutesSeconds($timestamp) {
        return strtotime(date('Y-m-d', $timestamp)); 
    }
    
    public static function displayCalendar($category) {
        $timestamp = strtotime('last Sunday');                
        $postingsOnCalendarQuery = XN_Query::create('Content')
            ->filter('type', 'eic', 'Posting')
            ->filter('my->category', '=', $category->id)
            ->filter('owner', '=')
            // Use > -1, < +1 rather than >=, <=, which currently do not work with strings (see NING-911) [Jon Aquino 2005-10-27]
            ->filter('my->date', '>', date('c', $timestamp-1))
            ->filter('my->date', '<=', date('c', $timestamp+1 + (4 * 7 * 24 * 60 * 60)))
            ->alwaysReturnTotalCount(true);
        $postingsOnCalendar = $postingsOnCalendarQuery->execute();                
        $linkToEachDay = count($postingsOnCalendar) < $postingsOnCalendarQuery->getTotalCount();                
        if (! $linkToEachDay) {
            $timestampsWithPostings = array();
            foreach ($postingsOnCalendar as $posting) {                        
                $timestampsWithPostings[self::stripHoursMinutesSeconds(strtotime($posting->my->date))] = true;
            }
        } ?>        
        <table id="calendar">
            <tr id="days">
                <th class="sun">S</th>
                <th class="mon">M</th>
                <th class="tue">T</th>
                <th class="wed">W</th>
                <th class="thu">T</th>
                <th class="fri">F</th>
                <th class="sat">S</th>
            </tr>
            <?php
            for($i = 0; $i < 4; $i++) {
                echo '<tr class="week">';
                for ($j = 0; $j < 7; $j++) { ?>
                    <td class="wed<?php if ($timestamp == self::stripHoursMinutesSeconds(time())) { echo ' today'; } ?>"> 
                    <?php
                    if ($linkToEachDay || $timestampsWithPostings[$timestamp]) { ?>
                        <a href="index.php?controller=posting&amp;action=listForDate&amp;categoryID=<?php echo $category->id ?>&amp;date=<?php echo date('Y-m-d', $timestamp); ?>"><?php echo date('j', $timestamp); ?></a>
                    <?php
                    } else { 
                        echo date('j', $timestamp); 
                    }
                    $timestamp = self::addDay($timestamp); ?>
                    </td>
                <?php
                }
                echo '</tr>';
            } ?>            
        </table>        
    <?php
    }
    
}

?>
