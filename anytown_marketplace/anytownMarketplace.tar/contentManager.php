<?php
require_once 'XNC/ContentManager.php';

$mgr = new XNC_ContentManager();
$mgr->go();

?>
