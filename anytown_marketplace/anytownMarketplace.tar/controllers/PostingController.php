<?php

require_once 'config/config.php';
require_once 'XNC/Form.php';
require_once 'lib/ShapedContent/W_Content.php';
require_once 'helpers/SecurityHelper.php';
require_once 'helpers/HTMLHelper.php';
require_once 'helpers/DateHelper.php';
require_once 'helpers/ValidationHelper.php';
require_once 'helpers/PaginationHelper.php';
require_once 'models/Category.php';
require_once 'models/Application.php';
require_once 'models/Posting.php';

class PostingController {    
    
    public static function process($action, $errors = null) {
        
        switch($action) {
            
            default:
                throw new Exception('Unknown action: ' . $action);                            
                
            case 'show':
                // categoryID and subcategoryID are used by the Post link in the header [Jon Aquino 2005-11-02]
                AssertionHelper::assert($_GET['categoryID']);                
                $posting = XN_Content::load($_GET['id']);
                if ($posting->my->content('category') == null) { throw new Exception('Category has been deleted'); }
                $posting->focus();    
                $category = $posting->my->content('category');
                $subcategory = $posting->my->content('subcategory');
                if ($category->my->postingsHaveComments == 'Y' || $category->my->postingsHaveRatings == 'Y') {
                    $comments = Posting::comments($posting);                     
                }
                $form = new XNC_Form(array());
                include 'views/posting/show.php';    
                break;                

            case 'selectCategory':
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsSignedIn())) { return; }
                $categories = Application::categoriesSortedByName();                   
                include 'views/posting/selectCategory.php';   
                break;     
                
            case 'new':
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsSignedIn())) { return; }
                $category = XN_Content::load($_GET['categoryID']);
                $subcategory = $_GET['subcategoryID'] ? XN_Content::load($_GET['subcategoryID']) : null;
                $subcategories = NingHelper::sortByTitle(Category::subcategories($category));
                $form = new XNC_Form(array('displayingUsername' => 'Y', 'allowingMessaging' => 'Y'));
                include 'views/posting/new.php';   
                break;        
            
            case 'create':      
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsSignedIn())) { return; }                                
                $category = XN_Content::load($_GET['categoryID']);
                $posting = W_Content::create('Posting');
                $posting->my->setContent('category', $_GET['categoryID']);
                $posting->my->setContent('subcategory', $_POST['subcategoryID'] ? $_POST['subcategoryID'] : null);
                $posting->my->displayingUsername = 'Y';
                $posting->my->allowingMessaging = 'Y';
                self::validateAndSave($posting, $category, 'new');
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . $posting->my->contentId('category') . '&subcategoryID=' . $posting->my->contentId('subcategory') . '&id=' . $posting->id);                
                break;     
                
            case 'edit':
                // categoryID and subcategoryID are used by the Post link in the header [Jon Aquino 2005-11-02]
                AssertionHelper::assert($_GET['categoryID']);            
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                $category = $posting->my->content('category');
                $subcategory = $posting->my->content('subcategory');
                $subcategories = NingHelper::sortByTitle(Category::subcategories($category));
                $defaults = $posting->export();
                if ($category->my->postingsHaveDate == 'Y' && $defaults['date']) {
                    $defaults['year'] = date('Y', strtotime($defaults['date']));
                    $defaults['month'] = date('m', strtotime($defaults['date']));
                    $defaults['day'] = date('d', strtotime($defaults['date']));
                }
                $form = new XNC_Form($defaults);
                $posting->focus();
                include 'views/posting/edit.php';       
                break;   
                
            case 'update':                                     
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                $category = $posting->my->content('category');
                $posting->my->setContent('subcategory', $_POST['subcategoryID'] ? $_POST['subcategoryID'] : null);
                self::validateAndSave($posting, $category, 'edit');
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . $posting->my->contentId('category') . '&subcategoryID=' . $posting->my->contentId('subcategory') . '&id=' . $posting->id);   
                break;                    
                
            case 'delete':
                $posting = XN_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                $category = $posting->my->content('category');
                $subcategory = $posting->my->content('subcategory');
                XN_Content::delete($posting);
                if ($_GET['targetURL']) {
                    HTMLHelper::redirect($_GET['targetURL']);
                } elseif ($subcategory != null) {
                    HTMLHelper::redirect('index.php?controller=posting&action=list&categoryID=' . $category->id . '&subcategoryID=' . $subcategory->id);
                } else {
                    HTMLHelper::redirect('index.php?controller=posting&action=list&categoryID=' . $category->id);
                }
                break;        
                
            case 'listForDate':                
                $timestamp = DateHelper::stripHoursMinutesSeconds(strtotime($_GET['date']));
                // Use > -1, < +1 rather than >=, <=, which currently do not work with strings (see NING-911) [Jon Aquino 2005-10-27]
                $query = XN_Query::create('Content')
                    ->filter('my->date', '>', date('c', $timestamp-1));              
                if ($_GET['categoryID']) {
                    $category = XN_Content::load($_GET['categoryID']); 
                }
                if ($_GET['subcategoryID']) {
                    $subcategory = XN_Content::load($_GET['subcategoryID']); 
                }                        
                $previousWeekURL = 'index.php?controller=posting&amp;action=listForDate&amp;categoryID=' . $_GET['categoryID'] . '&amp;subcategoryID=' . $_GET['subcategoryID'] . '&amp;date=' . date('Y-m-d', strtotime($_GET['date']) - (7 * 24 * 60 * 60));                                      
                self::displayList($category, $subcategory, $query, true, 'asc', $previousWeekURL);
                break;                                                                            
                
            case 'list':                          
                $query = XN_Query::create('Content');
                if ($_GET['query']) {
                    $query->filter('my->searchableText', 'likeic', preg_replace('/[^a-zA-Z]/', ' ', $_GET['query']));
                }
                if ($_GET['by']) {
                    $query->filter('contributorName', '=', $_GET['by']);
                    if (XN_Profile::current()->screenName != $_GET['by']) {
                        // Filter out anonymous postings to protect people's privacy [Jon Aquino 2005-10-31]
                        $query->filter('my->displayingUsername', '=', 'Y');
                    }
                }                
                if ($_GET['tag']) {
                    $query->filter('tag->value','eic',$_GET['tag']);
                }     
                if ($_GET['postingsWithRatingsOnly'] == 'yes') {
                    $query->filter('my->averageRating', '<>', null);
                }
                if (HTMLHelper::extractNumber($_GET['minPrice'])) {
                    $query->filter('my->searchablePrice', '>=', HTMLHelper::extractNumber($_GET['minPrice']));
                }                
                if (HTMLHelper::extractNumber($_GET['maxPrice'])) {
                    $query->filter('my->searchablePrice', '<=', HTMLHelper::extractNumber($_GET['maxPrice']));
                }                              
                if (HTMLHelper::extractNumber($_GET['minRating'])) {
                    $query->filter('my->averageRating', '>=', HTMLHelper::extractNumber($_GET['minRating']));
                }                
                if (HTMLHelper::extractNumber($_GET['maxRating'])) {
                    $query->filter('my->averageRating', '<=', HTMLHelper::extractNumber($_GET['maxRating']));
                }                                                                 
                if (HTMLHelper::extractNumber($_GET['minAge'])) {
                    $query->filter('my->age', '>=', HTMLHelper::extractNumber($_GET['minAge']));
                }                
                if (HTMLHelper::extractNumber($_GET['maxAge'])) {
                    $query->filter('my->age', '<=', HTMLHelper::extractNumber($_GET['maxAge']));
                }                               
                if ($_GET['categoryID']) {
                    $category = XN_Content::load($_GET['categoryID']); 
                }
                if ($_GET['subcategoryID']) {
                    $subcategory = XN_Content::load($_GET['subcategoryID']); 
                }                                 
                self::displayList($category, $subcategory, $query, $category->my->postingsHaveDate == 'Y', 'desc', null);
                break;   
                
            case 'replyByEmail':
                // categoryID and subcategoryID are used by the Post link in the header [Jon Aquino 2005-11-02]
                AssertionHelper::assert($_GET['categoryID']);  
                $posting = XN_Content::load($_GET['id']);
                if ($posting->my->content('category') == null) { throw new Exception('Category has been deleted'); }
                if (SecurityHelper::reportFailure(SecurityHelper::checkPostingAllowsMessaging($posting))) { return; }
                include 'views/posting/replyByEmail.php';   
                break;                         
        }

    }          
    
    private static function displayList($category, $subcategory, $query, $postingsHaveDate, $dateSortDirection, $previousWeekURL) {
        if ($category) { $query->filter('my->category', '=', $category->id); }
        if ($subcategory) { $query->filter('my->subcategory', '=', $subcategory->id); }
        // Category was deleted [Jon Aquino 2005-11-05]
        $query->filter('my->category', '<>', null);
        $postURL = $category ? 'index.php?controller=posting&amp;action=new&amp;categoryID=' . $category->id . '&amp;subcategoryID=' . $subcategory->id : 'index.php?controller=posting&amp;action=selectCategory';
        $postText = $category ? ('Post to ' . $category->my->h('xtitle')) : 'Post a listing';        
        $postings = $query
                ->filter('type', 'eic', 'Posting')                    
                ->filter('owner', '=')
                ->order($postingsHaveDate ? 'my->date' : 'createdDate', $dateSortDirection)
                ->begin(PaginationHelper::paginationStart())
                ->end(PaginationHelper::paginationStart() + Config::$postingsPerPage) 
                ->alwaysReturnTotalCount(true)                    
                ->execute();                    
        include 'views/posting/list.php';          
    }

    private static function validate($posting, $category) {
        $errors = ValidationHelper::validate($posting);                     
        $uploadError = ValidationHelper::validateImageUpload('Posting:photo1');        
        if ($uploadError != null) { $errors[] = $uploadError; }
        $uploadError = ValidationHelper::validateImageUpload('Posting:photo2');        
        if ($uploadError != null) { $errors[] = $uploadError; }
        $uploadError = ValidationHelper::validateImageUpload('Posting:photo3');        
        if ($uploadError != null) { $errors[] = $uploadError; }        
        if ($category->my->postingsHaveDate == 'Y' ) {
            if (strlen($_POST['year']) == 0 || strlen($_POST['month']) == 0 || strlen($_POST['day']) == 0) { 
                $errors[] = 'Date is required'; 
            } elseif (! DateHelper::dateValid($_POST['year'], $_POST['month'], $_POST['day'])) { 
                $errors[] = 'Date must be a valid mm/dd/yyyy date'; 
            }   
        }        
        if (strlen($_POST['tags']) > 100) { $errors[] = "Tags shouldn't be more than 100 characters long"; }
        return $errors;
    }       
    
    private static function cleanPostVariables($category) {
        if (isset($_POST['year'])) { $_POST['date'] = date('c', strtotime($_POST['year'] . '-' . $_POST['month'] . '-' . $_POST['day'])); }
        $_POST['displayingUsername'] = HTMLHelper::cleanBoolean($_POST['displayingUsername']);        
        if ($category->my->postingsHaveMessaging == 'Y') {
            $_POST['allowingMessaging'] = HTMLHelper::cleanBoolean($_POST['allowingMessaging']);
        }        
        if ($category->my->postingsHavePrice == 'Y') {
            $_POST['price'] = self::removeInitialDollarSign($_POST['price']);
        }                
    }          
    
    public static function removeInitialDollarSign($x) {
        return is_null($x) ? null : preg_replace('/^\$/', '', trim($x));
    }
    
    public static function formattedTitle($posting) {
        $formattedTitle = '';                
        if ($posting->my->h('price')) { $formattedTitle .= '$' . $posting->my->h('price') . ' - '; }        
        $formattedTitle .= $posting->my->h('xtitle');        
        if ($posting->my->h('age')) { $formattedTitle .= ' - ' . $posting->my->h('age'); }        
        if ($posting->my->h('location')) { $formattedTitle .= ' - ' . $posting->my->h('location'); }
        return $formattedTitle;
    }
    
    private static function validateAndSave($posting, $category, $validationFailedAction) {
        self::cleanPostVariables($category);
        $posting->import($_POST);
        if ($errors = self::validate($posting, $category)) {
            self::process($validationFailedAction, $errors);
            exit();
        }
        $posting->isPrivate = $posting->my->displayingUsername == 'N';
        Posting::updateStatistics($posting);         
        HTMLHelper::processImage('photo1', $posting);
        HTMLHelper::processImage('photo2', $posting);
        HTMLHelper::processImage('photo3', $posting);
        $posting->save();           
        NingHelper::addTags($posting, $_POST['tags']);
    }
    
}   



?>
