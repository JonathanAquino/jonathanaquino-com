<?php

require_once 'config/config.php';
require_once 'XNC/HTML.php';
require_once 'helpers/NingHelper.php';
require_once 'helpers/HTMLHelper.php';

class TagController {    
    
    public static function process($action, $errors = null) {
        
        switch($action) {
            
            default:
                throw new Exception('Unknown action: ' . $action);
                
            case 'list':                 
                $popularTagsAndCounts = XN_Query::create('Tag_ValueCount')
                    ->filter('content->owner')
                    ->order('valuecount','desc')
                    ->end(Config::$tagsOnTopTagsPage)->execute();
                include 'views/tag/list.php';       
                break;  
        }     
    }    
}

?>
