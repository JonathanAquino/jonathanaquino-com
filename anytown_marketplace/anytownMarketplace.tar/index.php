<?php

// This code includes and calls the given controller with the given action. 
// For example, if the controller is "category" and the action is "list",
// the code below will include "controllers/CategoryController.php"
// then execute MainController::process('list'). [Jon Aquino 2005-10-24]

trimGetAndPostValues();
if (! controllerValid()) {
    $_GET['controller'] = 'category';
    $_GET['action'] = 'list';
}
$controllerClassName = ucfirst($_GET['controller']) . 'Controller';
include 'controllers/' . $controllerClassName . '.php';
$controller = new $controllerClassName;
try {
    require_once 'helpers/NingHelper.php';
    NingHelper::cacheCategoriesAndSubcategories();
    $controller->process($_GET['action']);
} catch (Exception $exception) {
    $header = 'Whoops!';
    $message = 'I got confused about something. How about we head back to the <a href="/">front page</a>?';
    include 'views/shared/_error.php';
}

function controllerValid() {
    return in_array($_GET['controller'], array('category', 'posting', 'comment', 'tag'));
}

function trimGetAndPostValues() {
    foreach ($_GET as $key => $value) {
        $_GET[$key] = trim($value);
    }
    foreach ($_POST as $key => $value) {
        $_POST[$key] = trim($value);
    }    
}

?>
