<?php
require_once 'PHPUnit/GUI/HTML.php';
require_once 'PHPUnit.php';
$testNames = array(
    'WContentTest',
    'ValidationHelperTest',
    'HTMLHelperTest',
    'ColorSchemeHelperTest',
    'PHPHelperTest',
    'DateHelperTest',
    'CategoryHelperTest',
    'LocalContentStoreHelperTest',
    'LCSContentTest',
    'LCSContentStoreTest',
    'OodleHelperTest',
    'PostingTest',
    'ApplicationTest',
    'CategoryTest',
    'NingHelperTest',
    'PostingControllerTest'
);
$testSuites = array();
foreach($testNames as $testName) {
    require_once 'test/' . $testName . '.php';
    $testSuites[] = new PHPUnit_TestSuite($testName);
} 
$gui = new PHPUnit_GUI_HTML($testSuites);
$gui->show();
?>
