<?php

if (! XN_Profile::current()->isOwner()) { 
    echo '<b>Sorry, you must own this app to do that.</b>';
    exit();
}

XN_Application::includeFile('anytownmarketplace','/scripts/Tar.php');

if (! isset($_GET['step'])) { ?>
    <h2>Upgrade Anytown Listings to Anytown Marketplace: Step 1 of 2</h2>
    <br />
    This wizard will upgrade
    <a href="http://anytownlistings.ning.com">Anytown Listings</a> 
    to  
    <a href="http://anytownmarketplace.ning.com">Anytown Marketplace</a>.
    Anytown Marketplace is Anytown Listing's big brother, with additional
    features like discussion forums, ratings and reviews, drag-and-drop customization,
    color schemes, an event calendar, and more. <br />
    <br />
    Note that any customizations you made to Anytown Listings, and any existing
    data, will not appear in Anytown Marketplace. That said, you can always
    uninstall Anytown Marketplace, bringing your app back to its original state.<br /> 
    <br />
    <form>
        <input method="get" type="hidden" name="step" value="1a">
        <input value="Upgrade" type="submit" />
    </form>
    <?php
    exit();    
}

// Code from mail@scherzbold.net, "fread", http://ca.php.net/fread
// [Jon Aquino 2005-11-07]
function wwwcopy($file,$nfile)
{
   $fp = @fopen($file,"rb");
   while(!feof($fp))
   {
       $cont.= fread($fp,1024);
   }
   fclose($fp);

   $fp2 = @fopen($nfile,"w");
   fwrite($fp2,$cont);
   fclose($fp2);
} 

/**
 * rm() -- Vigorously erase files and directories. 
 *
 * @param $fileglob mixed If string, must be a file name (foo.txt), glob pattern (*.txt), or directory name.
 *                        If array, must be an array of file names, glob patterns, or directories. 
 */
function rm($fileglob)
{
   // Code from bishop, "unlink", http://ca.php.net/unlink 
   // [Jon Aquino 2005-11-07]
   if (is_string($fileglob)) {
       if (is_file($fileglob)) {
           return unlink($fileglob);
       } else if (is_dir($fileglob)) {
           $ok = rm("$fileglob/*");
           if (! $ok) {
               return false;
           }
           return rmdir($fileglob);
       } else {
           $matching = glob($fileglob);
           if ($matching === false) {
               trigger_error(sprintf('No files match supplied glob %s', $fileglob), E_USER_WARNING);
               return false;
           }     
           $rcs = array_map('rm', $matching);
           if (in_array(false, $rcs)) {
               return false;
           }
       }     
   } else if (is_array($fileglob)) {
       $rcs = array_map('rm', $fileglob);
       if (in_array(false, $rcs)) {
           return false;
       }
   } else {
       trigger_error('Param #1 must be filename or glob pattern, or array of filenames or glob patterns', E_USER_ERROR);
       return false;
   }

   return true;
} 

function touch_recursively($fileglob)
{
    if (is_file($fileglob)) {
        touch($fileglob);
    } else if (is_dir($fileglob)) {
        touch_recursively("$fileglob/*");
    } else {
        $matching = glob($fileglob);
        if ($matching === false) {
            return;
        }     
        $rcs = array_map('touch_recursively', $matching);
        if (in_array(false, $rcs)) {
            return;
        }
    }     
} 

function touch_app_files() {
    foreach (dirList('/' . XN_Application::load()->relativeUrl) as $file) {
        if (! is_app_file($file)) { continue; }
        touch_recursively($file);
    }        
}

// Code from Jon Haworth, "PHP: List files in a directory"
// http://www.laughing-buddha.net/jon/php/dirlist/
// [Jon Aquino 2005-11-07]
function dirList ($directory) 
{

    // create an array to hold directory list
    $results = array();

    // create a handler for the directory
    $handler = opendir($directory);

    // keep going until all files in directory have been read
    while ($file = readdir($handler)) {

        // if $file isn't this directory or its parent, 
        // add it to the results array
        if ($file != '.' && $file != '..')
            $results[] = $file;
    }

    // tidy up: close the handler
    closedir($handler);

    // done!
    return $results;

}

function is_app_file($file) {
    if ($file == 'xn_private') { return false; }
    if ($file == 'upgrade.php') { return false; }
    if (preg_match('/\.tar$/i', $file)) { return false; }
    return true;
}

function delete_app_files() {
    foreach (dirList('/' . XN_Application::load()->relativeUrl) as $file) {
        if (! is_app_file($file)) { continue; }
        rm($file);
    }     
}

if ($_GET['step'] == '1a') {
    wwwcopy('http://jonathanaquino.com/anytown_marketplace/anytownMarketplace.tar', 'anytownMarketplace.tar');
    if (! file_exists('anytownMarketplace.tar')) { throw new Exception('Could not find anytownMarketplace.tar'); }       
    $files = array();
    foreach (dirList('/' . XN_Application::load()->relativeUrl) as $file) {
        if (! is_app_file($file)) { continue; }        
        $files[] = $file;
    }
    $tar = new Archive_Tar(XN_Application::load()->relativeUrl . '-' . date('Y-m-d-H-i-s') . '.tar');
    if (! $tar->create($files)) { throw new Exception('Could not back up original files -- $tar->create($files) failed'); }
    $tar = new Archive_Tar('anytownListings.tar');
    if (! $tar->create($files)) { throw new Exception('Could not back up original files -- $tar->create($files) failed'); }
    delete_app_files();   
    $tar = new Archive_Tar('anytownMarketplace.tar');
    if (! $tar->extract()) { throw new Exception('A problem occurred extracting anytownMarketplace.tar'); };
    // Touch files so changes appear -- the header file, in particular [Jon Aquino 2005-11-07]
    touch_app_files();    
    // Redirect so if the user refreshes their browser, the above processing will not
    // be run. [Jon Aquino 2005-11-07]
    $redirectionLink = 'http://' . XN_Application::load()->relativeUrl . '.ning.com/upgrade.php?step=2';
    echo 'Redirecting to <a href="' . htmlentities($redirectionLink) . '">' . htmlentities($redirectionLink) . '</a>';
    header("Location: " . $redirectionLink);
    exit();
}

if ($_GET['step'] == 2) { 
    
    ?>
    <h2>Upgrade Anytown Listings to Anytown Marketplace: Step 2 of 2</h2>
    Congratulations! Anytown Marketplace was successfully installed. You may need to refresh
    your browser to see the changes.<br />
    <br />
    If you want to bring your app back to its original state, you can 
    <a href="?step=uninstall">uninstall Anytown Marketplace</a>.
<?php    
}

if ($_GET['step'] == 'uninstall') {  
    $files = array();
    foreach (dirList('/' . XN_Application::load()->relativeUrl) as $file) {
        if (! is_app_file($file)) { continue; }        
        $files[] = $file;
    }    
    $tar = new Archive_Tar(XN_Application::load()->relativeUrl . '-' . date('Y-m-d-H-i-s') . '.tar');
    if (! $tar->create($files)) { throw new Exception('Could not back up original files -- $tar->create($files) failed'); }
    delete_app_files();    
    $tar = new Archive_Tar('anytownListings.tar');
    if (! $tar->extract()) { throw new Exception('A problem occurred extracting anytownListings.tar'); };
    // Touch files so changes appear -- the header file, in particular [Jon Aquino 2005-11-07]
    touch_app_files();
    $anytownMarketplaceCategories = XN_Query::create('Content')
        ->filter('owner')
	    ->filter('type', '=', 'Category')
        ->filter('my->xtitle', '<>', null)
        ->execute();
    foreach ($anytownMarketplaceCategories as $category) {
        XN_Content::delete($category);
    }
    // There may be more than one Application because of spurious anonymous
    // objects -- see issue NING-935 [Jon Aquino 2005-11-08]
    $applications = XN_Query::create('Content')
        ->filter('owner')
	    ->filter('type', '=', 'Application')
        ->execute();
    foreach ($applications as $application) {        
        XN_Content::delete($application);
    }
    // Redirect so if the user refreshes their browser, the above processing will not
    // be run. [Jon Aquino 2005-11-07]
    $redirectionLink = 'http://' . XN_Application::load()->relativeUrl . '.ning.com/upgrade.php?step=uninstallComplete';
    echo 'Redirecting to <a href="' . htmlentities($redirectionLink) . '">' . htmlentities($redirectionLink) . '</a>';
    header("Location: " . $redirectionLink);
    exit();     
}

if ($_GET['step'] == 'uninstallComplete') { ?>
    <h2>Upgrade Anytown Listings to Anytown Marketplace: Uninstall</h2>
    Anytown Marketplace was successfully uninstalled. You may need to refresh
    your browser to see the changes.
<?php    
} ?>
