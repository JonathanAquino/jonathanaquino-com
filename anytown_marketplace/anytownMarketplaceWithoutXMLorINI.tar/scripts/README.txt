This directory contains useful administrative scripts. They are not used by
the app in any way. [Jon Aquino 2005-11-07]
