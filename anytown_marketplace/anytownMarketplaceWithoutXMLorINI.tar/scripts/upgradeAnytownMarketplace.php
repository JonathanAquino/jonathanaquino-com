<?php
// This wizard will upgrade your Anytown Marketplace clone to the latest 
// version. [Jon Aquino 2005-11-09]
XN_Application::includeFile('anytownmarketplace','/scripts/upgradeAnytownMarketplaceProper.php');
?>
