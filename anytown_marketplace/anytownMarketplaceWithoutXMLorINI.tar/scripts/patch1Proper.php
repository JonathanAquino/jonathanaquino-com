<?php

if (! XN_Profile::current()->isOwner()) { 
    echo '<b>Sorry, you must own this app to do that.</b>';
    exit();
}

if (! isset($_GET['step'])) { ?>
    <h2>Anytown Marketplace Patch 1: Step 1 of 2</h2>
    <br />
    This will fix the "Whoops! I got confused about something." error
    that occurs for some apps.<br />     
    <br />
    <form>
        <input method="get" type="hidden" name="step" value="1a">
        <input value="Fix" type="submit" />
    </form>
    <?php
    exit();    
}

if ($_GET['step'] == '1a') {
    $contents = @file_get_contents('models/Application.php');
    if (preg_match('/contributor/', $contents)) {
        // Fix already applied [Jon Aquino 2005-11-08]
    } else {        
        $contents = preg_replace('/->filter..owner., .=../', "->filter('owner', '=')->filter('contributor', '<>', null)", $contents);
        @file_put_contents('models/Application.php', $contents);
    }
    // Redirect so if the user refreshes their browser, the above processing will not
    // be run. [Jon Aquino 2005-11-07]
    $redirectionLink = 'http://' . XN_Application::load()->relativeUrl . '.ning.com/patch1.php?step=2';
    echo 'Redirecting to <a href="' . htmlentities($redirectionLink) . '">' . htmlentities($redirectionLink) . '</a>';
    header("Location: " . $redirectionLink);
    exit();
}

if ($_GET['step'] == 2) { ?>
    <h2>Anytown Marketplace Patch 1: Step 2 of 2</h2>
    <br />
    Congratulations! The fix was successfully applied.<br />
<?php    
} ?>
