<?php header("Content-Type: text/xml"); ?>
<?xml version="1.0" encoding="utf-8"?>

<?php
require_once '../helpers/AssertionHelper.php';
require_once '../helpers/NingHelper.php';
AssertionHelper::assert($_GET['xn_auth'] == 'no', 'Add ?xn_auth=no to URL');
$query = XN_Query::create('Content');
$query->filter('type', '=', 'Application');
$query->filter('my->originalApp', '=', 'AnytownMarketplace');
$applications = NingHelper::executeQueryWithoutLimit($query);
?>

<x></x>
