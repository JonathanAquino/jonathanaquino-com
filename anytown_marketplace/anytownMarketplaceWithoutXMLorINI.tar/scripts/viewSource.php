<style type="text/css">
#userContent code {
    font-size: 12pt;
}
</style>

<?php

if (strpos(realpath($_GET['file']), XN_Application::load()->relativeUrl . '/') == 1) {
    highlight_file($_GET['file']);
} 
