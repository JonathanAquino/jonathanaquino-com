<?php

// This wizard will upgrade Anytown Listings to Anytown Marketplace. 
// Anytown Marketplace is Anytown Listing's big brother, with additional features 
// like discussion forums, ratings and reviews, drag-and-drop customization, 
// color schemes, an event calendar, and more. [Jon Aquino 2005-11-07]

XN_Application::includeFile('anytownmarketplace','/scripts/upgradeProper.php');

?>
