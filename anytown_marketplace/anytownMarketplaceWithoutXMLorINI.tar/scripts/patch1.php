<?php
// This wizard will fix the "Whoops! I got confused about something." 
// error that occurs for some apps. [Jon Aquino 2005-11-08]
XN_Application::includeFile('anytownmarketplace', '/scripts/patch1Proper.php');
?>
