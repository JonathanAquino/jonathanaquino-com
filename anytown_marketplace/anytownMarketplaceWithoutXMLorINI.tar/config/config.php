<?php
require_once 'config/ApplicationConfig.php';

/**
 * The Config class holds application configuration information -- what kinds of
 * content the app is dealing with and other app-wide data like arrays for 
 * form choices, result page size, and so on. All of the configuration variables
 * should be declared as public static variables.
 */
class Config extends ApplicationConfig {   
    public static $reviewsOnFrontPage = 6;
    public static $postingsPerPage = 100;
    public static $tagsOnTopTagsPage = 50;
    public static $city = '';
    public static $stateAbbreviation = '';
    public static $countryAbbreviation = 'US';
    public static $googleMapsAPIKey;
    public static $frontPageMapInitialExtentURL = 'http://maps.google.com/maps?q=palo+alto&ll=37.439701,-122.145309&spn=0.124304,0.328766&hl=en';
    /**
     * 0 = Street map, 1 = Satellite Map, 2 = Hybrid Map
     */ 
    public static $mapType = 0;    
}

Config::load();

?>
