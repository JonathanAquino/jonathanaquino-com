<?php
  /*
   * ApplicationConfig.php
   * version 20050920-002
   * -- Better error message if XN_Application::load()
   * version 20050920-001
   * -- Don't redirect to setup.php if XN_Application::load() fails
   * version 20050902-001
   * -- update redirection logic in setup()
   * version 20050831-001
   * -- updateVars() now scans all variables in Config even if they're
   * -- not already in config.ini
   */
// You must call your config class "Config"
class ApplicationConfig {
    // The config vars loaded from the config file
    public static $_vars;
    
    // What static variables not to overwrite with values from the config file
    protected static $_varsToSkip = array('_vars','_varsToSkip','_configured');

    public static function load($filename = 'config.ini') {
  Config::$_vars = @parse_ini_file($filename,true);
  if (count(Config::$_vars) > 0) {
      foreach (Config::$_vars['config'] as $var => $value) {
    if (! in_array($var, Config::$_varsToSkip)) {
        Config::${$var} = $value;
    }
      }
  } else {
            Config::$_vars['config'] = array();
        }
        try {
            $app = XN_Application::load();
            if (! ($app && strlen($app->relativeUrl))) {
                throw new Exception("No application loaded.");
            }
        } catch (Exception $e) {
            print "We're sorry -- the system is having a problem right now.";
            exit();
        }

  if ((basename($_SERVER['SCRIPT_FILENAME']) != 'setup.php') &&
      (! (array_key_exists('config', Config::$_vars) &&
    is_array(Config::$_vars['config']) &&
    array_key_exists('_configured',Config::$_vars['config']) &&
    (Config::$_vars['config']['_configured'] == $app->relativeUrl)
                ))) {
      Config::setup();
  }
    }

    public static function setup() {
        ob_end_clean();
        $proto = 'http';
        // @todo sense HTTPS
        header("Location: $proto://{$_SERVER['HTTP_HOST']}/setup.php");
        exit();
    }

    public static function updateVars($section, $vars) {
  if (is_array(Config::$_vars[$section])) {
      if ($section == 'config') {
    Config::$_vars['config']['_configured'] = 
        XN_Application::load()->relativeUrl;
                $varsToCheck = get_class_vars('Config');
      } else {
                $varsToCheck = Config::$_vars[$section];
            }
      foreach ($varsToCheck as $var => $value) {
    if (array_key_exists($var, $vars)) {
        Config::$_vars[$section][$var] = $vars[$var];
    }
      }
  }
    }   

    public static function save($data, $filename = 'config.ini') {
  Config::updateVars('config',$data);

  $ini ='';
  foreach (Config::$_vars as $sectionName => $section) {
      $ini .= "[$sectionName]\n";
      foreach ($section as $var => $value) {
    if (! ctype_alnum($value)) {
        $value = str_replace('\\','\\\\',$value);
        $value = str_replace('"','\\"',$value);
        $value = '"'.$value.'"';
    }
    $ini .= "$var=$value\n";
      }
      $ini .= "\n";
  }
  $res = @file_put_contents($filename,$ini);
  if (($res === false) || ($res != strlen($ini))) {
      throw new Exception("Couldn't save $filename");
  }
    }

}
