<?php

/**
 * @author Christopher Schmidt
 * @author Anselm Hook
 * @author Jon Aquino
 */
class MapBrowser {
            
    public static function displayMapBrowser($lat, $lon, $zoomLevel, $form) { ?>
        <div id="status"></div>
        <div style="width:530px; height:200px;" id="selectmap"></div>        
        <?php
        echo '<script src="http://maps.google.com/maps?file=api&v=1&key='.Config::$googleMapsAPIKey.'" type="text/javascript"></script>';
        self::geocodeViaMap($lat, $lon, $zoomLevel, $form);
    }
    
    public static function geocodeViaMap($lat, $lon, $zoomLevel, $form) { 
	$mapType = Config::$mapType;
echo <<<HTML
<script defer>
  var map;
  var handler = false;
  var finalizer = false;
  function content_finalize() {
    if( handler.readyState==4) {
      if( window && window.ActiveXObject ) { finalizer( handler ); }
      else finalizer( handler.responseXML );
    }
  }
  function content_load(file,_finalizer) {
    // Animated GIF from Animation Library, "Set 1 d", http://www.animationlibrary.com/a-l/?n=image.php3&image_id=1300
    // [Jon Aquino 2005-11-20]
    var updatingHTML = 'Updating map... <img src="lib/MapBrowser/set_1_d.gif"/>';      
    handler = false;
    finalizer = _finalizer;
    if (window && window.ActiveXObject) {
      s = document.getElementById("status");
      s.innerHTML = updatingHTML;      
      try {
        handler = new ActiveXObject("Microsoft.XMLDOM");
        handler.async=true;
        handler.onreadystatechange=content_finalize;
      } catch (e) {
        try {
          handler = new ActiveXObject("Microsoft.XMLHTTP");
          handler.async=true;
          handler.onreadystatechange=content_finalize;
        } catch (E) {
          handler = false;
        }
      }
     } else {
      if(window.XMLHttpRequest || XMLHttpRequest != 'undefined') {  
        s = document.getElementById("status");
        s.innerHTML = updatingHTML;        
        handler = new XMLHttpRequest();
        handler.onload=content_finalize;
        handler.onreadystatechange=content_finalize;
        handler.open('GET',file, true);        
        handler.send("");
        return;
      }
    }
    if(!handler) {
      alert('Sorry, your browser can\'t handle this script');
      return;
    }
    handler.load(file);
  }
  function contentget(content,field) {
    if(!content) return "";
    for(var subnode = content.firstChild; subnode != null; subnode = subnode.nextSibling ) {
      if( field == subnode.nodeName ) {
        if( subnode.nodeType == 1 ) {
          if( subnode.firstChild ) {
            return subnode.firstChild.data;
          }
        }
        break;
      }
    }
    return "";
  }

  function node_skip_preamble(content) {
    if(!content) {
      return null;
    }
    for(var node = content; node != null; node = node.nextSibling ) {
      if( node.nodeName == 'items' ) return node;
    }
    for(var node = content.firstChild; node != null; node = node.nextSibling ) {
      if( node.nodeName == 'items' ) return node;
    }
    return null;
  }

  function node_get_first_item(content) {
    if(!content) return null;
    content = node_skip_preamble(content);
    if(!content) return null;
    content = content.firstChild;
    while( content != null && content.nodeName != 'item' ) { content = content.nextSibling; }
    return content;
  }


function finalizeaddress(content) {
  node = node_get_first_item(content);
  if(node) {
     var longitude = contentget(node,"longitude");
     var latitude = contentget(node,"latitude");
     var address = contentget(node,"address");
     var error = contentget(node,"error");
     if(map && longitude != 0 && latitude != 0) {
        s = document.getElementById("status");
        s.innerHTML = 'Map Updated.';
        zoom = map.getZoomLevel();
        if (zoom > 4) {
            zoom = 4;
        }
        map.centerAndZoom(new GPoint(longitude,latitude),zoom);
        
        map_refresh_form();
     }
     if (error) {
        s = document.getElementById("status");
        s.innerHTML = "Sorry, I could not update the map because of an error: "+error;
     }
  }
}

function getaddress() {    
   var node = document.getElementById("address");
   if(!node) return;
   if( node.value && node.value.length > 0 ) addr = node.value; else {
       alert('Please specify an address');
       return; 
   }
   var node = document.getElementById("city");
   if( node.value && node.value.length > 0 ) addr += ", " + node.value; else {
       alert('Please specify a city');
       return; 
   }
   var node = document.getElementById("state");
   if( node.value && node.value.length > 0 ) addr += ", " + node.value; else {
       alert('Please specify a state');
       return; 
   }   
   addr = escape(addr);
   addr = "lib/MapBrowser/geocode.php?address="+addr;   
   content_load(addr,finalizeaddress);
}


    function map_refresh_form() {
        var c = map.getCenterLatLng();
        lon = document.getElementById('gmlong');
        if(lon) {
            lon.value=""+c.x;
        }
        lat = document.getElementById('gmlat');
        if(lat) {
            lat.value=""+c.y;
        }
        zoomLevel = map.getZoomLevel();
        zoom = document.getElementById('gmzoom');
        if(zoom) {
            zoom.value=""+zoomLevel;
        }
        
    }
HTML;

if (is_null($lon)) {
    $lon = -122.141944;
    $lat = 37.441944;
    $span = 360;
    if( Config::$frontPageMapInitialExtentURL ) {
     $str = Config::$frontPageMapInitialExtentURL;
     $str = explode('?',$str);
     if(strlen($str) > 0 ) {
       $str = explode('&',$str[1]);
       foreach($str as $s) {
         if($s[0] == 'l' && $s[1] == 'l' && $s[2] == '=') {
             $ll = explode(',',substr($s,3));
             $lat = floatval($ll[0]);
             $lon = floatval($ll[1]); 
         } else if($s[0]=='s' && $s[1]=='p' && $s[2]=='n' && $s[3]=='=') {
             $span = floatval(substr($s,4));
         }
       }
      }
    }
}
$zoomLevelJavascript = is_null($zoomLevel) ? 'calculateZoomLevel('.$span.','.$span.'/2)' : $zoomLevel;
echo <<<HTML
    var mapzoom = 8;
    var latmin = 0;
    var latmax = 0;
    var lonmin = 0;
    var lonmax = 0;
    var zoomarea = 0;
    var latmid = 0;
    var lonmid = 0;
    var maplatch = 0;

    var _zoomLevels = new Array 
    ( 
    0.006909370422363281, 
    0.013818740844726562, 
    0.027637481689453125, 
    0.05527496337890625, 
    0.1105499267578125, 
    0.221099853515625, 
    0.44219970703125, 
    0.8843994140625, 
    1.768798828125, 
    3.53759765625, 
    7.0751953125, 
    14.150390625, 
    28.30078125, 
    56.6015625, 
    113.203125, 
    226.40625, 
    452.8125,
    905.625 ); 

    function calculateZoomLevel(spanLng, spanLat) { 
        var level = _zoomLevels.length-1;
        var found = false; 
        var index = 0; 
        // Get largest value 
        var compareTo = spanLng; 
        if (spanLat>spanLng) compareTo = spanLat; 
        while (!found && index<_zoomLevels.length) { 
            if (_zoomLevels[index]>compareTo)  { 
                level = index; 
                found = true;
            } 
            index++;
        } 
        return level 
    }

    var centermarker = null;
    function map_recenter() {
        var center = map.getCenterLatLng();
        if( centermarker ) {
            map.removeOverlay(centermarker);
            centermarker = new GMarker(new GPoint(center.x,center.y));
            map.addOverlay(centermarker);
        }
        map_refresh_form();
    }

    function map_init(mapdivname) {
        map = new GMap(document.getElementById(mapdivname));
        map.addControl(new GSmallZoomControl());
        map.addControl(new GMapTypeControl());
        var lon = {$lon};
        var lat = {$lat};
        var zoomLevel = {$zoomLevelJavascript};
        map.centerAndZoom(new GPoint(lon,lat),zoomLevel);

        centermarker = new GMarker(new GPoint(lon,lat));
        map.addOverlay(centermarker);
        GEvent.addListener(map, "moveend", map_recenter );
        map.setMapType(map.getMapTypes()[{$mapType}]);
        map_refresh_form();
    }
</script>
HTML;

        // Call map_init() in onload; otherwise get the following error:
        // "Internet Explorer cannot open the Internet site. Operation aborted"
        // This is a known issue with IE and Google Maps.
        // See Andrew Sterling Hanenkamp, "Microsoft Internet Explorer Sucks",
        // http://andrew.sterling.hanenkamp.com/node/119   [Jon Aquino 2005-11-20]
        ?>        
        <xn:body onload="map_init('selectmap')"/>
        <?php
        echo $form->hidden("latitude", 'id="gmlat"');
        echo $form->hidden("longitude", 'id="gmlong"');
        echo $form->hidden("zoomLevel", 'id="gmzoom"');

    }
    
}    
