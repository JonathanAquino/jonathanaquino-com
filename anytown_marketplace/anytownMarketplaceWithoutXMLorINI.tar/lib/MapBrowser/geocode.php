<?php

    # Helper for Javascript geocoding.
    require_once '../../helpers/GeocodingHelper.php';
    $error = null;
    try {
      $geocoderResult = GeocodingHelper::geocode( $_GET['address'] );
      $lat = $lon = 0;
      if(is_array($geocoderResult)) {
        $lat = $geocoderResult['lat'];
        $lon = $geocoderResult['long'];
      }
    } catch(Exception $e) {
      $error = $e->getMessage();
    }
    header("Content-Type: text/xml");
    echo '<?xml version="1.0" encoding="utf-8" ?>'.chr(13);
    echo '<items>'.chr(13);
    echo '  <item>'.chr(13);
    echo '    <longitude>'.$lon.'</longitude>'.chr(13);
    echo '    <latitude>'.$lat.'</latitude>'.chr(13);
    echo '    <address>'.$address.'</address>'.chr(13);
    echo '    <error>'.$error.'</error>'.chr(13);
    echo '  </item>'.chr(13);
    echo '</items>'.chr(13);

