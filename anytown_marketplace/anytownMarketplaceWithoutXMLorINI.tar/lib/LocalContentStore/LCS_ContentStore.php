<?php

require_once 'helpers/AssertionHelper.php';

/*
 * This "LocalContentStore" is a library that helps to reduce the number of 
 * content objects in apps that must write or read a lot of them (writing is particularly expensive). 
 * It looks and acts like the content store and XN_Content objects, but everything
 * is in memory (no database access). The local content store can then be easily
 * serialized for storage in a file or a single content object.
 * @author Jon Aquino
 */

class LCS_ContentStore {        
    
    public $nextID = 1;
    public $idToContentArray = array();
    public $foreignIDToIDArray = array();    
    
    public function create($type) {
        return new LCS_Content($type, $this);        
    }
    
    public function save($content) {        
        if ($content->id == null) {  
            // The "L" prefix indicates that it is a local ID, not a true
            // content-store ID. [Jon Aquino 2005-11-17]
            $content->id = 'L' . $this->nextID++;            
        }
        $this->idToContentArray[$content->id] = $content;
        if (! is_null($content->foreignID)) {
            $this->foreignIDToIDArray[$content->foreignID] = $content->id;
        }
        if ($this->persistenceEnabled) { $this->persist(); }
    }
    
    public function idForForeignID($foreignID) {
        AssertionHelper::assert(gettype($foreignID) == 'string');
        return $this->foreignIDToIDArray[$foreignID];
    }
    
    public $persistenceEnabled = true;
    
    /**
     * Override this method to implement persistence 
     * e.g. call LCS_Serializer::serialize(), then
     * persist to disk or to a single content object.
     */
    public function persist() {}
    
    public function load($id) {
        return $this->idToContentArray[$id];
    }    
    
    public function delete($idOrContent) {
        unset($this->idToContentArray[gettype($idOrContent) == 'string' ? $idOrContent : $idOrContent->id]);
        if ($this->persistenceEnabled) { $this->persist(); }
    }
    
}

?>
