<?php

require_once 'XML/Serializer.php';
require_once 'XML/Unserializer.php'; 
require_once 'LCS_AttributeContainer.php';
require_once 'LCS_ContentStore.php';
require_once 'LCS_Content.php';  

class LCS_Serializer {

    // Use XML Serializer instead of the PHP serializer, which is much harder
    // to debug (albeit more compact) [Jon Aquino 2005-11-18]
    
    public static function serialize($localContentStore) {        
        $serializer = new XML_Serializer(array('typeHints' => TRUE));
        $status = $serializer->serialize(self::removeBackReferences($localContentStore));
        self::addBackReferences($localContentStore);
        if (PEAR::isError($status)) { throw new Exception($status->getMessage()); }        
        return $serializer->getSerializedData();    
    }
    
    public static function unserialize($xml) {        
        $unserializer = new XML_Unserializer();
        $status = $unserializer->unserialize($xml);
        if (PEAR::isError($status)) { throw new Exception($status->getMessage()); }        
        return self::addBackReferences($unserializer->getUnserializedData());    
    }    
    
    private static function removeBackReferences($localContentStore) {
        // Drop circular references, which cause an infinite loop in XML_Serializer
        // [Jon Aquino 2005-11-18]
        foreach (array_values($localContentStore->idToContentArray) as $content) {
            $content->localContentStore = null;            
        }
        return $localContentStore;
    }
    
    private static function addBackReferences($localContentStore) {        
        foreach (array_values($localContentStore->idToContentArray) as $content) {
            $content->localContentStore = $localContentStore;
        }
        return $localContentStore;
    }    
    
}    
