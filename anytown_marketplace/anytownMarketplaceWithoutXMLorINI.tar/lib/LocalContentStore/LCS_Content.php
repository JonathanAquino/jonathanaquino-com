<?php

require_once 'LCS_AttributeContainer.php';

class LCS_Content {    
    
    public $type;
    public $id;
    /**
     * Lazily initialized ID of the corresponding content object in the real
     * (non-local) content store.
     */
    public $foreignID;
    public $my;
    public $localContentStore;
    
    public function __construct($type = null, $localContentStore = null) {
        // Arguments are null for XML_Serializer [Jon Aquino 2005-11-18]
        $this->type = $type;
        $this->my = new LCS_AttributeContainer();
        $this->localContentStore = $localContentStore;
    }        
    
    public function focus() {
        // Does nothing; included for compatibility with XN_Content. [Jon Aquino 2005-11-14]
    }
    
    public function save() {
        $this->localContentStore->save($this);
    }
    
}

?>
