<?php

require_once 'helpers/AssertionHelper.php';

class LCS_AttributeContainer {      
    
    public $nameToValueArray = array();
    public $nameToTypeArray = array();
    
    public function set($name, $value = null, $type = XN_Attribute::STRING) {
        if (is_null($value)) {             
            unset($this->nameToValueArray[$name]);
            unset($this->nameToTypeArray[$name]);
        } else {            
            $this->nameToValueArray[$name] = $value;
            $this->nameToTypeArray[$name] = $type;
        }        
    }
    
    public function __get($name) {     
        // Slightly different behavior from the regular content store:
        // int's stay as int's. In the regular content store, int's seem to be 
        // (inadvertently?) converted to strings by XN_Query (see NING-984).
        // Anyway, this difference should not be of any consequence to most apps.
        // [Jon Aquino 2005-11-17]
        return $this->raw($name);
    }    
    
    public function __set($name, $value) {                 
        $this->set($name, $value);
    }    
    
    public function raw($name) {
        return $this->nameToValueArray[$name];
    }
    
    public function h($name) {
        return htmlentities($this->{$name}, ENT_QUOTES, 'UTF-8');
    }
    
    public function attribute($name) {
        return new XN_Attribute($name, $this->nameToValueArray[$name], $this->nameToTypeArray[$name]);
    }    
    
}

?>
