<?php

require_once 'helpers/AssertionHelper.php';
require_once 'helpers/PHPHelper.php';

class NingHelper {    

    public static function addTags($object, $tagString) {
        try {
            XN_Tag::addTags($object, $tagString);
        } catch (XN_Exception $e) {
            // Get here if one of the tags already exists. Not criticial, so eat it. [Jon Aquino 2005-10-14]
        }
    }        
    
    private static $application;
    
    public static function application() {
        if (self::$application == null) {
            self::$application = XN_Application::load();
        }
        return self::$application;
    }                
    
    public static function sortByTitle($contentArray) {                
        AssertionHelper::assert(usort($contentArray, 'compareByTitle'));
        return $contentArray;
    }        
    
    /**
     * Works around the 100-result limit. Do not use this for queries that return 
     * thousands of results!
     */
    public static function executeQueryWithoutLimit($query, $limit = 10000) {
        $query->alwaysReturnTotalCount(true);
        $resultArrays = array();             
        do {            
            $query->begin($start = count($resultArrays) == 0 ? 0 : $query->getResultTo());
            $query->end(min($start + 100, $limit));
            $resultArrays[] = $query->execute();
        } while ($query->getResultTo() < min($query->getTotalCount(), $limit));
        return PHPHelper::concatenate($resultArrays);
    }
    
    public static function appConfigured() {
        return self::appConfiguredProper('config.ini', XN_Application::load()->relativeUrl);
    }
    
    public static function appConfiguredProper($iniFilename, $relativeUrl) {
      $settings = @parse_ini_file($iniFilename, true);      
      return $settings['config']['_configured'] == $relativeUrl;
    }

}

function compareByTitle($a, $b) {
    $aValue = strtolower($a->my->xtitle);
    $bValue = strtolower($b->my->xtitle);
    if ($aValue == $bValue) {
        return 0;
    }
    return ($aValue < $bValue) ? -1 : 1;
}    


