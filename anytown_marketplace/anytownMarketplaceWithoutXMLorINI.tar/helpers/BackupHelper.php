<?php

class BackupHelper {

    public static function backup($string, $filenamePrefix) {
        // Use @ to disable the display of warnings to the user. You will almost
        // certainly get a warning the first time -- for some reason, a save will
        // not succeed on the first try. See NING-900. [Jon Aquino 2005-11-18]
        $filenameProper = $filenamePrefix . '.backup.' . mt_rand(0, 9);
        if (0 == @file_put_contents($filenameProper, $string) || ! file_exists($filenameProper)) {
            if (0 == @file_put_contents($filenameProper, $string) || ! file_exists($filenameProper)) {
                if (0 == @file_put_contents($filenameProper, $string) || ! file_exists($filenameProper)) {
                }
            }
        }            
    }

}
