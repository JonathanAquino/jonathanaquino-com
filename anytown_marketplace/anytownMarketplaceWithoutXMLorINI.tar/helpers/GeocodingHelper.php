<?php
require_once 'XML/RPC.php';

/**
 * This class converts a street address to latitude-longitude coordinates. Example: 
 * <pre>
 *      $geocoderResult = geocode('1600 Pennsylvania Ave, Washington, DC');
 *      echo $geocoderResult['lat'];
 *      echo $geocoderResult['long']; 
 * </pre> 
 *
 * @author Jonathan Aquino
 */

class GeocodingHelper {	 
    
    /**
     * Set the subject's latitude and longitude attributes based on its address,
     * city and state attributes. Caching the latitude and longitude in this way avoids unnecessary
     * lookups, which can be slow. 
     * @param XN_Content $content Content object to update
     * @return boolean whether the latitude and longitude was determined
     * @author Jonathan Aquino
     */
    public static function ensureLatitudeAndLongitudeSet($content) {          
        if ($content->my->latitudeAndLongitudeFound == null) {
            try {
                $geocoderResult = self::geocode($content->my->address.", ".$content->my->city.", ".$content->my->state);                
                $content->my->set('latitude', $geocoderResult['lat'], XN_Attribute::NUMBER);                  
                $content->my->set('longitude', $geocoderResult['long'], XN_Attribute::NUMBER);                  
                $content->my->latitudeAndLongitudeFound = 'Y';
            } catch (XMLRPCException $e) {   
                // Don't set latitudeAndLongitudeFound, so it gets tried again next time. [Jon Aquino 2005-09-08]             
                return false;
            } catch (Exception $e) {
                $content->my->latitudeAndLongitudeFound = 'N';
            }
            $content->save();
        }
        return $content->my->latitudeAndLongitudeFound == 'Y';
    }       
    
    /**
     * Given an address or intersection, return its latitude and longitude. Examples of addresses:
     * <ul>
     * <li>1600 Pennsylvania Ave, Washington, DC</li>
     * <li>3601 Lyon Street, 94123</li>
     * <li>Angela and Simonton, Key West, FL</li>
     * </ul>
     * @param string $addressOrIntersection An address or intersection, followed by city and state, or zip code.
     * @return array 
     * @throws XMLRPCException if an XML-RPC error occurs
     * @throws Exception if the address cannot be parsed, or if the address cannot be found.
     * @see http://geocoder.us/help/
     */
    public static function geocode($addressOrIntersection) {
        $parameters = array(new XML_RPC_Value($addressOrIntersection, 'string'));
        $message = new XML_RPC_Message('geocode', $parameters);
        $client = new XML_RPC_Client('/service/xmlrpc', 'rpc.geocoder.us');
        $response = $client->send($message);
        GeocodingHelper::checkResponse($response, $addressOrIntersection);
        $value = $response->value();
        $geocoderResult = XML_RPC_decode($value);
        GeocodingHelper::checkGeocoderResult($geocoderResult, $addressOrIntersection);
        return $geocoderResult[0];
    }
    private static function checkResponse($response, $addressOrIntersection) {
    	// Error handling based on the example given in http://pear.php.net/manual/en/package.webservices.xml-rpc.examples.php [Jon Aquino 2005-09-07]
        if (!$response) { throw new XMLRPCException($client->errstr . ": " . $addressOrIntersection); }
        if ($response->faultCode()) { throw new XMLRPCException($response->faultCode() . " - " . $response->faultString() . ": " . $addressOrIntersection); }
    }

    private static function checkGeocoderResult($geocoderResult, $addressOrIntersection) {
        // The various kinds of results are documented at http://geocoder.us/help/ [Jon Aquino 2005-09-06]
        if (count($geocoderResult ) == 0) { throw new Exception("Address cannot be parsed: " . $addressOrIntersection); }
        if (!isset($geocoderResult [0]['lat'])) { throw new Exception("Address not found: " . $addressOrIntersection); }
    }	    
    
}

class XMLRPCException extends Exception {}
