<?php

class AssertionHelper {    
    public static function assert($condition, $message = '') {
        if (! $condition) { throw new AssertionFailedException($message); }           
    }
}

class AssertionFailedException extends Exception {}


