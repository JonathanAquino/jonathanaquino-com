<?php
require_once 'GeocodingHelper.php';
require_once 'controllers/PostingController.php';

abstract class AbstractMapsHelper {
    
    protected abstract function createMap($width, $height, $controls, $zoomLevel);

    public abstract function initialExtentURL();    

    public static function instance() {        
        if (Config::$mapBrand == 'Google Maps') { 
            require_once 'GoogleMapsHelper.php';
            return GoogleMapsHelper::instance();
        }
        if (Config::$mapBrand == 'Yahoo! Maps') { 
            require_once 'YahooMapsHelper.php';
            return YahooMapsHelper::instance();
        }
        throw new Exception("Shouldn't get here");
    }
    
    /**
     * Outputs the HTML for a Google Map or Yahoo! Map, with a marker for the given subject.
     * @param XN_Content $subject Content object with latitude and longitude attributes
     * @param integer $width width of the map; for example, 300px
     * @param integer $height height of the map; for example, 300px
     * @param string $controls array of control names from the following list: MapType, LargeMap, SmallMap SmallZoom
     */    
    public function displayMap($subject, $width, $height, $controls = array('SmallZoom', 'MapType')) {
        if (! GeocodingHelper::ensureLatitudeAndLongitudeSet($subject)) { return; }
        $map = $this->createMap($width, $height, $controls, $subject->my->zoomLevel);
        $map->setMapLocation($subject->my->longitude, $subject->my->latitude);
        $this->addMarker($subject, $map);  
        $this->configureMapType($map);        
        $map->display();         
    }    
    
    /**
     * Outputs the HTML for a Google Map or Yahoo! Map, with markers for the given array of subjects.
     * @param array $subjects XN_Content objects with latitude and longitude attributes
     * @param integer $width width of the map; for example, 300px
     * @param integer $height height of the map; for example, 300px
     * @param string $extentURL A Google Maps or Yahoo! Maps URL representing the bounding box of the map on the front page.
     * @param string $controls array of control names from the following list: MapType, LargeMap, SmallMap SmallZoom
     */    
    public function displayMapForArray($subjects, $width, $height, $extentURL, $controls = array('SmallZoom', 'MapType')) {
        $map = $this->createMap($width, $height, $controls, null);
        $map->setFromUrl($extentURL);
        foreach ($subjects as $subject) {
            if (GeocodingHelper::ensureLatitudeAndLongitudeSet($subject)) {
                $this->addMarker($subject, $map);
            }
        }                
        $this->configureMapType($map);        
        $map->display();
    }                 

    private function addMarker($subject, $map) {
        $map->addMarker($subject->my->longitude, $subject->my->latitude, $this->bubble($subject));    
    }

    private function bubble($subject) {        
        return '<div style="width:200px">' . str_replace("\r", "", str_replace("\n", "", PostingController::summary($subject, null, null, true))) . '</div>';
    }    

}
