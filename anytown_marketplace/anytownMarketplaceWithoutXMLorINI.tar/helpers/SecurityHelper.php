<?php

require_once 'helpers/CategoryHelper.php';

class SecurityHelper {

    public static function checkCurrentUserHasNotRated($posting) {         
        if (SecurityHelper::failed(SecurityHelper::checkCurrentUserIsSignedIn())) { return SecurityHelper::checkCurrentUserIsSignedIn(); }        
        if (CategoryHelper::content($posting, 'category')->my->postingsHaveRatings == 'N') { return null; }        
        if ($posting->contributorName == XN_Profile::current()->screenName) { return 'Sorry, you have already rated this'; }
        foreach (Posting::comments($posting) as $comment) {
            if ($comment->contributorName == XN_Profile::current()->screenName) { return 'Sorry, you have already rated this'; }
        }
        return null; 
    }        
    
    public static function checkPostingAllowsMessaging($posting) {
        if (SecurityHelper::failed(SecurityHelper::checkCurrentUserIsSignedIn())) { return SecurityHelper::checkCurrentUserIsSignedIn(); }        
        if ($posting->my->allowingMessaging != 'Y') { return 'Sorry, the poster is not allowing messaging.'; }
        if (CategoryHelper::content($posting, 'category')->my->postingsHaveMessaging != 'Y') { return 'Sorry, the poster is not allowing messaging.'; }
        return null;    
    }
    
    public static function checkCurrentUserIsSignedIn() { 
        if (! XN_Profile::current()->isLoggedIn()) { return 'Sorry, you must be signed in to do that.'; }
        return null;
    }
    
    public static function checkCurrentUserContributed($content) { 
        return SecurityHelper::checkCurrentUserIs($content->contributorName); 
    }
    
    public static function checkCurrentUserIs($screenName) { 
        if (SecurityHelper::failed(SecurityHelper::checkCurrentUserIsSignedIn())) { return SecurityHelper::checkCurrentUserIsSignedIn(); }
        if (XN_Profile::current()->screenName != $screenName) { return 'Sorry, you must be ' . $screenName . ' to do that.'; }
        return null;
    }
    
    public static function checkCurrentUserIsAppOwner() { 
        if (SecurityHelper::failed(SecurityHelper::checkCurrentUserIsSignedIn())) { return SecurityHelper::checkCurrentUserIsSignedIn(); }            
        if (! XN_Profile::current()->isOwner()) { return 'Sorry, you must own this app to do that.'; }
        return null;
    }    
    
    public static function failed($failureMessage) { return $failureMessage != null; }
    
    public static function reportFailure($failureMessage) {
        if (SecurityHelper::failed($failureMessage)) {
            $header = $failureMessage;
            include 'views/shared/_error.php'; 
        }
        return SecurityHelper::failed($failureMessage);
    }
    
}


