<?php

// For interfacing with oodle.com [Jon Aquino 2005-11-09]

class OodleHelper {

    /**
     * @param $metroArea City, State/Province Abbreviation, Country; for example:
     * Knoxville, TN, US
     */     
     public static function xmlForApplication($applicationRelativeURL, $maxPostingsWithDate, $maxPostingsWithoutDate, $metroArea) {
        $postingsWithDateQuery = self::createQuery($applicationRelativeURL);        
        // Subtract 24 hours so it works with any timezone [Jon Aquino 2005-11-09]        
        $postingsWithDateQuery->filter('my->date', '>', date('c', time() - (24 * 60 * 60)));
        $postingsWithDateQuery->order('my->date', 'asc');
        $postingsWithDate = NingHelper::executeQueryWithoutLimit($postingsWithDateQuery, $maxPostingsWithDate);        
        
        $postingsWithoutDateQuery = self::createQuery($applicationRelativeURL);
        $postingsWithoutDateQuery->filter('my->date', '=', null);
        $postingsWithoutDateQuery->order('createdDate', 'desc');        
        $postingsWithoutDate = NingHelper::executeQueryWithoutLimit($postingsWithoutDateQuery, $maxPostingsWithoutDate);                
        return self::xmlForApplicationProper($postingsWithDate, $postingsWithoutDate, time(), $metroArea);
    }
    
    public static function metroArea($application) {
        return self::metroAreaProper($application, $application->owner->relativeUrl);
    }
    
    public static function metroAreaProper($application, $applicationRelativeURL) {   
        if ($hardcodedMetroArea = self::hardcodedMetroArea($applicationRelativeURL)) {
            return $hardcodedMetroArea;
        }
        return $application->my->city . ', ' . $application->my->stateAbbreviation . ', ' . $application->my->countryAbbreviation;
    }
    
    public static function hardcodedMetroArea($applicationRelativeURL) {
        switch ($applicationRelativeURL) {
            // Sites created prior to metro areas. [Jon Aquino 2005-11-10]
            case 'zhongguopost': return ', , CN';
            case 'koprivnica ': return 'Koprivnica, , HR';
            case 'roanoke': return 'Roanoke, VA, US';
            case 'ifindnewyork': return 'New York, NY, US';
            case 'auckland': return 'Auckland, N North Island, NZ';
            case 'kerala': return ', Kerala, IN';
            case 'greenvilleconnection': return 'Greenville, SC, US';
            case 'avisosbaires': return 'Buenos Aires, , AR';
            case 'annapolis': return 'Annapolis, MD, US';
            case 'chennaimarket': return 'Chennai, Tamil Nadu, IN';
            case 'metzannonce': return 'Metz, Moselle, FR';
            case 'metzannonces': return 'Metz, Moselle, FR';
            case 'nonupeleftbehind': return ', Nupe, NG';
            case 'Pajottenlandweb': return 'Payottenland, Flemish Brabant, BE';
            case 'newyork': return 'New York, NY, US';
            case 'kerrobert': return 'Kerrobert, SK, CA';
            case 'orangecounty': return 'Anaheim, CA, US';
            case 'losangeles': return 'Los Angeles, CA, US';
            case 'knoxville': return 'Knoxville, TN, US';
            case 'marketstreet': return 'Portsmouth, NH, US';
            case 'okcmarketplace': return 'Oklahoma City, OK, US';
            case 'openMarket': return ', , ZM';
            case 'miamifl': return 'Miami, FL, US';
            case 'southerncalifornia': return ', CA, US';
            case 'portlandmarket': return 'Portland, ME, US';
            case 'virginiatech': return 'Blacksburg, VA, US';
        }  
        return null;
    }
    
    private static function createQuery($applicationRelativeURL) {
        $query = XN_Query::create('Content');
        $query->filter('type', '=', 'Posting');
        $query->filter('owner->relativeUrl', 'eic', $applicationRelativeURL);
        // Category not deleted [Jon Aquino 2005-11-05]
        $query->filter('my->category', '<>', null);
        return $query;
    }
     
    public static function xmlForApplicationProper($postingsWithDate, $postingsWithoutDate, $feedGeneratedTime, $metroArea) {
        $xml .= '<?xml version="1.0" encoding="utf-8"?>';
        $xml .= "\n" . '<listing_feed>';
        $xml .= "\n" . '  <feed_generated_time>' . $feedGeneratedTime . '</feed_generated_time>';
        $xml .= "\n" . '  <listings>';
        foreach ($postingsWithDate as $posting) {
            $xml .= self::xmlForPosting($posting, $metroArea);
        }
        foreach ($postingsWithoutDate as $posting) {
            $xml .= self::xmlForPosting($posting, $metroArea);
        }
        $xml .= "\n" . '  </listings>';
        $xml .= "\n" . '</listing_feed>';  
        return $xml;
    } 
     
    private static function xmlForPosting($posting, $metroArea) {
        return self::xmlForPostingProper($posting, $posting->owner->relativeUrl, date('c', strtotime($posting->createdDate)), $metroArea, $posting->my->content('category'), $posting->my->content('subcategory'), is_null($posting->my->date) ? null : (date('c', strtotime($posting->my->date))));
    }
     
    public static function xmlForPostingProper($posting, $applicationRelativeURL, $iso8601CreationDate, $metroArea, $category, $subcategory, $date) {
        // See "Oodle Feed Guidelines", http://sf.oodle.com/info/feed/
        // [Jon Aquino 2005-11-09]        
        $xml .= "\n<listing>";
        $xml .= "\n    <id>" . $posting->id . "</id>";
        $xml .= "\n    <url>" . htmlspecialchars(self::url($applicationRelativeURL, $category, $subcategory, $posting), ENT_COMPAT, 'UTF-8') . "</url>";
        $xml .= "\n    <category>" . htmlspecialchars($category->my->xtitle, ENT_COMPAT, 'UTF-8') . (! is_null($subcategory) ? '/' . htmlspecialchars($subcategory->my->xtitle, ENT_COMPAT, 'UTF-8') : '') . "</category>";
        $xml .= "\n    <title>" . htmlspecialchars($posting->my->xtitle, ENT_COMPAT, 'UTF-8') . "</title>";
        if ($date) {
            $xml .= "\n    <event_date>" . $date . "</event_date>";
        }
        $xml .= "\n    <description>" . htmlspecialchars($posting->my->xdescription, ENT_COMPAT, 'UTF-8') . "</description>";
        // metro_area format from personal communication with Scott Kister, CTO, Oodle.
        // [Jon Aquino 2005-11-09]
        $xml .= "\n    <metro_area>" . htmlspecialchars($metroArea, ENT_COMPAT, 'UTF-8') . "</metro_area>";
        $xml .= "\n    <create_time>" . $iso8601CreationDate . "</create_time>";    
        $xml .= "\n</listing>";
        return $xml;
    }
    
    public static function url($applicationRelativeURL, $category, $subcategory, $posting) {
        return "http://" . $applicationRelativeURL . ".ning.com/index.php?controller=posting&action=show&categoryID=" . ($category->my->localID ? $category->my->localID : $category->id) . "&subcategoryID=" . ($subcategory ? ($subcategory->my->localID ? $subcategory->my->localID : $subcategory->id) : '') . "&id=" . $posting->id;     
    } 
    
}


