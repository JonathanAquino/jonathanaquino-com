<?php

/**
 * A 1-liner to turn a <ul> list into a drag-and-droppable list, for easy reordering of items
 * or moving items between lists. 
 *
 * Also includes a convenient JavaScript function extractNonNullAttributeValues() for extracting ids from the list, 
 * so you can send the new order back to the database. See http://anytownmarketplace.ning.com 
 * for an example of this use. That app also has an example of adding new items to a 
 * drag-and-droppable list (using the makeItemDragable() function).
 *
 * @author Jonathan Aquino
 */
class DragDropHelper { 
    
    /**
     * To make a <ul> sortable, give it a class of "sortable" and include its ID in $listIDs.
     * @param $listIDs array
     */
    public static function initialize($listIDs) { 
        if (SecurityHelper::failed(SecurityHelper::checkCurrentUserIsAppOwner())) { return; } ?>     
        
        <style type="text/css">           
            /* 
            Don't prefix "ul.sortable li" with "#userContent"; otherwise, when you drag a list item
            outside of its list, it disappears for some reason. [Jon Aquino 2005-11-01]
            */
            ul.sortable li {
                position: relative;
                cursor:move;
            }
        </style>
    
        <script language="JavaScript" type="text/javascript" src="lib/DragDrop/coordinates.js"></script>
        <script language="JavaScript" type="text/javascript" src="lib/DragDrop/drag.js"></script>
        <script language="JavaScript" type="text/javascript" src="lib/DragDrop/dragdrop.js"></script>    
        
        <script language="JavaScript" type="text/javascript">
            function extractNonNullAttributeValues(listID, attributeName, delimiter) {            
                var list = document.getElementById(listID);
                
                // Workaround for Firefox issue: In http://anytownmarketplace.ning.com we found
                // that if you drag a <ul> element from the fourth column to someplace far away (e.g. into the sidebar on the right)
                // then let go, the element will return to the list it came from, but for some reason
                // a spurious <ul> element is created in the DOM. Thereafter, getElementById return this
                // spurious <ul> element instead of the real <ul> element. (This had the effect of losing an entire
                // column from the front page when the user hit the Save Layout button). This problem does not
                // happen in IE 6 -- just Firefox. Thanks to Nancy Chacko for identifying this problem.
                // See issue EXA-502. [Jon Aquino 2005-]
                while (! list.hasChildNodes()) {
                    list.parentNode.removeChild(list);
                    list = document.getElementById(listID);
                }
                
                var items = list.getElementsByTagName("li");        
                var nonNullAttributeValues = '';        
                for (var i = 0, n = items.length; i < n; i++) {            
                    var item = items[i];
                    var attributeValue = item.getAttribute(attributeName);
                    if (attributeValue != null) {
                        if (nonNullAttributeValues != '') { nonNullAttributeValues += delimiter; } 
                        nonNullAttributeValues += attributeValue;
                    }			
                }         
                return nonNullAttributeValues;
            }
            // Code from  Tom Westcott, "Multi List Drag and Drop", 
            // http://www.cyberdummy.co.uk/2005/07/13/multi-list-drag-and-drop/
            // Several people contributed to this code; the good thing about Tom's version
            // is that it doesn't lose items dragged to nowhere -- they simply bounce back
            // to their original list. [Jon Aquino 2005-11-01]
            function initializeDragDrop() {
                <?php
                foreach ($listIDs as $listID) { ?>        
                    var list = document.getElementById('<?php echo $listID ?>');
                    DragDrop.makeListContainer(list, 'group1');
                    list.onDragOver = function() { this.style["background"] = "#EEF"; };
                    list.onDragOut = function() {this.style["background"] = "none"; };            
                <?php
                } ?>
            };   
        </script>
        
        <xn:body onload="initializeDragDrop()" />
        
    <?php    
    }
} 
