<?php

require_once 'lib/LocalContentStore/LCS_ContentStore.php';
require_once 'lib/LocalContentStore/LCS_Serializer.php';
require_once 'helpers/NingHelper.php';
require_once 'helpers/BackupHelper.php';
require_once 'helpers/AssertionHelper.php';

class PersistentLocalContentStore extends LCS_ContentStore {
    public function persist() {  
        $xml = LCS_Serializer::serialize($this);
        file_put_contents(LocalContentStoreHelper::$filename, $xml);
        BackupHelper::backup($xml, LocalContentStoreHelper::$filename);
    }      
}

class LocalContentStoreHelper {        
    
    private static $localContentStore;
    
    public static function localContentStore() {        
        if (! self::$localContentStore) {   
            self::createFileIfNecessary();
            self::$localContentStore = LCS_Serializer::unserialize(file_get_contents(self::$filename));            
        }         
        return self::$localContentStore;
    }      
    
    // Put it in xn_private so it won't get cloned. [Jon Aquino 2005-11-18]
    public static $filename = 'xn_private/localContentStore.xml';
    
    public static function createFileIfNecessary() {
        if (! file_exists(self::$filename)) { 
            $query = XN_Query::create('Content')
                ->filter('type', 'eic', 'Category')        
                ->filter('owner', '=');
            $oldCategories = NingHelper::executeQueryWithoutLimit($query);
            $query = XN_Query::create('Content')
                ->filter('type', 'eic', 'Subcategory')        
                ->filter('owner', '=');
            $oldSubcategories = NingHelper::executeQueryWithoutLimit($query);                                   
            $lcs = new PersistentLocalContentStore();                
            self::addLegacyCategoriesToLocalContentStore($oldCategories, $oldSubcategories, $lcs);
            $xml = LCS_Serializer::serialize($lcs);
            // Use @ to disable the display of warnings to the user. You will almost
            // certainly get a warning the first time -- for some reason, a save will
            // not succeed on the first try. See NING-900. [Jon Aquino 2005-11-18]
            if (0 == @file_put_contents(self::$filename, $xml) || ! file_exists(self::$filename)) {
                if (0 == @file_put_contents(self::$filename, $xml) || ! file_exists(self::$filename)) {
                    if (0 == @file_put_contents(self::$filename, $xml) || ! file_exists(self::$filename)) {
                        throw new Exception('Could not create ' . self::$filename);
                    }
                }
            }             
        }
        return self::$filename;
    }
    
    public static function addLegacyCategoriesToLocalContentStore($oldCategories, $oldSubcategories, $localContentStore) {
        // Batch the writes [Jon Aquino 2005-11-17]        
        $localContentStore->persistenceEnabled = false;
        self::addLegacyCategoriesToLocalContentStoreProper($oldCategories, $oldSubcategories, $localContentStore);
        $localContentStore->persistenceEnabled = true;  
        // Don't call $localContentStore->persist() here, as we are in the middle
        // of creating the local content store, and would get into an infinite loop.
        // [Jon Aquino 2005-11-17]
    }
    
    public static function addLegacyCategoriesToLocalContentStoreProper($oldCategories, $oldSubcategories, $localContentStore) {
        foreach ($oldCategories as $oldCategory) {
            $newCategory = $localContentStore->create('Category');
            $w_content = new W_Content($oldCategory);
            foreach ($w_content->export() as $name => $value) {
                $newCategory->my->set($name, $value, $oldCategory->my->attribute($name)->type);
            }
            $newCategory->my->subcategoryIDs = $oldCategory->my->subcategoryIDs;
            if (! is_null($oldCategory->my->postingCount)) {
                $newCategory->my->set('postingCount', intval($oldCategory->my->postingCount), XN_Attribute::NUMBER);
            }
            // Set the id to that of the existing content object, so we won't need
            // to update the IDs in the Application object [Jon Aquino 2005-11-17]
            $newCategory->id = $oldCategory->id;
            $newCategory->foreignID = $oldCategory->id;            
            $newCategory->save();
        }
        foreach ($oldSubcategories as $oldSubcategory) {
            $newSubcategory = $localContentStore->create('Subcategory');            
            $newSubcategory->my->xtitle = $oldSubcategory->my->xtitle;
            // Set the id to that of the existing content object, so we won't need
            // to update the IDs in the Category objects [Jon Aquino 2005-11-17]
            $newSubcategory->id = $oldSubcategory->id;
            $newSubcategory->foreignID = $oldSubcategory->id;
            $newSubcategory->save();
        }
        return $localContentStore;
    }
    
}    
