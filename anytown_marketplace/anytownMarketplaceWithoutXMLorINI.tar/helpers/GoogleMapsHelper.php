<?php
require_once 'AbstractMapsHelper.php';
XN_Application::includeFile('alphacomponents','/Alpha/Services/Google/Maps.php');

/**
 * This class contains static methods that help with creating a Google Map.
 *
 * @author Jonathan Aquino
 */
class GoogleMapsHelper extends AbstractMapsHelper {
    
    private static $instance = null;
    
    public static function instance() {
        if (is_null($instance)) { $instance = new GoogleMapsHelper(); }
        return $instance;
    }    
 
    protected function configureMapType($map) {
        $map->injectJavascript("map.setMapType(map.getMapTypes()[".Config::$mapType."]);");
    }   
    
    public function initialExtentURL() { return Config::$googleMapsInitialExtentURL; }

    protected function createMap($width, $height, $controls, $zoomLevel) {        
        $options = array(
            'mapWidth' => $width, 
            'mapHeight' => $height,            
            'controls' => implode(',', $controls));
        if (! is_null($zoomLevel)) {
            $options['defaultZoom'] = $zoomLevel;
        }
        $map = new XNC_Alpha_Services_Google_Maps(Config::$googleMapsAPIKey, $options);
        return $map;
    }    

}
