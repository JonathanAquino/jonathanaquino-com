<?php

class PHPHelper {        
    
    public static function removeValue($valueToRemove, $array) {
        $newArray = array();
        foreach ($array as $key => $value) {
            if ($value == $valueToRemove) { continue; }
            $newArray[$key] = $value;
        }
        return $newArray;
    }       
    
    public static function concatenate($arrays) {
        $newArray = array();
        foreach($arrays as $array) {
            foreach($array as $item) {
                $newArray[] = $item;
            }
        }
        return $newArray;
    }
    
}


