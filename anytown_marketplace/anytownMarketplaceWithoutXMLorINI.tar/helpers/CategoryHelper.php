<?php

require_once 'helpers/AssertionHelper.php';
require_once 'helpers/LocalContentStoreHelper.php';
require_once 'lib/ShapedContent/W_Content.php';

/**
 * This class centralizes operations on Category and Subcategory content objects,
 * to ease the transition from XN_Content objects to LCS_Content objects.
 * We are switching to LCS_Content ("local content store") objects for categories
 * and subcategories to reduce the amount of database activity when creating
 * these objects immediately after cloning the app. But we still need to create (on demand)
 * real category/subcategory content objects to store in the Posting object,
 * in order to simulate batch deletion when the category/subcategory is deleted.
 * @author Jon Aquino
 */

class CategoryHelper {

    public static function load($id) {  
        return IDHelper::content($id); 
    }
    
    public static function loadW_Content($id) {  
        return new W_Content(self::load(IDHelper::id($id))); 
    }
    
    public static function delete($idOrContent) {   
        if (! is_null(IDHelper::content($idOrContent)->foreignID)) {
            XN_Content::delete(IDHelper::content($idOrContent)->foreignID);
        }
        LocalContentStoreHelper::localContentStore()->delete(IDHelper::id($idOrContent));
    }    
    
    public static function create($type) { return LocalContentStoreHelper::localContentStore()->create($type); }
    
    public static function createW_Content($type) { return new W_Content(self::create($type)); }
    
    public static function contentId($content, $attributeName) {
        return self::idForForeignID($content->my->contentId($attributeName));     
    }
    
    public static function idForForeignID($foreignID) {
        return is_null($foreignID) ? null : LocalContentStoreHelper::localContentStore()->idForForeignID((string)$foreignID);
    }
    
    public static function content($content, $attributeName) {
        $id = self::contentId($content, $attributeName);
        return is_null($id) ? null : self::load($id); 
    }
    
    public static function setContent($content, $attributeName, $idOrContent) { 
        AssertionHelper::assert($attributeName == 'category' || $attributeName == 'subcategory');
        if (is_null($idOrContent)) {
            $content->my->setContent($attributeName, null);
            return;
        }            
        if (is_null(IDHelper::content($idOrContent))) {
            // Can get here if category or subcategory was recently deleted.
            // See EXA-602. Throw exception so we get the friendly "Whoops!" page
            // instead of "Fatal error". [Jon Aquino 2005-11-21]
            throw new Exception("IDHelper::content($idOrContent) is null");
        }        
        if (is_null(IDHelper::content($idOrContent)->foreignID)) {
            $foreignContent = XN_Content::create(ucfirst($attributeName));
            // Store the localID so we can reconstruct the URL in the Oodle feed. [Jon Aquino 2005-11-18]
            $foreignContent->my->localID = IDHelper::id($idOrContent);
            // Set the title so it appears in the pivot. [Jon Aquino 2005-11-21]
            $foreignContent->title = IDHelper::content($idOrContent)->my->xtitle;            
            $foreignContent->save();        
            IDHelper::content($idOrContent)->foreignID = $foreignContent->id;            
            IDHelper::content($idOrContent)->save();
        }
        $content->my->setContent($attributeName, IDHelper::content($idOrContent)->foreignID);
    }        
    
}

class IDHelper {
    public static function id($idOrContent) {
        return gettype($idOrContent) == 'string' ? $idOrContent : (gettype($idOrContent) == 'integer' ? (string)$idOrContent : $idOrContent->id);
    }    
    
    public static function content($idOrContent) {
        return self::contentProper($idOrContent, LocalContentStoreHelper::localContentStore());
    }
    public static function contentProper($idOrContent, $localContentStore) {
        return gettype($idOrContent) == 'string' ? $localContentStore->load($idOrContent) : (gettype($idOrContent) == 'integer' ? $localContentStore->load((string)$idOrContent) : $idOrContent);
    }
}
