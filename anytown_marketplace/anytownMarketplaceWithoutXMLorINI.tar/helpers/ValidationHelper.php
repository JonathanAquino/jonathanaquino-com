<?php

class ValidationHelper {

    public static function validate($w_content) {
        $errors = $w_content->validate();
        $denormalizedErrors = array();
        foreach ($errors as $attributeName => $attributeErrors) {
            foreach ($attributeErrors as $attributeError) {
                $attributeName = $attributeName == 'xtitle' ? 'title' : $attributeName;
                $attributeName = $attributeName == 'xdescription' ? 'description' : $attributeName;
                $denormalizedErrors[] = ucfirst($attributeName) . ' ' . $attributeError;
            }
        }
        return $denormalizedErrors;
    }   
    
    public static function validateImageUpload($postVariableName) {        
        // Based on David Sklar's code in the ThisOrThat app. [Jon Aquino 2005-09-22]
        if($_POST[$postVariableName] == '') { return null; }
        $allowed_file_types = array('gif','jpeg','pjpeg','png'); 
        $file_type = explode('/',$_POST[$postVariableName . ':type']);
        if(!in_array($file_type[1],$allowed_file_types)) {
            return 'Photo ' . $_POST[$postVariableName] . ' does not exist or is not one of the following types: '.join(', ',$allowed_file_types).'.';
        }        
        return ValidationHelper::validateUpload($postVariableName);        
    }    
    
    public static function validateUpload($postVariableName) {
        // Based on David Sklar's code in the ThisOrThat app. [Jon Aquino 2005-09-22]
        if($_POST[$postVariableName] == '') { return null; }
        switch ($_POST[$postVariableName . ':status']) {
            case 1:
            case 2:
                return $_POST[$postVariableName] . ' is too big. Please upload a smaller version.';
            case 3:
            case 4:
                return 'Either ' . $_POST[$postVariableName] . ' is not a complete file, or the upload didn\'t complete for some reason.';
            case 5:
                return 'A system error while trying to upload ' . $_POST[$postVariableName] . '.';
        }      
        return null;
    }              
       
}


