<?php

class PaginationHelper {
    
    public static function displayPaginationHeader($resultsPerPage, $pageStart, $numItems) {
        $pageEnd = min($numItems, $pageStart + $resultsPerPage); ?>
        Showing <?php echo $numItems == 0 ? 0 : ($pageStart+1) ?>-<?php echo $pageEnd ?>
    <?php    
    }
    
    public static function displayPaginationFooter($resultsPerPage, $pageStart, $numItems) {       
        // Based on Anselm Hook's code in the Photo Sharing app. [Jon Aquino 2005-09-22]
        if ($numItems <= $resultsPerPage) { return; }
        $pageEnd = min($numItems, $pageStart + $resultsPerPage);
        $path = '?';
        foreach ($_GET as $name => $value) {
            if ($name == 'start') { continue; }
            $path .= $name . '=' . $value . '&amp;';
        }        
        echo '<p class="pageNav">';        
        if( $pageStart > 0 ) {
            $pageStart -= $resultsPerPage;
            if($pageStart<0) { $pageStart=0; }
            echo ' <span><a href="'.$path.'start='.$pageStart.'">&laquo; previous</a></span>&nbsp;&nbsp;';
            $pageStart += $resultsPerPage;
        }        
        $last = intval(($numItems-1)/$resultsPerPage);
        $current = intval($pageStart/$resultsPerPage);
        $start = $current - 4;
        if($start < 0 ) $start = 0;
        $end = $start + 8;
        echo ' page: ';        
        // bookend?
        if( $start > 0 ) {
            echo ' <a href="'.$path.'start=0">(1)</a> ... ';
        }        
        // region?
        for( $counter = $start; $counter < $end && $counter <= $last; $counter++ ) {
            if($counter == $current ) {
                echo '('.($counter+1).') ';
            } else {
                echo '<a href="'.$path.'start='.($counter*$resultsPerPage).'">('.($counter+1).')</a> ';
            }
        }        
        // bookend?
        if($counter < $last ) {
            echo '... <a href="'.$path.'start='.($last*$resultsPerPage).'">('.($last+1).')</a> ';
        }        
        if( $numItems > $pageEnd ) {
            $pageStart += $resultsPerPage;
            echo ' &nbsp;&nbsp;<span><a href="'.$path.'start='.$pageStart.'">next &raquo;</a></span>';
            $pageStart -= $resultsPerPage;
        }
        echo '</p>';     
    }	

    public static function paginationStart() {
        return isset($_GET['start']) ? max(0, intval($_GET['start'])) : 0;
    }    
    
}


