<?php

require_once 'config/config.php';
require_once 'XNC/Form.php';
require_once 'lib/ShapedContent/W_Content.php';
require_once 'helpers/SecurityHelper.php';
require_once 'helpers/HTMLHelper.php';
require_once 'helpers/DateHelper.php';
require_once 'helpers/CategoryHelper.php';
require_once 'helpers/ValidationHelper.php';
require_once 'helpers/PaginationHelper.php';
require_once 'models/Category.php';
require_once 'models/Application.php';
require_once 'models/Posting.php';

class PostingController {    
    
    public static function process($action, $errors = null) {
        
        switch($action) {
            
            default:
                throw new Exception('Unknown action: ' . $action);                            
                
            case 'show':              
                $posting = XN_Content::load($_GET['id']);
                if (CategoryHelper::content($posting, 'category') == null) { throw new Exception('Category has been deleted'); }
                $posting->focus();    
                $category = CategoryHelper::content($posting, 'category');
                $subcategory = CategoryHelper::content($posting, 'subcategory');
                if ($category->my->postingsHaveComments == 'Y' || $category->my->postingsHaveRatings == 'Y') {
                    $comments = Posting::comments($posting);                     
                }
                $form = new XNC_Form(array());
                include 'views/posting/show.php';    
                break;                

            case 'selectCategory':
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsSignedIn())) { return; }
                $categories = Application::categoriesSortedByName();                   
                include 'views/posting/selectCategory.php';   
                break;     
                
            case 'new':
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsSignedIn())) { return; }
                $category = CategoryHelper::load($_GET['categoryID']);
                if (is_null($category)) {
                    // Get here if category has just been deleted. See EXA-603. [Jon Aquino 2005-11-21]
                    HTMLHelper::redirect('index.php?controller=posting&action=selectCategory');
                    break;
                }
                if ($category->type != 'Category') {
                    // Get here if user tries to stick a subcategory ID into the category ID parameter. See EXA-603. [Jon Aquino 2005-11-21]
                    HTMLHelper::redirect('index.php?controller=posting&action=selectCategory');
                    break;
                }                
                $subcategory = $_GET['subcategoryID'] ? CategoryHelper::load($_GET['subcategoryID']) : null;
                $subcategories = NingHelper::sortByTitle(Category::subcategories($category));
                $form = new XNC_Form(array('displayingUsername' => 'Y', 'allowingMessaging' => 'Y'));
                include 'views/posting/new.php';   
                break;        
            
            case 'create':      
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsSignedIn())) { return; }                                
                $category = CategoryHelper::load($_GET['categoryID']);
                $posting = W_Content::create('Posting');
                CategoryHelper::setContent($posting, 'category', $_GET['categoryID']);
                CategoryHelper::setContent($posting, 'subcategory', $_POST['subcategoryID'] ? $_POST['subcategoryID'] : null);
                $posting->my->displayingUsername = 'Y';
                $posting->my->allowingMessaging = 'Y';                
                self::validateAndSave($posting, $category, 'new');
                Category::updatePostingCount($category);                  
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);                
                break;     
                
            case 'edit':
                // categoryID and subcategoryID are used by the Post link in the header [Jon Aquino 2005-11-02]
                AssertionHelper::assert($_GET['categoryID']);            
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                $category = CategoryHelper::content($posting, 'category');
                $subcategory = CategoryHelper::content($posting, 'subcategory');
                $subcategories = NingHelper::sortByTitle(Category::subcategories($category));
                $defaults = $posting->export();
                if ($category->my->postingsHaveDate == 'Y' && $defaults['date']) {
                    $defaults['year'] = date('Y', strtotime($defaults['date']));
                    $defaults['month'] = date('m', strtotime($defaults['date']));
                    $defaults['day'] = date('d', strtotime($defaults['date']));
                }
                $form = new XNC_Form($defaults);
                $posting->focus();
                include 'views/posting/edit.php';       
                break;   
                
            case 'update':                                     
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                $category = CategoryHelper::content($posting, 'category');
                CategoryHelper::setContent($posting, 'subcategory', $_POST['subcategoryID'] ? $_POST['subcategoryID'] : null);
                self::validateAndSave($posting, $category, 'edit');
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);   
                break;       
                
            case 'deletePhoto':                                     
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                $posting->my->setContent('photo' . $_GET['photoNumber'], null);
                $posting->save();
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);   
                break;   
                
            case 'delete':
                $posting = XN_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                $category = CategoryHelper::content($posting, 'category');
                $subcategory = CategoryHelper::content($posting, 'subcategory');
                XN_Content::delete($posting);
                Category::updatePostingCount($category);
                if ($_GET['targetURL']) {
                    HTMLHelper::redirect($_GET['targetURL']);
                } elseif ($subcategory != null) {
                    HTMLHelper::redirect('index.php?controller=posting&action=list&categoryID=' . $category->id . '&subcategoryID=' . $subcategory->id);
                } else {
                    HTMLHelper::redirect('index.php?controller=posting&action=list&categoryID=' . $category->id);
                }
                break;                                                                                                  
                
            case 'list':                          
                $query = XN_Query::create('Content');
                if ($_GET['query']) {
                    // Removed the code that replaced non-alpha characters with spaces,
                    // as this was filtering out international characters. [Jon Aquino 2005-11-19]
                    $query->filter('my->searchableText', 'likeic', $_GET['query']);                    
                }
                if ($_GET['by']) {
                    $query->filter('contributorName', '=', $_GET['by']);
                    if (XN_Profile::current()->screenName != $_GET['by']) {
                        // Filter out anonymous postings to protect people's privacy [Jon Aquino 2005-10-31]
                        $query->filter('my->displayingUsername', '=', 'Y');
                    }
                }                
                if ($_GET['tag']) {
                    $query->filter('tag->value','eic',$_GET['tag']);
                }     
                if ($_GET['postingsWithRatingsOnly'] == 'yes') {
                    $query->filter('my->averageRating', '<>', null);
                }
                if (HTMLHelper::extractNumber($_GET['minPrice'])) {
                    $query->filter('my->searchablePrice', '>=', HTMLHelper::extractNumber($_GET['minPrice']));
                }                
                if (HTMLHelper::extractNumber($_GET['maxPrice'])) {
                    $query->filter('my->searchablePrice', '<=', HTMLHelper::extractNumber($_GET['maxPrice']));
                }                              
                if (HTMLHelper::extractNumber($_GET['minRating'])) {
                    $query->filter('my->averageRating', '>=', HTMLHelper::extractNumber($_GET['minRating']));
                }                
                if (HTMLHelper::extractNumber($_GET['maxRating'])) {
                    $query->filter('my->averageRating', '<=', HTMLHelper::extractNumber($_GET['maxRating']));
                }                                                                 
                if (HTMLHelper::extractNumber($_GET['minAge'])) {
                    $query->filter('my->age', '>=', HTMLHelper::extractNumber($_GET['minAge']));
                }                
                if (HTMLHelper::extractNumber($_GET['maxAge'])) {
                    $query->filter('my->age', '<=', HTMLHelper::extractNumber($_GET['maxAge']));
                }                     
                if ($_GET['categoryID']) {
                    $category = CategoryHelper::load($_GET['categoryID']);
                    $query->filter('my->category', '=', $category->foreignID);
                }            
                if ($_GET['subcategoryID']) {
                    $subcategory = CategoryHelper::load($_GET['subcategoryID']);
                    $query->filter('my->subcategory', '=', $subcategory->foreignID);
                }                   
                $sortDirection = 'desc';
                $sortAttribute = 'createdDate';
                if (isset($_GET['date'])) {
                    $timestamp = DateHelper::stripHoursMinutesSeconds(strtotime($_GET['date']));
                    // Use > -1, < +1 rather than >=, <=, which currently do not work with strings (see NING-911) [Jon Aquino 2005-10-27]                
                    $query->filter('my->date', '>', date('c', $timestamp-1));                                   
                    $previousWeekURL = 'index.php?controller=posting&amp;action=list&amp;categoryID=' . $_GET['categoryID'] . '&amp;subcategoryID=' . $_GET['subcategoryID'] . '&amp;date=' . date('Y-m-d', strtotime($_GET['date']) - (7 * 24 * 60 * 60));
                    $sortDirection = 'asc';
                    $sortAttribute = 'my->date';
                }
                // Category not deleted [Jon Aquino 2005-11-05]
                $query->filter('my->category', '<>', null);
                $postURL = $category ? 'index.php?controller=posting&amp;action=new&amp;categoryID=' . $category->id . '&amp;subcategoryID=' . $subcategory->id : 'index.php?controller=posting&amp;action=selectCategory';
                $postText = $category ? ('Post to ' . $category->my->h('xtitle')) : 'Post a listing';                       
                $query->filter('type', 'eic', 'Posting');                    
                $query->filter('owner', '=');
                $query->order($sortAttribute, $sortDirection);
                if ($_GET['view'] == 'rss') {
                    AssertionHelper::assert($_GET['xn_auth'] == 'no', 'Add &xn_auth=no to URL');
                    // If date parameter is specified, the sort attribute and direction don't make
                    // sense for the RSS feed [Jon Aquino 2005-11-09]
                    AssertionHelper::assert(is_null($_GET['date']) || $_GET['date'] == '', 'Remove &date=... from URL');
                    $query->end(90);                     
                    $postings = $query->execute();                    
                    include 'views/posting/rss.php';                    
                } else {
                    $query->begin(PaginationHelper::paginationStart());
                    $query->end(PaginationHelper::paginationStart() + Config::$postingsPerPage); 
                    $query->alwaysReturnTotalCount(true);                    
                    $postings = $query->execute(); 
                    $geocodedPostings = array();
                    foreach ($postings as $posting) {
                        if ($posting->my->latitudeAndLongitudeFound == 'Y') {
                            $geocodedPostings[] = $posting;
                        }
                    }
                    include 'views/posting/list.php';                     
                }
                break;   
                
            case 'replyByEmail':
                // categoryID and subcategoryID are used by the Post link in the header [Jon Aquino 2005-11-02]
                AssertionHelper::assert($_GET['categoryID']);  
                $posting = XN_Content::load($_GET['id']);
                if (CategoryHelper::content($posting, 'category') == null) { throw new Exception('Category has been deleted'); }
                if (SecurityHelper::reportFailure(SecurityHelper::checkPostingAllowsMessaging($posting))) { return; }
                include 'views/posting/replyByEmail.php';   
                break;     
                
            case 'newMap':
                // categoryID and subcategoryID are used by the Post link in the header [Jon Aquino 2005-11-02]
                AssertionHelper::assert($_GET['categoryID']);            
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                $form = new XNC_Form(array());
                $posting->focus();
                include 'views/posting/newMap.php';       
                break;                                 

            case 'createMap':                                     
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                self::validateAndSaveMap($posting, 'newMap');
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);   
                break;    
                
            case 'editMap':
                // categoryID and subcategoryID are used by the Post link in the header [Jon Aquino 2005-11-02]
                AssertionHelper::assert($_GET['categoryID']);            
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                $form = new XNC_Form(array('address' => $posting->my->address, 'city' => $posting->my->city, 'state' => $posting->my->state));
                $posting->focus();
                include 'views/posting/editMap.php';       
                break;  
                
            case 'updateMap':                                     
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                self::validateAndSaveMap($posting, 'editMap');
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);   
                break;                    
                
            case 'deleteMap':                                     
                $posting = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($posting))) { return; }
                self::validateAndSaveMap($posting, null);
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);   
                break;                 
        }

    }              

    private static function validate($posting, $category) {
        $errors = ValidationHelper::validate($posting);                     
        $uploadError = ValidationHelper::validateImageUpload('Posting:photo1');        
        if ($uploadError != null) { $errors[] = $uploadError; }
        $uploadError = ValidationHelper::validateImageUpload('Posting:photo2');        
        if ($uploadError != null) { $errors[] = $uploadError; }
        $uploadError = ValidationHelper::validateImageUpload('Posting:photo3');        
        if ($uploadError != null) { $errors[] = $uploadError; }        
        if ($category->my->postingsHaveDate == 'Y' ) {
            if (strlen($_POST['year']) == 0 || strlen($_POST['month']) == 0 || strlen($_POST['day']) == 0) { 
                $errors[] = 'Date is required'; 
            } elseif (! DateHelper::dateValid($_POST['year'], $_POST['month'], $_POST['day'])) { 
                $errors[] = 'Date must be a valid mm/dd/yyyy date'; 
            }   
        }        
        if (strlen($_POST['tags']) > 100) { $errors[] = "Tags shouldn't be more than 100 characters long"; }
        return $errors;
    }       
    
    private static function cleanPostVariables($category) {
        if (isset($_POST['year'])) { $_POST['date'] = date('c', strtotime($_POST['year'] . '-' . $_POST['month'] . '-' . $_POST['day'])); }
        $_POST['displayingUsername'] = HTMLHelper::cleanBoolean($_POST['displayingUsername']);        
        if ($category->my->postingsHaveMessaging == 'Y') {
            $_POST['allowingMessaging'] = HTMLHelper::cleanBoolean($_POST['allowingMessaging']);
        }        
        if ($category->my->postingsHavePrice == 'Y') {
            $_POST['price'] = self::removeInitialDollarSign($_POST['price']);
        }                
    }          
    
    public static function removeInitialDollarSign($x) {
        return is_null($x) ? null : preg_replace('/^\$/', '', trim($x));
    }
    
    public static function formattedTitle($posting) {        
        return htmlentities(self::formattedTitleRaw($posting), ENT_QUOTES, 'UTF-8');
    }
    public static function formattedTitleRaw($posting) {
        $formattedTitle = '';                
        if ($posting->my->price) { $formattedTitle .= '$' . $posting->my->price . ' - '; }        
        $formattedTitle .= $posting->my->xtitle;        
        if ($posting->my->age) { $formattedTitle .= ' - ' . $posting->my->age; }        
        if ($posting->my->location) { $formattedTitle .= ' - ' . $posting->my->location; }
        return $formattedTitle;
    }
    
    private static function validateAndSave($posting, $category, $validationFailedAction) {
        self::cleanPostVariables($category);
        $posting->import($_POST);
        if ($errors = self::validate($posting, $category)) {
            self::process($validationFailedAction, $errors);
            exit();
        }
        $posting->isPrivate = $posting->my->displayingUsername == 'N';
        Posting::updateStatistics($posting);         
        HTMLHelper::processImage('photo1', $posting);
        HTMLHelper::processImage('photo2', $posting);
        HTMLHelper::processImage('photo3', $posting);
        // Set the title so it appears in the pivot. [Jon Aquino 2005-11-21]
        $posting->title = $posting->my->xtitle;
        $posting->save();           
        NingHelper::addTags($posting, $_POST['tags']);
    }
    
    private static function validateMap() {
        $errors = array();
        if (strlen($_POST['address']) > 100) { $errors[] = "Address shouldn't be more than 100 characters long"; }
        if (strlen($_POST['city']) > 100) { $errors[] = "City shouldn't be more than 100 characters long"; }
        if (strlen($_POST['state']) > 2) { $errors[] = "State shouldn't be more than 2 characters long"; }
        return $errors;
    }           
    
    private static function validateAndSaveMap($posting, $validationFailedAction) {
        if ($errors = self::validateMap()) {
            self::process($validationFailedAction, $errors);
            exit();
        }
        $posting->my->address = $_POST['address'] == '' ? null : $_POST['address'];
        $posting->my->city = $_POST['city'] == '' ? null : $_POST['city'];
        $posting->my->state = $_POST['state'] == '' ? null : $_POST['state'];
        $posting->my->latitude = $_POST['latitude'] == '' ? null : $_POST['latitude'];
        $posting->my->longitude = $_POST['longitude'] == '' ? null : $_POST['longitude'];
        $posting->my->zoomLevel = $_POST['zoomLevel'] == '' ? null : $_POST['zoomLevel'];
        // If the latitude was not set (by AJAX), give the lat/long a chance to be set
        // lazily by setting latitudeAndLongitudeFound to null rather than 'N'. [Jon Aquino 2005-11-19]
        $posting->my->latitudeAndLongitudeFound = is_null($posting->my->latitude) ? null : 'Y';     
        $posting->save();           
    }

    public static function summary($posting, $currentCategory, $currentSubcategory, $googleMapsBubble = false) {         
        ob_start();
        ?>
        <a href="index.php?controller=posting&amp;action=show&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>"><?php echo self::formattedTitle($posting); ?></a>
        <?php                        
        if ($categorySubcategoryLink = HTMLHelper::categorySubcategoryLink($posting, ! $currentCategory, ! $currentSubcategory)) { echo ($googleMapsBubble ? '<br />' : ' in ') . $categorySubcategoryLink . ($googleMapsBubble ? '<br />' : ''); }
        if ($posting->my->commentCount) { echo '<span>' . $posting->my->commentCount . ' ' . HTMLHelper::plural('comment', $posting->my->commentCount) . '</span>'; } 
        if ($posting->my->averageRating) { echo '<span><img src="images/stars' . $posting->my->averageRating . '.gif" /></span>'; }   
        if ($posting->my->photo1 || $posting->my->photo2 || $posting->my->photo3) { echo '<span>photo</span>'; }
        // Don't show the Delete link in the Google Maps bubble. Otherwise, 
        // if you are in posting/show and click Delete, you get an exception:
        // "Cannot find content with ID '559378'". See EXA-597. [Jon Aquino 2005-11-21]
        if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserContributed($posting)) && !$googleMapsBubble) { ?>
            <span>
                <a class="editDelete" href="index.php?controller=posting&amp;action=edit&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>">Edit</a> |
                <a class="editDelete" href="index.php?controller=posting&amp;action=delete&amp;id=<?php echo $posting->id ?>&amp;targetURL=<?php echo htmlentities(urlencode(HTMLHelper::currentURL()), ENT_QUOTES, 'UTF-8') ?>" onclick="javascript:return confirm('Are you sure you want to delete this posting?')">Delete</a>
            </span>
        <?php
        } 
        $summary = ob_get_contents();
        ob_end_clean();         
        return $summary;
    }    
    
}   





