<?php

require_once 'config/config.php';
require_once 'helpers/OodleHelper.php';
require_once 'helpers/HTMLHelper.php';

class ApplicationController {    
    
    public static function process($action, $errors = null) {
        
        switch($action) {
            
            default:
                throw new Exception('Unknown action: ' . $action);                            
                
            case 'rss':  
                AssertionHelper::assert($_GET['xn_auth'] == 'no', 'Add &xn_auth=no to URL');
                $applications = self::applications();
                include 'views/application/rss.php';
                break;
                
            case 'list':  
                $applications = self::applications();
                include 'views/application/list.php';
                break;                
                
            case 'oodle':  
                AssertionHelper::assert($_GET['xn_auth'] == 'no', 'Add &xn_auth=no to URL');
                AssertionHelper::assert($_GET['applicationRelativeURL'], 'Add &applicationRelativeURL=... to URL');
                $application = XN_Query::create('Content')
                    ->filter('type', 'eic', 'Application')
                    ->filter('owner->relativeUrl', 'eic', $_GET['applicationRelativeURL'])
                    // Filter out spurious anonymous objects -- workaround
                    // for issue NING-935 [Jon Aquino 2005-11-08]                    
                    ->filter('contributor', '<>', null)
                    ->uniqueResult();                                
                header("Content-Type: text/xml");                
                echo OodleHelper::xmlForApplication($_GET['applicationRelativeURL'], $_GET['maxPostingsWithDate'], $_GET['maxPostingsWithoutDate'], OodleHelper::metroArea($application));
                break;                
                         
        }

    }        
    
    private static function applications() {
        $query = XN_Query::create('Content');
        $query->filter('type', '=', 'Application');
        $query->filter('my->originalApp', '=', 'AnytownMarketplace');
        // Filter out spurious anonymous objects -- workaround
        // for issue NING-935 [Jon Aquino 2005-11-08]                    
        $query->filter('contributor', '<>', null);
        $query->order('createdDate', 'desc');
        return NingHelper::executeQueryWithoutLimit($query);    
    }
    
}   




