<?php

require_once 'config/config.php';
require_once 'helpers/SecurityHelper.php';
require_once 'helpers/ValidationHelper.php';
require_once 'helpers/HTMLHelper.php';
require_once 'helpers/CategoryHelper.php';
require_once 'lib/ShapedContent/W_Content.php';
require_once 'models/Comment.php';
require_once 'controllers/PostingController.php';

class CommentController {            
    
    public static function process($action, $errors = null) {
        
        switch($action) {
            
            default:
                throw new Exception('Unknown action: ' . $action);
                
            case 'create':
                $posting = XN_Content::load($_GET['postingID']);                
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserHasNotRated($posting))) { return; }
                $comment = W_Content::create('Comment');
                $comment->import($_POST);                
                if ($errors = ValidationHelper::validate($comment)) {
                    $_GET['id'] = $_GET['postingID'];
                    PostingController::process('show', $errors);
                    return;
                }                               
                $comment->my->setContent('posting', $posting);
                $comment->save(); 
                Posting::updateStatistics($posting);
                $posting->save();
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);           
                break;          
                
            case 'delete':
                $comment = XN_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($comment))) { return; }
                $posting = $comment->my->content('posting');            
                XN_Content::delete($comment);
                Posting::updateStatistics($posting);
                $posting->save();
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);
                break;          
                
            case 'edit':
                $comment = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($comment))) { return; }
                $posting = $comment->my->content('posting');
                $category = CategoryHelper::content($posting, 'category');
                $subcategory = CategoryHelper::content($posting, 'subcategory');
                $form = new XNC_Form($comment->export());
                $comment->focus();
                include 'views/comment/edit.php';       
                break;         
                
            case 'update':         
                $comment = W_Content::load($_GET['id']);
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserContributed($comment))) { return; }
                $comment->import($_POST);
                if ($errors = ValidationHelper::validate($comment)) {
                    self::process('edit', $errors);
                    return;
                }                 
                $comment->save(); 
                $posting = $comment->my->content('posting');
                Posting::updateStatistics($posting);
                $posting->save();
                HTMLHelper::redirect('index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);   
                break;                  
                                
        }

    }     
    
}   




