<?php

require_once 'config/config.php';
require_once 'XNC/Form.php';
require_once 'lib/ShapedContent/W_Content.php';
require_once 'helpers/SecurityHelper.php';
require_once 'helpers/ValidationHelper.php';
require_once 'helpers/HTMLHelper.php';
require_once 'helpers/PHPHelper.php';
require_once 'helpers/CategoryHelper.php';
require_once 'helpers/DateHelper.php';
require_once 'helpers/DragDropHelper.php';
require_once 'models/Category.php';
require_once 'models/Application.php';

class CategoryController {            
    
    public static function process($action, $errors = null) {
        
        switch($action) {
            
            default:
                throw new Exception('Unknown action: ' . $action);     
                
            case 'list':          
                $recentGeocodedPostings = XN_Query::create('Content')
                    ->filter('my->latitudeAndLongitudeFound', '=', 'Y')
                    ->filter('type', 'eic', 'Posting')                    
                    ->filter('owner', '=')
                    // Category not deleted [Jon Aquino 2005-11-05]
                    ->filter('my->category', '<>', null)
                    ->order('createdDate', 'desc')
                    ->end(10)                     
                    ->execute();                 
                $recentReviews = XN_Query::create('Content')
                    ->filter('my->averageRating', '<>', null)
                    ->filter('type', 'eic', 'Posting')                    
                    ->filter('owner', '=')
                    // Category not deleted [Jon Aquino 2005-11-05]
                    ->filter('my->category', '<>', null)
                    ->order('createdDate', 'desc')
                    ->end(Config::$reviewsOnFrontPage)                     
                    ->execute();                 
                $column1Categories = Application::categoriesInColumn(1);
                $column2Categories = Application::categoriesInColumn(2);
                $column3Categories = Application::categoriesInColumn(3);
                $column4Categories = Application::categoriesInColumn(4);      
                $categoriesSortedByName = Application::categoriesSortedByName();                  
                $query = XN_Query::create('Content');
                $query->filter('type', '=', 'Application');
                $query->filter('my->originalApp', '=', 'AnytownMarketplace');
                // Filter out spurious anonymous objects -- workaround
                // for issue NING-935 [Jon Aquino 2005-11-08]                    
                $query->filter('contributor', '<>', null);
                $query->order('createdDate', 'desc');
                $query->end(20);
                $applicationCandidates = $query->execute();
                $applications = array();
                foreach ($applicationCandidates as $application) {
                    if ($application->owner->publishedState == 'N') { continue; }                    
                    $applications[] = $application;
                    if (count($applications) == 6) { break; }
                }
                include 'views/category/list.php';       
                break;                                             
                
            case 'new':
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsAppOwner())) { return; }
                $form = new XNC_Form(array('postingsHaveLocation' => 'Y', 'postingsHaveMessaging' => 'Y'));
                include 'views/category/new.php';   
                break;                                   
            
            case 'create':      
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsAppOwner())) { return; }
                $category = CategoryHelper::createW_Content('Category');                
                self::validateAndSave($category, 'new');                  
                Application::instance()->my->set('column' . $_GET['column'] . 'CategoryIDs', trim(Application::categoryIDStringForColumn($_GET['column']) . ' ' . $category->id));                
                Application::instance()->save();
                Application::serialize();
                HTMLHelper::redirect('index.php?controller=category&action=list'); 
                break;   
                
            case 'saveLayout':      
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsAppOwner())) { return; }
                Application::instance()->my->set('column1CategoryIDs', $_POST['column1CategoryIDs']);
                Application::instance()->my->set('column2CategoryIDs', $_POST['column2CategoryIDs']);
                Application::instance()->my->set('column3CategoryIDs', $_POST['column3CategoryIDs']);
                Application::instance()->my->set('column4CategoryIDs', $_POST['column4CategoryIDs']);
                Application::instance()->save();
                Application::serialize();
                HTMLHelper::redirect('index.php?controller=category&action=list'); 
                break;                   
                
            case 'delete':        
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsAppOwner())) { return; }
                // Don't actually delete it; otherwise we will have errors because of orphaned postings
                // (orphaned because it is expensive to delete each child posting) [Jon Aquino 2005-10-28]
                Application::instance()->my->set('column1CategoryIDs', implode(' ', PHPHelper::removeValue($_GET['id'], Application::categoryIDsInColumn(1))));
                Application::instance()->my->set('column2CategoryIDs', implode(' ', PHPHelper::removeValue($_GET['id'], Application::categoryIDsInColumn(2))));
                Application::instance()->my->set('column3CategoryIDs', implode(' ', PHPHelper::removeValue($_GET['id'], Application::categoryIDsInColumn(3))));
                Application::instance()->my->set('column4CategoryIDs', implode(' ', PHPHelper::removeValue($_GET['id'], Application::categoryIDsInColumn(4))));
                Application::instance()->save();   
                Application::serialize();
                $category = CategoryHelper::load($_GET['id']);
                $subcategoryIDs = Category::subcategoryIDs($category);
                LocalContentStoreHelper::localContentStore()->persistenceEnabled = false;
                foreach ($subcategoryIDs as $subcategoryID) {
                    CategoryHelper::delete($subcategoryID);
                }                                
                CategoryHelper::delete($category);
                LocalContentStoreHelper::localContentStore()->persistenceEnabled = true;
                LocalContentStoreHelper::localContentStore()->persist();                
                HTMLHelper::redirect('index.php?controller=category&action=list');   
                break;      
                
            case 'edit':
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsAppOwner())) { return; }
                $category = CategoryHelper::loadW_Content($_GET['id']);                
                $form = new XNC_Form($category->export());
                $category->focus();                
                include 'views/category/edit.php';       
                break;          
                
            case 'update':
                if (SecurityHelper::reportFailure(SecurityHelper::checkCurrentUserIsAppOwner())) { return; }
                $category = CategoryHelper::loadW_Content($_GET['id']);
                self::validateAndSave($category, 'edit');    
                Application::serialize();
                HTMLHelper::redirect('index.php?controller=category&action=list');   
                break;                     
                                
        }

    }         
    
    private static function cleanPostVariables() {
        $_POST['postingsHaveLocation'] = HTMLHelper::cleanBoolean($_POST['postingsHaveLocation']);
        $_POST['postingsHavePrice'] = HTMLHelper::cleanBoolean($_POST['postingsHavePrice']);
        $_POST['postingsHaveAge'] = HTMLHelper::cleanBoolean($_POST['postingsHaveAge']);
        $_POST['postingsHaveDate'] = HTMLHelper::cleanBoolean($_POST['postingsHaveDate']);
        $_POST['postingsHaveComments'] = HTMLHelper::cleanBoolean($_POST['postingsHaveComments']);
        $_POST['postingsHaveRatings'] = HTMLHelper::cleanBoolean($_POST['postingsHaveRatings']);
        $_POST['postingsHaveMessaging'] = HTMLHelper::cleanBoolean($_POST['postingsHaveMessaging']);
    }        
    
    private static function validateAndSave($category, $validationFailedAction) {
        self::cleanPostVariables();                
        $category->import($_POST);
        if ($errors = ValidationHelper::validate($category)) {
            self::process($validationFailedAction, $errors);
            exit();
        }                 
        $subcategoryIDsAndNames = $_POST['subcategoryIDsAndNames']? explode('^', $_POST['subcategoryIDsAndNames']) : array();
        AssertionHelper::assert(fmod(count($subcategoryIDsAndNames), 2) == 0, $_POST['subcategoryIDsAndNames']);
        $oldSubcategoryIDs = Category::subcategoryIDs($category);
        $newSubcategoryIDs = array();
        LocalContentStoreHelper::localContentStore()->persistenceEnabled = false;
            for ($i = 0; $i < count($subcategoryIDsAndNames); $i += 2) {
                $subcategoryID = $subcategoryIDsAndNames[$i];
                $subcategoryName = $subcategoryIDsAndNames[$i+1];
                $subcategory = self::subcategory($subcategoryID);        
                if ($subcategory->my->xtitle != $subcategoryName) {
                    // Saving takes a few seconds, so only do it if necessary [Jon Aquino 2005-11-01]
                    $subcategory->my->xtitle = $subcategoryName;
                    $subcategory->save();
                }
                $newSubcategoryIDs[] = $subcategory->id;
            }        
            $category->my->subcategoryIDs = implode(' ', $newSubcategoryIDs);        
            $category->save(); 
            foreach ($oldSubcategoryIDs as $oldSubcategoryID) {
                if (! in_array($oldSubcategoryID, $newSubcategoryIDs)) {
                    CategoryHelper::delete($oldSubcategoryID);
                }
            }
        LocalContentStoreHelper::localContentStore()->persistenceEnabled = true;
        LocalContentStoreHelper::localContentStore()->persist();
    }    
    
    private static function subcategory($subcategoryID) {
        return $subcategoryID == 'new' ? CategoryHelper::create('Subcategory') : CategoryHelper::load($subcategoryID);
    }
    
}   




