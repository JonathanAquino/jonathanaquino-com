<?php XN_Application::includeFile('livebadge','/badgeProper.php'); ?>
