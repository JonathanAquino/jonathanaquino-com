<?php
require_once 'PHPUnit.php';
require_once 'lib/LocalContentStore/LCS_Content.php';
require_once 'lib/LocalContentStore/LCS_ContentStore.php';
require_once 'lib/LocalContentStore/LCS_Serializer.php';

class LCSContentTest extends PHPUnit_TestCase {    
    
    public function testUTF8() {
        $localContentStore = new LCS_ContentStore();        
        $category = $localContentStore->create('Category');
        $category->my->xtitle = utf8_encode('�res annonces publi�es � more');
        $category->save();
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);
        $this->assertEquals(utf8_encode('�res annonces publi�es � more'), $category->my->xtitle);
    }
    
    public function testIDs() {
        $localContentStore = new LCS_ContentStore();        
        $category = $localContentStore->create('Category');        
        $this->assertEquals(null, $category->id);        
        $category->save();        
        $this->assertEquals('L1', $category->id);
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);        
        $this->assertEquals('Category', $category->type);
        $this->assertEquals('L1', $category->id);           
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->create('Category');
        $this->assertEquals(null, $category->id);
        $category->save();
        $this->assertEquals('L2', $category->id, '20051115');
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);        
        $this->assertEquals('L2', $category->id, '20051115b');
    }   
    
    public function testBasicIO() {        
        $localContentStore = new LCS_ContentStore();
        $category = $localContentStore->create('Category');
        $category->my->xtitle = 'Cars & Trucks';
        $category->save();
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);        
        $this->assertEquals('Cars & Trucks', $category->my->xtitle);
        $this->assertEquals('Cars &amp; Trucks', $category->my->h('xtitle'));
        $this->assertEquals('Cars & Trucks', $category->my->raw('xtitle'));
        $this->assertEquals('string', gettype($category->my->xtitle));
        $category->my->set('color', 'green');
        $category->save();
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);        
        $this->assertEquals('green', $category->my->color);
        $this->assertEquals('string', gettype($category->my->color));
        $category->my->set('color', null);
        $category->save();
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);        
        $this->assertEquals(null, $category->my->color);
        $category->my->set('color', null, XN_Attribute::STRING);
        $category->save();
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);        
        $this->assertEquals(null, $category->my->color);
        $category->my->set('age', 28, XN_Attribute::NUMBER);
        $category->save();
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);        
        $this->assertEquals(28, $category->my->age);
        $this->assertEquals('integer', gettype($category->my->age));
        $category->my->set('age', 28.5, XN_Attribute::NUMBER);
        $category->save();
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);        
        $this->assertEquals(28.5, $category->my->age);
        $this->assertEquals('double', gettype($category->my->age));
        $category->my->set('age', '28.5', XN_Attribute::NUMBER);
        $category->my->set('age', null, XN_Attribute::NUMBER);
        $category->save();
        $localContentStore = LCS_Serializer::unserialize(LCS_Serializer::serialize($localContentStore));
        $category = $localContentStore->load($category->id);        
        $this->assertEquals(null, $category->my->age);
        $category->my->set('birthday', date('c'), XN_Attribute::DATE);
    }
    
    public function testFocus() {
        $localContentStore = new LCS_ContentStore();
        $category = $localContentStore->create('Category');
        $category->focus();
    }
    
}

?>


