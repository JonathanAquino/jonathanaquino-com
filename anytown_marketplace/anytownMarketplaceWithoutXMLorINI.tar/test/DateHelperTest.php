<?php
require_once 'PHPUnit.php';
require_once 'helpers/DateHelper.php';

class DateHelperTest extends PHPUnit_TestCase {    
    
    public function testDateValid() {
        $this->assertTrue(DateHelper::dateValid('1000', '01', '01'));
        $this->assertFalse(DateHelper::dateValid('999', '01', '01'));
        $this->assertFalse(DateHelper::dateValid('1000', '00', '01'));
        $this->assertFalse(DateHelper::dateValid('1000', '01', '00'));
        $this->assertTrue(DateHelper::dateValid('9999', '12', '31'));
        $this->assertFalse(DateHelper::dateValid('10000', '12', '31'));
        $this->assertFalse(DateHelper::dateValid('9999', '13', '31'));
        $this->assertFalse(DateHelper::dateValid('9999', '12', '32'));
        // Feb 31 passes -- oh well [Jon Aquino 2005-11-05]
        $this->assertTrue(DateHelper::dateValid('1000', '02', '31'));
        $this->assertFalse(DateHelper::dateValid('A', 'B', 'C'));
    }                           
    
}

?>


