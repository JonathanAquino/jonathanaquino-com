<?php
require_once 'PHPUnit.php';
require_once 'models/Category.php';
require_once 'helpers/CategoryHelper.php';

class CategoryTest extends PHPUnit_TestCase {            
    
    public function testSerializeCategory() {
        $this->doTestSerializeCategory(W_Content::create('Category'));
        $localContentStore = new LCS_ContentStore();
        $this->doTestSerializeCategory(new W_Content($localContentStore->create('Category')));
    }
    public function doTestSerializeCategory($category) {
        $category->my->xtitle = utf8_encode('events & � classes');
        $category->my->postingsHaveDate = 'Y';
        $category->my->postingsHavePrice = null;
        $category->my->postingsHaveLocation = 'Y';
        $category->my->postingsHaveAge = 'N';
        $category->my->postingsHaveComments = 'N';
        $category->my->postingsHaveMessaging = 'Y';
        $category->my->postingsHaveRatings = 'N';
        $this->assertEquals(utf8_encode('<category><attribute name="xtitle">events &amp; � classes</attribute><attribute name="postingsHaveDate">Y</attribute><attribute name="postingsHavePrice"></attribute><attribute name="postingsHaveLocation">Y</attribute><attribute name="postingsHaveAge">N</attribute><attribute name="postingsHaveComments">N</attribute><attribute name="postingsHaveMessaging">Y</attribute><attribute name="postingsHaveRatings">N</attribute></category>'), Category::serialize($category));        
        $deserializedCategory = Category::deserialize(simplexml_load_string(Category::serialize($category), FALSE));
        $this->assertEquals('string', gettype($deserializedCategory->my->xtitle));
        $this->assertEquals(utf8_encode('events & � classes'), $deserializedCategory->my->xtitle);
    }       
    
    public function testSerializeSubcategory() {
        $this->doTestSerializeSubcategory(XN_Content::create('Subcategory'));
        $localContentStore = new LCS_ContentStore();
        $this->doTestSerializeSubcategory($localContentStore->create('Subcategory'));
    }
    public function doTestSerializeSubcategory($subcategory) {
        $subcategory->my->xtitle = utf8_encode('karate & � stuff');
        $this->assertEquals(utf8_encode('<subcategory>karate &amp; � stuff</subcategory>'), Category::serializeSubcategory($subcategory));
        $deserializedSubcategory = Category::deserializeSubcategory(simplexml_load_string(Category::serializeSubcategory($subcategory), FALSE));
        $this->assertEquals('string', gettype($deserializedSubcategory->my->xtitle));
        $this->assertEquals(utf8_encode('karate & � stuff'), $deserializedSubcategory->my->xtitle);
    }
    
}

?>


