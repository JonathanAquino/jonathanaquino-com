<?php
require_once 'PHPUnit.php';
require_once 'models/Application.php';

class ApplicationTest extends PHPUnit_TestCase {        
    
    public function testSerializeColumns() {
        $this->assertEquals('<application><column></column><column></column><column></column><column></column></application>', 
                Application::serializeColumns(array(), array(), array(), array()));
    }

    public function testDeserializeColumns() {
        $columns = Application::deserializeColumns('<application><column></column><column><category><attribute name="xtitle">events &amp; classes</attribute><attribute name="postingsHaveDate">Y</attribute><attribute name="postingsHavePrice"></attribute><attribute name="postingsHaveLocation">Y</attribute><attribute name="postingsHaveAge">N</attribute><attribute name="postingsHaveComments">N</attribute><attribute name="postingsHaveMessaging">Y</attribute><attribute name="postingsHaveRatings">N</attribute></category></column></application>', false);        
        $this->assertEquals(2, count($columns));
        $this->assertEquals(0, count($columns[0]));
        $this->assertEquals(1, count($columns[1]));
        $category = $columns[1][0];        
        $this->assertEquals('events & classes', $category->my->xtitle);
        $this->assertEquals('Y', $category->my->postingsHaveDate);        
        $this->assertEquals('', $category->my->postingsHavePrice);
        $this->assertEquals('Y', $category->my->postingsHaveLocation);
        $this->assertEquals('N', $category->my->postingsHaveAge);
        $this->assertEquals('N', $category->my->postingsHaveComments);
        $this->assertEquals('Y', $category->my->postingsHaveMessaging);
        $this->assertEquals('N', $category->my->postingsHaveRatings);        
        $this->assertEquals('', $category->my->subcategoryIDs);        
    }    
    
}

?>


