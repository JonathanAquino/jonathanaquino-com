<?php
require_once 'PHPUnit.php';
require_once 'lib/LocalContentStore/LCS_Content.php';
require_once 'lib/LocalContentStore/LCS_ContentStore.php';
require_once 'helpers/AssertionHelper.php';

class LocalContentStoreForPersistenceTest extends LCS_ContentStore {
    public $persistCount = 0;
    public function persist() {  
        $this->persistCount++;
    }    
}

class LCSContentStoreTest extends PHPUnit_TestCase {        
        
    public function testPersist() {
        $localContentStore = new LocalContentStoreForPersistenceTest();
        $foo = $localContentStore->create('Foo');        
        $this->assertEquals(null, $foo->id);
        $this->assertEquals(0, $localContentStore->persistCount);
        $foo->save();
        $this->assertEquals('L1', $foo->id);
        $this->assertEquals(1, $localContentStore->persistCount);
    }    
    
    public function testPersistence() {
        $localContentStore = new LocalContentStoreForPersistenceTest();
        $foo = $localContentStore->create('Foo');        
        $this->assertEquals(0, $localContentStore->persistCount);
        $foo->save();
        $this->assertEquals(1, $localContentStore->persistCount);
        $foo->save();
        $this->assertEquals(2, $localContentStore->persistCount);
        $foo->save();
        $this->assertEquals(3, $localContentStore->persistCount);
        $localContentStore->persistenceEnabled = false;        
        $foo->save();
        $this->assertEquals(3, $localContentStore->persistCount);
        $foo->save();
        $this->assertEquals(3, $localContentStore->persistCount);
        $localContentStore->persistenceEnabled = true;
        $foo->save();
        $this->assertEquals(4, $localContentStore->persistCount);
        $foo->save();
        $this->assertEquals(5, $localContentStore->persistCount);
        $localContentStore->delete($foo);
        $this->assertEquals(6, $localContentStore->persistCount);
    }    

    public function testDelete() {
        $localContentStore = new LCS_ContentStore();
        $foo1 = $localContentStore->create('Foo');
        $foo1->save();
        $this->assertEquals('L1', $foo1->id);
        $foo2 = $localContentStore->create('Foo');
        $foo2->save();
        $this->assertEquals('L2', $foo2->id);
        $this->assertEquals(2, count($localContentStore->idToContentArray));
        $localContentStore->delete($foo1);
        $this->assertEquals('L2', $foo2->id);
        $this->assertEquals(1, count($localContentStore->idToContentArray));        
    }
    
    public function testDeleteByID() {
        $localContentStore = new LCS_ContentStore();
        $foo1 = $localContentStore->create('Foo');
        $foo1->save();
        $this->assertEquals('L1', $foo1->id);
        $foo2 = $localContentStore->create('Foo');
        $foo2->save();
        $this->assertEquals('L2', $foo2->id);
        $this->assertEquals(2, count($localContentStore->idToContentArray));
        $localContentStore->delete('L1');
        $this->assertEquals('L2', $foo2->id);
        $this->assertEquals(1, count($localContentStore->idToContentArray));        
    }
    
    public function testIDForForeignID() {
        $localContentStore = new LCS_ContentStore();
        $foo1 = $localContentStore->create('Foo');
        $foo1->save();
        $this->assertEquals('L1', $foo1->id);
        $foo2 = $localContentStore->create('Foo');
        $foo2->foreignID = '12345';
        $foo2->save();
        $this->assertEquals('L2', $foo2->id, 'a');
        $this->assertEquals('L2', $localContentStore->idForForeignID('12345'), 'b');
        try {
            $localContentStore->idForForeignID(12345);
            $this->assertTrue(false);
        } catch (AssertionFailedException $e) {
            $this->assertTrue(true);
        }    
        $this->assertEquals(null, $localContentStore->idForForeignID('99999'));
        try {
            $localContentStore->idForForeignID(null);
            $this->assertTrue(false);
        } catch (AssertionFailedException $e) {
            $this->assertTrue(true);
        }    
        
    }
    
}

?>


