<?php
require_once 'PHPUnit.php';
require_once 'helpers/CategoryHelper.php';

class CategoryHelperTest extends PHPUnit_TestCase {         
    public function testID() {
        $localContentStore = new LCS_ContentStore();
        $foo = $localContentStore->create('Foo');
        $foo->id = '456';        
        $this->assertEquals('123', IDHelper::id('123'));
        $this->assertEquals('123', IDHelper::id(123));
        $this->assertEquals('456', IDHelper::id($foo));
    }
    public function testContent() {
        $localContentStore = new LCS_ContentStore();
        $foo = $localContentStore->create('Foo');
        $foo->id = '456';        
        $foo->save();
        $this->assertEquals($foo, IDHelper::contentProper('456', $localContentStore), 'a');
        $this->assertEquals($foo, IDHelper::contentProper(456, $localContentStore), 'a');
        $this->assertEquals($foo, IDHelper::contentProper($foo, $localContentStore), 'b');
    }    
}

?>


