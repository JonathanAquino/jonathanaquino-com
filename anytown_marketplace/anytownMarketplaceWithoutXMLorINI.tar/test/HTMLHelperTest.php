<?php
require_once 'PHPUnit.php';
require_once 'helpers/HTMLHelper.php';

class HTMLHelperTest extends PHPUnit_TestCase {    
    
    public function testURLParametersWithout() {
        $this->assertEquals('', HTMLHelper::urlParametersWithout(array(), array()));
        $this->assertEquals('a=1&b=2&c=porsche+911', HTMLHelper::urlParametersWithout(array(), array('a' => '1', 'b' => '2', 'c' => 'porsche 911')));
        $this->assertEquals('a=1&c=porsche+911', HTMLHelper::urlParametersWithout(array('b'), array('a' => '1', 'b' => '2', 'c' => 'porsche 911')));
    }
    
    public function testLocation() {
        $application = XN_Content::create('Application');
        $application->my->city = null;
        $application->my->stateAbbreviation = null;
        $application->my->countryAbbreviation = null;
        $this->assertEquals(null, HTMLHelper::location($application, ''));
        $application->my->city = '';
        $application->my->stateAbbreviation = '';
        $application->my->countryAbbreviation = '';
        $this->assertEquals(null, HTMLHelper::location($application, ''));
        $application->my->city = 'Victoria';
        $application->my->stateAbbreviation = 'BC';
        $application->my->countryAbbreviation = 'CA';
        $this->assertEquals('Victoria, BC, Canada', HTMLHelper::location($application, ''));
        $application->my->city = '';
        $application->my->stateAbbreviation = '';
        $application->my->countryAbbreviation = 'CN';
        $this->assertEquals('China', HTMLHelper::location($application, ''));
        $application->my->city = 'Houston';
        $application->my->stateAbbreviation = 'TX';
        $application->my->countryAbbreviation = 'US';
        $this->assertEquals('Houston, TX', HTMLHelper::location($application, ''));
        $application->my->city = 'New York';
        $application->my->stateAbbreviation = '';
        $application->my->countryAbbreviation = '';
        $this->assertEquals('New York', HTMLHelper::location($application, ''));
        $application->my->city = '';
        $application->my->stateAbbreviation = 'Alberta';
        $application->my->countryAbbreviation = '';
        $this->assertEquals('Alberta', HTMLHelper::location($application, ''));
        $application->my->city = '';
        $application->my->stateAbbreviation = 'Alberta';
        $application->my->countryAbbreviation = '';
        $this->assertEquals('Metz, Moselle, France', HTMLHelper::location($application, 'metzannonce'));        
    }
    
    public function testExtractNumber() {
        $this->assertEquals(null, HTMLHelper::extractNumber(null));
        $this->assertEquals(null, HTMLHelper::extractNumber('  '));
        $this->assertEquals(null, HTMLHelper::extractNumber('ABC'));
        $this->assertEquals(5, HTMLHelper::extractNumber('  5  '));
        $this->assertEquals(5, HTMLHelper::extractNumber('_5_'));
        $this->assertEquals(5.4, HTMLHelper::extractNumber('_5.4_'));
        $this->assertEquals(null, HTMLHelper::extractNumber('_5.4.3_'));
        $this->assertEquals(1234.56, HTMLHelper::extractNumber('$1,234.56'));
    }         
    
    public function testRemoveEvilTags() {
        $this->assertEquals('<a href="forbiddenalert(1);" target="_blank" forbidden = "alert(1)">test</a>', HTMLHelper::removeEvilTags('<a href="javascript:alert(1);" target="_blank" onMouseOver = "alert(1)">test</a>'));
    }
    
}

?>



