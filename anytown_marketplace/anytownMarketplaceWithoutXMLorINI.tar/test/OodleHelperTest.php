<?php
require_once 'PHPUnit.php';
require_once 'helpers/OodleHelper.php';
require_once 'helpers/CategoryHelper.php';
require_once 'lib/LocalContentStore/LCS_Content.php';

class OodleHelperTest extends PHPUnit_TestCase {    
    
    public function testFilledInMetroArea() {
        $application = XN_Content::create('Application');
        $application->my->city = 'Ottawa';
        $application->my->stateAbbreviation = 'ON';
        $application->my->countryAbbreviation = 'CA';
        $this->assertEquals('Ottawa, ON, CA', OodleHelper::metroAreaProper($application, ''));
    }
    
    public function testBlankMetroArea() {
        $application = XN_Content::create('Application');
        $application->my->city = '';
        $application->my->stateAbbreviation = '';
        $application->my->countryAbbreviation = '';
        $this->assertEquals(', , ', OodleHelper::metroAreaProper($application, ''));
    }
    
    public function testNullMetroArea() {
        $application = XN_Content::create('Application');
        $this->assertEquals(', , ', OodleHelper::metroAreaProper($application, ''));
    }

    public function testPredefinedMetroArea() {
        $application = XN_Content::create('Application');
        $application->my->city = 'Ottawa';
        $application->my->stateAbbreviation = 'ON';
        $application->my->countryAbbreviation = 'CA';      
        $this->assertEquals('Los Angeles, CA, US', OodleHelper::metroAreaProper($application, 'losangeles'));
    }    
    
    public function testPredefinedMetroArea2() {
        $application = XN_Content::create('Application');     
        $this->assertEquals('Los Angeles, CA, US', OodleHelper::metroAreaProper($application, 'losangeles'));
    }   
    
    public function testOrangeCountyMetroArea() {
        $application = XN_Content::create('Application');
        // Scott Kister pointed out that Orange County is not a city, and recommended
        // that we use Anaheim for the city. [Jon Aquino 2005-11-18]
        $this->assertEquals('Anaheim, CA, US', OodleHelper::metroAreaProper($application, 'orangecounty'));
    }           
    
    public function testXMLForApplicationProper() {
        $expected = trim(preg_replace("/\r/", '', '
<?xml version="1.0" encoding="utf-8"?>
<listing_feed>
  <feed_generated_time>123456</feed_generated_time>
  <listings>
  </listings>
</listing_feed>'));
        $actual = trim(preg_replace("/\r/", '', OodleHelper::xmlForApplicationProper(array(), array(), 123456, null)));
        //var_dump($expected);
        //var_dump($actual);
        $this->assertEquals($expected, $actual);
    }
    
    public function testXMLForPostingProper() {
        $this->doTestXMLForPostingProper(true, false);
        $this->doTestXMLForPostingProper(false, true);
    }
    
    public function doTestXMLForPostingProper($subcategoryExists, $dateExists) {
        $posting = XN_Content::create('Posting');
        $posting->my->xtitle = 'The Dark Knight Returns';
        $posting->my->xdescription = "Frank Miller's magnum opus.
    
I love this comic, but I've read it enough times and want someone else to enjoy it.";
        $category = XN_Content::create('Category');
        $category->my->xtitle = 'North America';
        if ($subcategoryExists) {
            $subcategory = XN_Content::create('Subcategory');
            $subcategory->my->xtitle = 'Superheroes & Supervillains';
        }        
        $expected = trim(preg_replace("/\r/", '', "
<listing>
    <id></id>
    <url>http://comics.ning.com/index.php?controller=posting&amp;action=show&amp;categoryID=&amp;subcategoryID=&amp;id=</url>
    <category>North America" . ($subcategoryExists ? '/Superheroes &amp; Supervillains' : '') . "</category>
    <title>The Dark Knight Returns</title>"
    . (!$dateExists ? "" : "
    <event_date>1977-02-15T00:00:00Z</event_date>")
    . "
    <description>Frank Miller's magnum opus.
    
I love this comic, but I've read it enough times and want someone else to enjoy it.</description>
    <metro_area>Knoxville, TN, US</metro_area>
    <create_time>2004-09-16T14:00:00-07:00</create_time>
</listing>
"));
        $actual = trim(preg_replace("/\r/", '', OodleHelper::xmlForPostingProper($posting, 'comics', '2004-09-16T14:00:00-07:00', 'Knoxville, TN, US', $category, $subcategory, $dateExists ? '1977-02-15T00:00:00Z' : null)));
        //var_dump($expected);
        //var_dump($actual);
        $this->assertEquals($expected, $actual);
    }          
    
    public function testURL1() {
        $category = new LCS_Content('Category');
        $category->id = 1;
        $posting = new LCS_Content('Posting');
        $posting->id = 2;        
        $this->assertEquals('http://foo.ning.com/index.php?controller=posting&action=show&categoryID=1&subcategoryID=&id=2', OodleHelper::url('foo', $category, $subcategory, $posting));
    }
    
    public function testURL2() {
        $category = new LCS_Content('Category');
        $category->id = 1;
        $subcategory = new LCS_Content('Subcategory');
        $subcategory->id = 2;        
        $posting = new LCS_Content('Posting');
        $posting->id = 3;        
        $this->assertEquals('http://foo.ning.com/index.php?controller=posting&action=show&categoryID=1&subcategoryID=2&id=3', OodleHelper::url('foo', $category, $subcategory, $posting));
    }

    public function testURL3() {
        $category = new LCS_Content('Category');
        $category->id = 1;
        $category->my->localID = 'L1';
        $subcategory = new LCS_Content('Subcategory');
        $subcategory->id = 2;     
        $posting = new LCS_Content('Posting');
        $posting->id = 3;        
        $this->assertEquals('http://foo.ning.com/index.php?controller=posting&action=show&categoryID=L1&subcategoryID=2&id=3', OodleHelper::url('foo', $category, $subcategory, $posting));
    }

    public function testURL4() {
        $category = new LCS_Content('Category');
        $category->id = 1;
        $subcategory = new LCS_Content('Subcategory');
        $subcategory->id = 2;
        $subcategory->my->localID = 'L2';        
        $posting = new LCS_Content('Posting');
        $posting->id = 3;        
        $this->assertEquals('http://foo.ning.com/index.php?controller=posting&action=show&categoryID=1&subcategoryID=L2&id=3', OodleHelper::url('foo', $category, $subcategory, $posting));
    }    
    
}

?>


