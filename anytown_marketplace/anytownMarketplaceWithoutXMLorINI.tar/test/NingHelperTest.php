<?php
require_once 'PHPUnit.php';
require_once 'helpers/NingHelper.php';

class NingHelperTest extends PHPUnit_TestCase {            
    
    public function testExecuteQueryWithoutLimitForLargeQuery() {
        $query = XN_Query::create('Content');
        // The number of results returned can be slightly less than what
        // one expects. See issue NING-950 [Jon Aquino 2005-11-09]
        $count = count(NingHelper::executeQueryWithoutLimit($query, 247));
        $this->assertTrue(abs(247 - $count) < 10);            
    }
    
    public function testExecuteQueryWithoutLimitForSmallQuery() {
        $query = XN_Query::create('Content');
        $query->filter('type', '=', 'Application');
        $query->filter('owner', '=');
        // Filter out spurious anonymous objects -- workaround
        // for issue NING-935 [Jon Aquino 2005-11-08]                    
        $query->filter('contributor', '<>', null);
        // The number of results returned can be slightly less than what
        // one expects. See issue NING-950 [Jon Aquino 2005-11-09]
        $count = count(NingHelper::executeQueryWithoutLimit($query, 247));
        $this->assertEquals(1, $count);            
    }    
    
    public function testAppConfiguredProper() {
        $data = '[config]
_configured=AMwithMaps
reviewsOnFrontPage=6
postingsPerPage=100
tagsOnTopTagsPage=50
city=
stateAbbreviation=
countryAbbreviation=
googleMapsAPIKey="ABQIAAAANFYJyitS5RtvrTlhw3O3hhTVxIk0iyITFr5AK1ibjKVu-JEEdhTXQHsHzHGaSLp2r1RzA7adLxl5Sg"
frontPageMapInitialExtentURL=http://maps.google.com/maps?q=palo+alto&ll=37.439701,-122.145309&spn=0.124304,0.328766&hl=en';
        // Doesn't always work the first time [Jon Aquino 2005-11-20]
        file_put_contents('xn_private/testAppConfiguredProper.txt', $data);
        file_put_contents('xn_private/testAppConfiguredProper.txt', $data);
        file_put_contents('xn_private/testAppConfiguredProper.txt', $data);
        $this->assertTrue(NingHelper::appConfiguredProper('xn_private/testAppConfiguredProper.txt', 'AMwithMaps'));
        $this->assertFalse(NingHelper::appConfiguredProper('xn_private/testAppConfiguredProper.txt', 'amwithmaps'));
        $this->assertFalse(NingHelper::appConfiguredProper('xn_private/testAppConfiguredProper.txt', 'FOO'));
    }
    
}

?>


