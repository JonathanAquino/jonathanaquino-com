<?php

class Comment {

    /**
     * @var XN_Attribute::STRING
     * @rule length ,4000
     */    
    public $xdescription;
    // Use "xdescription" while we are waiting for W_Content to properly handle "description" [Jon Aquino 2005-10-27]
    // Also waiting for the core to handle "my->title" -- see NING-921 [Jon Aquino 2005-11-02]

    /**
     * @var XN_Attribute::NUMBER optional
     * @rule range 1,5
     */
    public $rating;           
}

?>
