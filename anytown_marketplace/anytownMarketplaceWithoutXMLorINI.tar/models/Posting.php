<?php

require_once 'models/Comment.php';
require_once 'helpers/CategoryHelper.php';

class Posting {

    /**
     * @var XN_Attribute::STRING
     * @rule length ,100
     */    
    public $xtitle;
    // Use "xtitle" while we are waiting for W_Content to properly handle "title" [Jon Aquino 2005-10-25]
    // Also waiting for the core to handle "my->title" -- see NING-921 [Jon Aquino 2005-11-02]
    
    /**
     * @var XN_Attribute::STRING
     * @rule length ,4000
     */    
    public $xdescription;
    // Use "xdescription" while we are waiting for W_Content to properly handle "description" [Jon Aquino 2005-10-25]
    // Also waiting for the core to handle "my->title" -- see NING-921 [Jon Aquino 2005-11-02]    

    /**
     * @var XN_Attribute::STRING optional
     * @rule length ,100
     */    
    public $location;    
    
    /**
     * @var XN_Attribute::NUMBER optional
     * @rule range(is not valid) 1,150
     */
    public $age;     
    
    /**
     * @var XN_Attribute::STRING optional
     * @rule length ,100     
     */
    public $price;     
    
   /**
     * @var XN_Attribute::STRING optional
     */
    public $date; 
    // Use a STRING instead of a DATE because there currently isn't a way to filter
    // a query by a date attribute [Jon Aquino 2005-10-27]
    
    /**
     * @var XN_Attribute::NUMBER optional
     * @rule range 1,5
     */
    public $rating;        
    
    /**
     * @var XN_Attribute::STRING
     * @rule regex /^[YN]$/
     */
    public $displayingUsername;
    
    /**
     * @var XN_Attribute::STRING
     * @rule regex /^[YN]$/
     */
    public $allowingMessaging;    

    public static function updateStatistics($posting) {
        if ($posting instanceof XN_Content) { $posting = new W_Content($posting); }
        $comments = self::comments($posting);     
        $posting->my->set('commentCount', count($comments), XN_Attribute::NUMBER);
        $posting->my->searchableText = self::searchableText($posting, $comments);
        $posting->my->set('searchablePrice', HTMLHelper::extractNumber($posting->my->price), XN_Attribute::NUMBER);
        if (CategoryHelper::content($posting, 'category')->my->postingsHaveRatings == 'Y') {         
            $posting->my->set('averageRating', self::averageRating($posting, $comments), XN_Attribute::NUMBER);
        }
    }
    
    private static function searchableText($posting, $comments) {
        $searchableText = self::searchableTextProper($posting) . ' ';
        foreach ($comments as $comment) {
            $searchableText .= self::searchableTextProper($comment) . ' ';
        }                
        return $searchableText;
    }
    
    private static function searchableTextProper($w_content) {
        $searchableText = $w_content->title . ' ' . $w_content->description . ' ';
        if (! $w_content->isPrivate) {
            $searchableText .= $w_content->contributorName . ' ';
        }        
        foreach ($w_content->export() as $key => $value) {
            $searchableText .= $value . ' ';
        }
        return strtolower($searchableText); 
    }
    
    public static function averageRating($posting, $comments) {
        $objects = PHPHelper::concatenate(array(array($posting), $comments));
        $numberOfObjectsWithRatings = 0;
        $sumOfRatings = 0;
        foreach ($objects as $object) {
            if ($object->my->rating) {
                $numberOfObjectsWithRatings++;
                $sumOfRatings += $object->my->rating;
            }
        }
        // There will be 0 ratings if the user has turned on ratings for a category with
        // existing postings. This is rare, so just return something reasonable [Jon Aquino 200]
        if ($numberOfObjectsWithRatings == 0) { return 3; }   
        return round($sumOfRatings/$numberOfObjectsWithRatings);
    }        
    
    public static function comments($posting) {
        if (! $posting->id) { return array(); }
        $comments = XN_Query::create('Content')
            ->filter('type', 'eic', 'Comment')
            ->filter('owner', '=') 
            ->filter('my->posting', '=', $posting->id) 
            ->order('createdDate', 'asc') 
            ->execute();
        $wrappedComments = array();
        foreach ($comments as $comment) {
            $wrappedComments[] = new W_Content($comment);
        }
        return $wrappedComments;
    }
    
}

?>
