<?php DragDropHelper::initialize(array('subcategoryList')); ?>

<div id="main">

    <?php HTMLHelper::displayErrors($errors); ?>
    <h2>Add A New Category</h2>    
    <form id="form" name="form" method="POST" action="index.php?controller=category&amp;action=create&amp;column=<?php echo $_GET['column'] ?>">
        <dl>  
            <?php 
            include '_form.php' ?>                
            <dt><?php echo $form->submit(null, 'Add This Category', 'class="button" onclick="extractSubcategoryIDs()"') ?></dt>  
        </dl>
    </form>
    
    <script type="text/javascript">
        document.form.xtitle.focus();
    </script>

</div>


