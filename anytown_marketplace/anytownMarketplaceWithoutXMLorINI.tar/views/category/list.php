<?php DragDropHelper::initialize(array('column1CategoryList', 'column2CategoryList', 'column3CategoryList', 'column4CategoryList')); ?>

<script language="JavaScript" type="text/javascript">
    var savingLayout = false;
    function saveLayout() {
        savingLayout = true;
        extractCategoryIDs();
    }
    function extractCategoryIDs() {
        document.getElementById('column1CategoryIDs').value = extractNonNullAttributeValues('column1CategoryList', 'categoryID', ' ');
        document.getElementById('column2CategoryIDs').value = extractNonNullAttributeValues('column2CategoryList', 'categoryID', ' ');
        document.getElementById('column3CategoryIDs').value = extractNonNullAttributeValues('column3CategoryList', 'categoryID', ' ');
        document.getElementById('column4CategoryIDs').value = extractNonNullAttributeValues('column4CategoryList', 'categoryID', ' ');
    }
</script>    

<?php
if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserIsAppOwner())) { ?>
    <div id="headerMessage" style="font-size:small">
        <form action="index.php?controller=category&amp;action=saveLayout" method="post">        
            <input type="hidden" name="column1CategoryIDs" id="column1CategoryIDs" value="" />
            <input type="hidden" name="column2CategoryIDs" id="column2CategoryIDs" value="" />
            <input type="hidden" name="column3CategoryIDs" id="column3CategoryIDs" value="" />
            <input type="hidden" name="column4CategoryIDs" id="column4CategoryIDs" value="" />
            As the app owner, you can rearrange the categories by dragging them to new locations then pressing
            <input type="submit" onclick="saveLayout()" value="Save Layout" class="button" />
        </form>    
    </div>    
<?php
} ?>

<div id="column1">
    <div id="boxSearch">     
        <h3>Search for</h3>
        <form action="index.php" method="get" name="form" id="search" >
            <input type="hidden" name="controller" value="posting">
            <input type="hidden" name="action" value="list">        
            <dl>
                <dd><input name="query" type="text" class="input-search" value="<?php echo htmlentities($_GET['query'], ENT_QUOTES, 'UTF-8'); ?>" /></dd>
                <dd>
                    in 
                    <select name="categoryID">
                        <option value="">all categories</option>            
                        <?php                        
                        foreach ($categoriesSortedByName as $category) { ?>
                            <option value="<?php echo $category->id ?>"><?php echo $category->my->h('xtitle') ?></option>
                        <?php
                        } ?>
                    </select>
                </dd>
                <dd><input value="Search" class="button" type="submit" /></dd>            
            </dl>
        </form>
        <script type="text/javascript">
            document.form.query.focus();
        </script>            
    </div>    
    <?php
    $column = 1;
    include '_columnList.php'; ?>        
    <div id="recentReviews">
    <h3><a href="<?php echo $reviewsURL = 'index.php?controller=posting&amp;action=list&amp;postingsWithRatingsOnly=yes&amp;lastBreadcrumb=Recent+Reviews' ?>">Recent Reviews</a></h3>
        <ul>
            <?php
            foreach ($recentReviews as $posting) { ?>
                <li>
                    <a href="index.php?controller=posting&amp;action=show&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>">
                        <?php echo $posting->my->h('xtitle') ?>
                    </a>
                    in <?php echo HTMLHelper::categorySubcategoryLink($posting, true, true) ?>
                    <span><img src="images/stars<?php echo $posting->my->averageRating ?>.gif" /></span>                    
                </li> 
            <?php
            } ?>            
            <p class="seeMore"><a href="<?php echo $reviewsURL ?>">&raquo; More reviews</a></p>                
        </ul>
    </div>    
    <div id="recentReviews">
    <h3><a href="<?php echo $otherCitiesURL = 'index.php?controller=application&amp;action=list' ?>">Other Cities</a></h3>
        <ul>
            <?php
            foreach ($applications as $application) { ?>
                <li>
                    <a href="http://<?php echo htmlentities($application->owner->relativeUrl, ENT_QUOTES, 'UTF-8') ?>.ning.com"><?php echo htmlentities($application->owner->name, ENT_QUOTES, 'UTF-8') ?></a> 
                    <?php if ($location = HTMLHelper::location($application, $application->owner->relativeUrl)) { echo '(' . $location . ')'; } ?>                    
                </li> 
            <?php
            } ?>            
            <p class="seeMore"><a href="<?php echo $otherCitiesURL ?>">&raquo; More cities</a></p>                
        </ul>
    </div>      
    <table width="100%">
        <tr>
            <td>
                <p><a href="index.php?controller=posting&amp;action=list&amp;view=rss&amp;xn_auth=no">RSS</a></p>            
            </td>
        </tr>
    </table>    
</div>

<?php
if (Config::$googleMapsAPIKey && Config::$frontPageMapInitialExtentURL) { ?>
    <div id="mapContainer">
        <?php
        require_once 'helpers/GoogleMapsHelper.php';
        GoogleMapsHelper::instance()->displayMapForArray($recentGeocodedPostings, '95%', '300px', Config::$frontPageMapInitialExtentURL); ?>
    </div>
<?php
} ?>

<div id="column2">
    <?php
    $column = 2;
    include '_columnList.php'; ?>      
</div>

<div id="column3">
    <?php
    $column = 3;
    include '_columnList.php'; ?>      
</div>

<div id="column4">
    <?php
    $column = 4;
    include '_columnList.php'; ?>      
</div>

<?php
if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserIsAppOwner())) { ?>

    <script language="JavaScript" type="text/javascript">    
        function categoryOrder() {
            var categoryOrder = ''; 
            categoryOrder += extractNonNullAttributeValues('column1CategoryList', 'categoryID', ' ') + ' \n';
            categoryOrder += extractNonNullAttributeValues('column2CategoryList', 'categoryID', ' ') + ' \n';
            categoryOrder += extractNonNullAttributeValues('column3CategoryList', 'categoryID', ' ') + ' \n';
            categoryOrder += extractNonNullAttributeValues('column4CategoryList', 'categoryID', ' ');
            return categoryOrder;
        }            
        var originalCategoryOrder = categoryOrder();
        // onbeforeunload doesn't work on older browsers, but that's OK as this is just precautionary.
        // See http://www.sitepoint.com/forums/showpost.php?p=1976587&postcount=5        
        // [Jon Aquino 2005-11-04]
        window.onbeforeunload = function() {            
            if (! savingLayout && categoryOrder() != originalCategoryOrder) { return 'The changes you made to the layout have not been saved.' }
        }
    </script>       

<?php
} ?>



