<ul id="column<?php echo $column ?>CategoryList" class="sortable">
    <?php 
    foreach (${'column' . $column . 'Categories'} as $category) { ?>
        <li categoryID="<?php echo $category->id ?>">
            <div class="box">          
                <h3><?php echo HTMLHelper::categoryLink($category, true) ?></h3>    
                <?php
                if ($category->my->postingsHaveDate == 'Y') { 
                    DateHelper::displayCalendar($category);
                } ?>                
                <ul>
                    <?php
                    foreach (Category::subcategories($category) as $subcategory) { ?>                
                        <li><?php echo HTMLHelper::subcategoryLink($category, $subcategory) ?></li>
                    <?php
                    } ?>            
                </ul>
                <?php
                if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserIsAppOwner())) { ?>
                    <p class="actions">
                        <a href="index.php?controller=category&amp;action=edit&amp;id=<?php echo $category->id ?>">edit</a> |
                        <?php
                        // Workaround for IE bug: &#039; causes an "Expected ')'" JavaScript error in IE. So remove it from the confirmation message. [Jon Aquino 2005-11-02] 
                        ?>
                        <a href="index.php?controller=category&amp;action=delete&amp;id=<?php echo $category->id ?>" onclick="javascript:return confirm('Are you sure you want to delete <?php echo str_replace('&#039;', '', $category->my->h('xtitle')); ?> and its subcategories and postings?')">delete</a> 
                    </p>   
                <?php
                } ?>                        
            </div>
        </li>
    <?php
    } ?>            
    <?php
    if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserIsAppOwner())) { 
        // Placeholder to make it easier to drop a category into an empty column [Jon Aquino 2005-11-01] 
        ?>       
        <li><div class="columnPlaceholder">&nbsp;</div></li>
    <?php
    } ?>
</ul>
<?php
if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserIsAppOwner())) { ?>
    <div class="actions"><a href="index.php?controller=category&amp;action=new&amp;column=<?php echo $column ?>">add category</a></div>
<?php
} ?>    
