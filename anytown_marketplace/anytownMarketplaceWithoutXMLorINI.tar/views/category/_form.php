<script language="JavaScript" type="text/javascript">
    function trim(str) {
        return str.replace(/^\s*|\s*$/g,'');
    }
    var lastSubcategoryListItemID = 0;
    function deleteSubcategory(subcategoryListItemID) {
        var list = document.getElementById('subcategoryList');
        var item = document.getElementById(subcategoryListItemID);
        list.removeChild(item);
    }
    function subcategoryListItemHTML(subcategoryListItemID, subcategoryID, subcategoryName) {
        return subcategoryName + ' <span class="editDelete"><a href="javascript:editSubcategory(\'' + subcategoryListItemID + '\')">Edit</a> | <a href="javascript:deleteSubcategory(\'' + subcategoryListItemID + '\')">Delete</a></span>';
    }
    function addSubcategory() {
        var subcategoryName = clean(prompt('What would you like to call the new subcategory?', ''));
        if (subcategoryName == null) { return; }
        addSubcategoryProper('new', subcategoryName);
    }
    function addSubcategoryProper(subcategoryID, subcategoryName) {
        var list = document.getElementById('subcategoryList');
        var item = document.createElement('li');
        lastSubcategoryListItemID++;
        item.setAttribute('id', 'subcategoryListItem' + lastSubcategoryListItemID);
        item.setAttribute('subcategoryID', subcategoryID);
        item.setAttribute('subcategoryName', subcategoryName);
        item.setAttribute('subcategoryIDAndName', subcategoryIDAndName(item.getAttribute('subcategoryID'), subcategoryName));
        item.innerHTML = subcategoryListItemHTML(item.getAttribute('id'), item.getAttribute('subcategoryID'), subcategoryName);        
        list.appendChild(item);     
        DragDrop.makeItemDragable(item);
    }    
    function editSubcategory(subcategoryListItemID) {
        var item = document.getElementById(subcategoryListItemID);        
        var subcategoryName = clean(prompt('What would you like to rename this subcategory to?', item.getAttribute('subcategoryName')));
        if (subcategoryName == null) { return; }
        var list = document.getElementById('subcategoryList');
        item.setAttribute('subcategoryName', subcategoryName);
        item.setAttribute('subcategoryIDAndName', subcategoryIDAndName(item.getAttribute('subcategoryID'), subcategoryName));
        item.innerHTML = subcategoryListItemHTML(item.getAttribute('id'), item.getAttribute('subcategoryID'), subcategoryName);  
    }
    function clean(subcategoryName) {
        if (subcategoryName == null) { return null; }
        subcategoryName = trim(subcategoryName);
        if (subcategoryName == '') { return null; }
        // Remove ^ as we use this for a delimiter [Jon Aquino 2005-11-02]
        // Replace " with ' to prevent problems in addSubcategoryProper(..., "...") later [Jon Aquino 2005-11-02]
        return subcategoryName.replace(/\^/g, '').replace(/"/g, "'");        
    }
    function subcategoryIDAndName(subcategoryID, subcategoryName) {        
        return subcategoryID + '^' + subcategoryName;
    }    
    function extractSubcategoryIDs() {
        document.getElementById('subcategoryIDsAndNames').value = extractNonNullAttributeValues('subcategoryList', 'subcategoryIDAndName', '^');
    }    
</script>

<dt><label for="xtitle">Category Name:</label> <small>(examples: community, personals, discussion forums)</small></dt>  
<dd><?php echo $form->text('xtitle') ?></dd>
<dt>When someone posts to this category, they will be asked to specify:</dt>          
<dd><?php echo $form->checkbox('postingsHaveLocation', 'Y') ?> <label for="postingsHaveLocation">location/area</label></dd>
<dd><?php echo $form->checkbox('postingsHavePrice', 'Y') ?> <label for="postingsHavePrice">$</label></dd>
<dd><?php echo $form->checkbox('postingsHaveDate', 'Y') ?> <label for="postingsHaveDate">date</label></dd>
<dd><?php echo $form->checkbox('postingsHaveAge', 'Y') ?> <label for="postingsHaveAge">age</label></dd>
<dt>Other options: <small>(Typically you'd pick one)</small></dt>
<dd><?php echo $form->checkbox('postingsHaveComments', 'Y') ?> <label for="postingsHaveComments">people can add comments to each other's posts</label></dd>
<dd><?php echo $form->checkbox('postingsHaveRatings', 'Y') ?> <label for="postingsHaveRatings">people can add <img class="plain-image" src="images/stars5.gif"/> ratings</label> to each other's posts</dd>
<dd><?php echo $form->checkbox('postingsHaveMessaging', 'Y') ?> <label for="postingsHaveMessaging">people can send messages to the poster</label></dd>
<dt>Subcategories: <small>(You can change the order by dragging subcategories around)</small></dt>
<dd>
    <ul id="subcategoryList" class="sortable"></ul>
    <a href="javascript:addSubcategory()">Add a subcategory</a>
</dd>
<input type="hidden" name="subcategoryIDsAndNames" id="subcategoryIDsAndNames" value="" />

<script language="JavaScript" type="text/javascript">
    <?php
    foreach (Category::subcategories($category) as $subcategory) { 
        // Use raw() rather than h() because we are inside the <script> tags. Otherwise ' will be converted to &#039; [Jon Aquino 2005-11-02]
        // Put quotes around the subcategory ID, because it will likely start with L 
        // (indicating it is a local content store ID, not a real content store ID).
        // [Jon Aquino 2005-11-18]
        ?>
        addSubcategoryProper('<?php echo $subcategory->id ?>', "<?php echo $subcategory->my->raw('xtitle') ?>");
    <?php
    } ?>
</script>        
