<div id="main">
    <?php HTMLHelper::displayErrors($errors); ?>
    <h2>Add A Map To Your Posting</h2>    
    <form id="form" name="form" method="POST" action="index.php?controller=posting&amp;action=createMap&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>">    
        <dl>
            <?php include '_mapForm.php' ?>
            <dd><?php echo $form->submit(null, 'Add Map', 'class="button"') ?></dd>
        </dl>
    </form>                        
</div><!-- end #main -->

<script type="text/javascript">
    document.form.address.focus();
</script>
