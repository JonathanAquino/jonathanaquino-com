<div id="main">
    <h2>Post to which category?</h2>
        <ul class="categories">
            <?php
            foreach ($categories as $category) { ?>
                <li><a href="index.php?controller=posting&amp;action=new&amp;categoryID=<?php echo $category->id; ?>"><?php echo $category->my->h('xtitle'); ?></a></li>
            <?php
            } ?>        
        </ul>
</div><!-- end #main -->

