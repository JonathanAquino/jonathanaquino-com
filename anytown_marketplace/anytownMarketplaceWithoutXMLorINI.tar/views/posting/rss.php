<?php
XN_Application::includeFile('alphacomponents','/Alpha/Format/RSS.php');
$feed = new XNC_Alpha_Format_RSS();
$feed->version('0.91');
$feed->title(NingHelper::application()->name);
$feed->link('http://' . NingHelper::application()->relativeUrl . '.ning.com/index.php?' . HTMLHelper::urlParametersWithout(array('xn_auth', 'view')));
// pubDate and lastBuild date are required by some aggregators, like Bloglines.
// See http://jonaquino.blogspot.com/2005/02/rolling-your-own-rss-feed-be-sure-to.html
// [Jon Aquino 2005-11-09]
$feed->pubDate(date('r'));
$feed->lastBuildDate(date('r'));
// Workaround for error that occurs when there are no feed items. See NING-964 [Jon Aquino 2005-11-19]
if (count($postings) == 0) {
    $item = $feed->createItem();
    $feed->items[] = $item;    
}
foreach ($postings as $posting) { 
    $item = $feed->createItem();
    $item->title(self::formattedTitleRaw($posting));
    $item->link('http://' . NingHelper::application()->relativeUrl . '.ning.com/index.php?controller=posting&action=show&categoryID=' . CategoryHelper::contentId($posting, 'category') . '&subcategoryID=' . CategoryHelper::contentId($posting, 'subcategory') . '&id=' . $posting->id);
    $item->description(HTMLHelper::removeEvilTags(nl2br($posting->my->xdescription)));
    $item->pubDate($posting->createdDate);
    $feed->items[] = $item;
} 
header("Content-Type: text/xml");
echo $feed->toXML();
?>

