<div id="main">
    <?php HTMLHelper::displayErrors($errors); ?>
    <h2>Post to <span><?php echo $category->my->h('xtitle'); ?></span> </h2>    
    <!--
    enctype must be multipart/form-data for images. 
    See http://developerdocumentation.ning.com/post.php?Post:slug=XNC_Image%3A%3AbuildFormField
    [Jon Aquino 2005-09-12]
    -->
    <form id="form" name="form" method="POST" enctype="multipart/form-data" action="index.php?controller=posting&amp;action=create&amp;categoryID=<?php echo $category->id; ?>">   
        <dl>  
            <dd><small>(Want to post to a <a href="index.php?controller=posting&amp;action=selectCategory">different category</a>?)</small></dd>
            <?php 
            include '_form.php' ?>        
            <dt><?php echo $form->submit(null, 'Post', 'class="button"') ?></dt>  
        </dl>
    </form>
</div><!-- end #main -->

<script type="text/javascript">
    document.form.xtitle.focus();
</script>
