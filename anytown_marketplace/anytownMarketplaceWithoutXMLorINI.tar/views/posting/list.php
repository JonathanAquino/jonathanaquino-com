<div id="main"> 
    <?php HTMLHelper::displayBreadcrumbs($category, $subcategory, null, strlen($_GET['query']) > 0); ?>
    <div id="searchCategory">
        <form action="index.php" method="get" id="search" name="form">
        <input type="hidden" name="controller" value="posting">
        <input type="hidden" name="action" value="list">
        <input type="hidden" name="categoryID" value="<?php echo $category->id ?>">            
            <dl>
                <dd>keywords: <input name="query" type="text" class="input-search" value="<?php echo htmlentities($_GET['query'], ENT_QUOTES, 'UTF-8'); ?>" /> 
                    <?php
                    // Show the combobox even if there are no subcategories, so the user can tell that they are searching
                    // one category, not all categories. [Jon Aquino 2005-11-02]
                    if ($category) { ?>
                        in
                        <select name="subcategoryID">
                            <option value="">All <?php echo $category->my->h('xtitle') ?></option>            
                            <?php
                            // Call it $subcategoryForCombobox rather than $subcategory, as we check if $subcategory
                            // exists below [Jon Aquino 2005-10-31]
                            foreach (Category::subcategories($category) as $subcategoryForCombobox) { ?>
                                <option value="<?php echo $subcategoryForCombobox->id ?>" <?php if ($_GET['subcategoryID'] == $subcategoryForCombobox->id) { echo 'selected="selected"'; } ?>><?php echo $subcategoryForCombobox->my->h('xtitle') ?></option>
                            <?php
                            } ?>
                        </select>	    
                    <?php
                    } 
                    $secondLine = false; ?>
                    <?php
                    if ($category->my->postingsHavePrice == 'Y') {
                        echo $secondLine ? '<span style="margin-left:10px;"/>' : '<br /> ';
                        $secondLine = true; ?>                        
                        $ 
                        <input type="text" name="minPrice" value="<?php echo $_GET['minPrice'] ? htmlentities($_GET['minPrice'], ENT_QUOTES, 'UTF-8') : 'min'; ?>" size="5" onfocus="if ( value == 'min' ) { value = ''; }" onblur="if ( value == '' ) { value = 'min'; }"/>
                        to
                        <input type="text" name="maxPrice" value="<?php echo $_GET['maxPrice'] ? htmlentities($_GET['maxPrice'], ENT_QUOTES, 'UTF-8') : 'max'; ?>" size="5" onfocus="if ( value == 'max' ) { value = ''; }" onblur="if ( value == '' ) { value = 'max'; }"/>                            
                    <?php
                    } ?>        
                    <?php
                    if ($category->my->postingsHaveRatings == 'Y') { 
                        echo $secondLine ? '<span style="margin-left:10px;"/>' : '<br /> ';
                        $secondLine = true; ?>              
                        rating:
                        <select name="minRating">
                            <option value=""></option>                        
                            <option value="5" <?php if ($_GET['minRating'] == '5') { echo 'selected="selected"'; } ?>>5 stars</option>
                            <option value="4" <?php if ($_GET['minRating'] == '4') { echo 'selected="selected"'; } ?>>4 stars</option>
                            <option value="3" <?php if ($_GET['minRating'] == '3') { echo 'selected="selected"'; } ?>>3 stars</option>                
                            <option value="2" <?php if ($_GET['minRating'] == '2') { echo 'selected="selected"'; } ?>>2 stars</option>
                            <option value="1" <?php if ($_GET['minRating'] == '1') { echo 'selected="selected"'; } ?>>1 stars</option>
                        </select>
                        to
                        <select name="maxRating">
                            <option value=""></option>                        
                            <option value="5" <?php if ($_GET['maxRating'] == '5') { echo 'selected="selected"'; } ?>>5 stars</option>
                            <option value="4" <?php if ($_GET['maxRating'] == '4') { echo 'selected="selected"'; } ?>>4 stars</option>
                            <option value="3" <?php if ($_GET['maxRating'] == '3') { echo 'selected="selected"'; } ?>>3 stars</option>                
                            <option value="2" <?php if ($_GET['maxRating'] == '2') { echo 'selected="selected"'; } ?>>2 stars</option>
                            <option value="1" <?php if ($_GET['maxRating'] == '1') { echo 'selected="selected"'; } ?>>1 stars</option>
                        </select>                            
                    <?php
                    } ?>               
                    <?php
                    if ($category->my->postingsHaveAge == 'Y') { 
                        echo $secondLine ? '<span style="margin-left:10px;"/>' : '<br /> ';
                        $secondLine = true; ?>              
                        age:
                        <input type="text" name="minAge" value="<?php echo $_GET['minAge'] ? htmlentities($_GET['minAge'], ENT_QUOTES, 'UTF-8') : 'min'; ?>" size="5" onfocus="if ( value == 'min' ) { value = ''; }" onblur="if ( value == '' ) { value = 'min'; }"/>
                        to
                        <input type="text" name="maxAge" value="<?php echo $_GET['maxAge'] ? htmlentities($_GET['maxAge'], ENT_QUOTES, 'UTF-8') : 'max'; ?>" size="5" onfocus="if ( value == 'max' ) { value = ''; }" onblur="if ( value == '' ) { value = 'max'; }"/>                            
                    <?php
                    } ?>                         
                    <input value="Search" class="button" type="submit" />
                </dd>
            </dl>
        </form>
        <script type="text/javascript">
            document.form.query.focus();
        </script>        
    </div>     
    
    <table width="100%">
        <tr>
            <td>
                <?php
                if ($previousWeekURL) { ?>                    
                    <p class="status" style="text-align:left">
                        <a href="<?php echo $previousWeekURL ?>">&laquo; Previous Week</a>
                    </p>
                <?php
                } ?>
            </td>
            <td>
                <p class="status">
                    <?php PaginationHelper::displayPaginationHeader(Config::$postingsPerPage, $_GET['start'], $query->getTotalCount()); ?>    
                    / <a class="post" href="<?php echo $postURL ?>"><?php echo $postText ?></a>
                </p>
             </td>
         </tr>
    </table>
    
    <?php
    $ulOpen = false;
    // Hack to ensure current date is always shown [Jon Aquino 2005-11-06]
    $dummyPostings = array();    
    if (isset($_GET['date'])) {
        $dummyPosting = XN_Content::create('Posting');
        $dummyPosting->my->dummyDate = $_GET['date'];
        $dummyPostings[] = $dummyPosting;
    }    
    foreach (PHPHelper::concatenate(array($dummyPostings, $postings)) as $posting) {           
        $date = $posting->my->dummyDate ? $posting->my->dummyDate : (isset($_GET['date']) ? $posting->my->date : $posting->createdDate);
        // $date will be null if user turned on postingsHaveDate for a category with existing postings [Jon Aquino 2005-10-27]
        if ($date) {
            $formattedDate = HTMLHelper::date(strtotime($date));
            if ($lastFormattedDate != $formattedDate) { 
                if ($ulOpen) { echo '</ul>'; } ?>                
                <p class="date"><?php echo $formattedDate; ?></p>
                <ul>
                <?php
                $ulOpen = true;
                $lastFormattedDate = $formattedDate;            
            }
        } ?>
        <?php if ($posting->my->dummyDate) { continue; } ?>
        <li><?php echo PostingController::summary($posting, $category, $subcategory) ?></li>       
    <?php    
    } 
    if ($ulOpen) { echo '</ul>'; } ?> 
    <?php PaginationHelper::displayPaginationFooter(Config::$postingsPerPage, $_GET['start'], $query->getTotalCount()) ?>
    <table width="100%">
        <tr>
            <td>
                <?php
                // Drop the date parameter. If the date parameter is specified, the 
                // sort attribute and direction don't make sense for the RSS feed [Jon Aquino 2005-11-09]
                ?>
                <p><a href="index.php?<?php echo htmlentities(HTMLHelper::urlParametersWithout(array('date')), ENT_QUOTES, 'UTF-8'); ?>&amp;view=rss&amp;xn_auth=no">RSS</a></p>            
            </td>
        </tr>
        <tr>
            <td>
                <?php
                require_once 'badge.php';
                if (XN_Profile::current()->screenName && XN_Profile::current()->screenName == $_GET['by']) {
                    display_badge_link('Posting', 'posting', 'postings', 'http://livebadge.ning.com/images/badge_wishlist.png', 'FreeSansBold.ttf', 12, 30, 26, 'left', XN_Application::load()->name, 'FreeSans.ttf', 6.3, 30, 10, 'left');
                }
                ?>            
            </td>        
        </tr>        
    </table>

    <?php
    if (Config::$googleMapsAPIKey && Config::$frontPageMapInitialExtentURL) { ?>        
        <?php
        require_once 'helpers/GoogleMapsHelper.php';
        GoogleMapsHelper::instance()->displayMapForArray($geocodedPostings, '75%', '300px', Config::$frontPageMapInitialExtentURL); ?>
    <?php
    } ?>    
</div>



