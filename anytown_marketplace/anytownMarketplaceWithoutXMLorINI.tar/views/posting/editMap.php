<div id="main">
    <?php HTMLHelper::displayErrors($errors); ?>
    <h2>Edit Your Posting's Map</h2>    
    <form id="form" name="form" method="POST" action="index.php?controller=posting&amp;action=updateMap&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>">    
        <dl>
            <?php include '_mapForm.php' ?>
            <dd><?php echo $form->submit(null, 'Continue', 'class="button"') ?></dd>
        </dl>
    </form>                        
</div><!-- end #main -->

<script type="text/javascript">
    document.form.address.focus();
</script>
