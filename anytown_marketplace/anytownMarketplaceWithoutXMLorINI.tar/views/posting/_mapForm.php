<dt class="map-form-instructions">
    Move/zoom the map to the desired location. 
    Or (for US locations) use the Address Finder to zoom to an address.
</dt>
<dt>
    <table style="background:#FBFFCC; width:440px; margin-bottom:15px">
        <tr>
            <td style="padding:10px">
                <span class="address-finder-heading">Address Finder</span> <br />
                <span class="address-finder-instructions">(Currently US only. For non-US locations, simply move/zoom the map directly)</span> 
                <div style="margin-top:5px">
                    <span class="address-finder-field-heading">US Street Address or Intersection:</span> <span class="address-finder-instructions">(Example: West 42nd &amp; Broadway)</span> <br />
                    <?php echo $form->text('address', 'class="address-input-field" id="address"') ?>
                </div>
                <div>
                    <span class="address-finder-field-heading">City:</span> <?php echo $form->text('city','class="city-input-field" id="city"') ?>  
                    <span class="address-finder-field-heading">State:</span> <?php echo $form->text('state','size="2" maxlength="2" id="state"') ?>
                    <!-- Use a submit button that returns false, so hitting Enter won't submit form. [Jon Aquino 2005-11-21] -->                    
                    <?php echo $form->submit(null, 'Zoom', 'class="button" onClick="getaddress(); return false;"') ?>
                </div>
            </td>
        </tr>
    </table>
</dt>    
<?php require_once 'lib/MapBrowser/MapBrowser.php' ?>
<?php MapBrowser::displayMapBrowser($_POST['latitude'] ? $_POST['latitude'] : ($posting ? $posting->my->latitude : null), $_POST['longitude'] ? $_POST['longitude'] : ($posting ? $posting->my->longitude : null), $_POST['zoomLevel'] ? $_POST['zoomLevel'] : ($posting ? $posting->my->zoomLevel : null), $form) ?>
<br />
