<div id="main">
    <?php HTMLHelper::displayErrors($errors); ?>
    <h2>Edit Your Posting in <span><?php echo $category->my->h('xtitle') . ($subcategory ? ' &gt; ' . $subcategory->my->h('xtitle') : '') ?></span></h2>    
    <!--
    enctype must be multipart/form-data for images. 
    See http://developerdocumentation.ning.com/post.php?Post:slug=XNC_Image%3A%3AbuildFormField
    [Jon Aquino 2005-09-12]
    --> 
    <form id="form" name="form" method="POST" enctype="multipart/form-data" action="index.php?controller=posting&amp;action=update&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>">    
        <dl>
            <?php include '_form.php' ?>
            <dd><?php echo $form->submit(null, 'Continue', 'class="button"') ?></dd>
        </dl>
    </form>                        
</div><!-- end #main -->

<script type="text/javascript">
    document.form.xtitle.focus();
</script>
