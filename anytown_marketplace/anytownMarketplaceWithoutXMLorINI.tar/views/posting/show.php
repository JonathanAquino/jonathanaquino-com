<div id="main">
    <?php
    if ($_GET['messageSent'] == 'yes') {
        echo '<h4 class="systemMsg">Thanks! Your message has been sent to the person who posted this.</h4>';
    } ?>
    <?php HTMLHelper::displayErrors($errors); ?>
    <?php HTMLHelper::displayBreadcrumbs($category, $subcategory, $posting, false); ?>
    <div id="listingTitle">
        <h2>        
            <?php echo self::formattedTitle($posting); ?>
        </h2>                		
        <p>
            <?php if ($posting->my->h('date')) { echo 'Event Date: ' . HTMLHelper::date(strtotime($posting->my->h('date'))) . '<br/>'; } ?>             
            <?php 
            if ($posting->my->rating) { ?>
                Rated <img class="plain-image" src="images/stars<?php echo ($posting->my->rating) ?>.gif" />
            <?php 
            } else { ?>
                Posted 
            <?php
            } ?> 
            on <?php echo HTMLHelper::date(strtotime($posting->createdDate)) ?>
            <?php
            if ($posting->my->displayingUsername == 'Y') { ?>
                by <a class="user" href="index.php?controller=posting&amp;action=list&amp;by=<?php echo $posting->urlencode('contributorName') ?>&amp;lastBreadcrumb=<?php echo $posting->urlencode('contributorName') ?>"><?php echo $posting->h('contributorName') ?></a>
            <?php
            } else { ?>
                by anonymous
            <?php
            } ?>
            <?php 
            $popularTagsHTML = HTMLHelper::popularTagsHTML($posting);             
            if ($popularTagsHTML) { echo 'and tagged ' . $popularTagsHTML; } ?>            
            <?php
            if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserContributed($posting))) { ?>
                <a class="editDelete" href="index.php?controller=posting&amp;action=edit&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>">Edit</a> |
                <a class="editDelete" href="index.php?controller=posting&amp;action=delete&amp;id=<?php echo $posting->id ?>" onclick="javascript:return confirm('Are you sure you want to delete this posting?')">Delete</a>
            <?php
            } ?>
            <?php 
            if ($category->my->postingsHaveRatings == 'Y' && count($comments) > 0 && $posting->my->averageRating) { ?>
                <br />
                Average Rating: <img src="images/stars<?php echo $posting->my->averageRating ?>.gif" />
            <?php
            } ?>                
            <br />
            <?php
            if ($category->my->postingsHaveMessaging == 'Y' && $posting->my->allowingMessaging == 'Y' && ! isset($_GET['messageSent'])) { ?>
                <strong><a href="index.php?controller=posting&amp;action=replyByEmail&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>">Reply by email</a></strong> (You may not contact this poster with services or other commercial interests)
            <?php
            } ?>
        </p>
    </div>
    <?php /* The seemingly missing > is not a typo */ ?>
    <div <?php echo ($category->my->postingsHaveComments == 'Y' || $category->my->postingsHaveRatings == 'Y') ? '' : ' id="listingTitle"' ?>>
        <p><?php echo HTMLHelper::removeEvilTags(nl2br($posting->my->xdescription)); ?></p>
        <?php
        $deletePhotoLinks = array();
        for ($i = 1; $i <= 3; $i++) {
            if (HTMLHelper::displayImage($posting, 'photo' . $i, false)) {
                $deletePhotoLinks[] = '<a class="editDelete" href="index.php?controller=posting&amp;action=deletePhoto&amp;id=' . $posting->id . '&amp;photoNumber=' . $i . '" onclick="javascript:return confirm(\'Are you sure you want to delete this photo?\')">Delete Photo ' . $i . '</a>'; 
            }            
        } 
        if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserContributed($posting))) {
            if (count($deletePhotoLinks) > 0) {
                echo '<p>' . implode(' | ', $deletePhotoLinks) . '</p>';
            }
        }        
        if (Config::$googleMapsAPIKey) {
            // The user may either have typed in an address or visually indicated a latitude/longitude. [Jon Aquino 2005-11-19]
            if (! is_null($posting->my->latitude)) {                
                require_once 'helpers/GoogleMapsHelper.php';
                GoogleMapsHelper::instance()->displayMap($posting, '530px', '200px');
                echo '<br />';
                if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserContributed($posting))) { ?>                
                    <p>
                        <a class="editDelete" href="index.php?controller=posting&amp;action=editMap&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>">Edit Map</a>
                        |
                        <a class="editDelete" href="index.php?controller=posting&amp;action=deleteMap&amp;id=<?php echo $posting->id ?>" onclick="javascript:return confirm('Are you sure you want to delete this map?')">Delete Map</a>
                    </p>
                <?php
                } ?>
            <?php
            } elseif (! SecurityHelper::failed(SecurityHelper::checkCurrentUserContributed($posting))) { ?>
                <p><a class="editDelete" href="index.php?controller=posting&amp;action=newMap&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $posting->id ?>">Add A Map To Your Posting</a></p>
            <?php
            }
        }
        ?>     
    </div>
    <?php
    if ($category->my->postingsHaveComments == 'Y' || $category->my->postingsHaveRatings == 'Y') { ?>        
        <?php        
        if (count($comments) > 0) { ?>
            <div id="listingDetails">
            <h2><?php echo $category->my->postingsHaveRatings == 'Y' ? 'Ratings &amp; Reviews' : 'Comments' ?></h2>
            <?php 
            foreach ($comments as $comment) { ?>
                <p class="posted">
                    <?php 
                    if ($comment->my->rating) { ?>
                        Rated <img class="plain-image" src="images/stars<?php echo ($comment->my->rating) ?>.gif" />
                    <?php 
                    } else { ?>
                        Posted 
                    <?php
                    } ?>
                    on <?php echo HTMLHelper::date(strtotime($comment->createdDate)) ?> 
                    by <a class="user" href="index.php?controller=posting&amp;action=list&amp;by=<?php echo $comment->urlencode('contributorName') ?>&amp;lastBreadcrumb=<?php echo $comment->urlencode('contributorName') ?>"><?php echo $comment->h('contributorName') ?></a>
                    <?php
                    if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserContributed($comment))) { 
                        // categoryID and subcategoryID are used by the Post link in the header [Jon Aquino 2005-11-04] 
                        ?>
                        <a class="editDelete" style="font-weight:normal;" href="index.php?controller=comment&amp;action=edit&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $comment->id ?>">Edit</a> | 
                        <a class="editDelete" style="font-weight:normal;" href="index.php?controller=comment&amp;action=delete&amp;id=<?php echo $comment->id ?>"  onclick="javascript:return confirm('Are you sure you want to delete this comment?')">Delete</a>
                    <?php
                    } ?>                        
                </p>                                        
                <p><?php echo HTMLHelper::removeEvilTags(nl2br($comment->my->xdescription)) ?></p>
            <?php
            } ?>
            </div>
        <?php
        }    
        if (! SecurityHelper::failed(SecurityHelper::checkCurrentUserHasNotRated($posting))) { ?>
            <h2 id="add"><?php echo $category->my->postingsHaveRatings == 'Y' ? 'Add Your Rating &amp; Review' : 'Post A Comment' ?> </h2>
            <form method="POST" action="index.php?controller=comment&amp;action=create&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;postingID=<?php echo $posting->id ?>">
                <dl>
                    <?php 
                    include 'views/shared/_commentForm.php'; ?> 
                    <dd><?php echo $form->submit(null, 'Add', 'class="button"') ?></dd>
                </dl>
            </form>
        <?php
        } ?>                
    <?php        
    } ?>    
</div>
