<?php
if (count($subcategories) > 0) { ?>
    <dt>
        Subcategory:
        <select name="subcategoryID">            
            <?php
            foreach ($subcategories as $subcategory) { ?>
                <option value="<?php echo $subcategory->id ?>" <?php if ($_POST['subcategoryID'] == $subcategory->id || (!$_POST['subcategoryID'] && $_GET['subcategoryID'] == $subcategory->id)) { echo 'selected="selected"'; } ?>><?php echo $subcategory->my->h('xtitle') ?></option>
            <?php
            } ?>
        </select>	    
    </dt>
<?php
} ?>
<dt><label for="xtitle">Title:</label></dt>  
<dd><?php echo $form->text('xtitle', 'class="input-field"') ?></dd>
<?php
if ($category->my->postingsHaveLocation == 'Y') { ?>
    <dt><label for="location">Location/Area:</label> <?php echo $form->text('location', 'size="20"') ?></dt>
<?php
} ?>
<?php
if ($category->my->postingsHavePrice == 'Y') { ?>
    <dt><label for="price">$ </label> <?php echo $form->text('price', 'size="10"') ?></dt>
<?php
} ?>
<?php
if ($category->my->postingsHaveDate == 'Y') { ?>
    <dt>
        Date (mm/dd/yyyy):
        <?php echo $form->text('month','size="2" maxlength="2"') ?>
        /
        <?php echo $form->text('day','size="2" maxlength="2"') ?>
        /
        <?php echo $form->text('year','size="4" maxlength="4"') ?>
    </dt>  
<?php
} ?>
<?php
if ($category->my->postingsHaveAge == 'Y') { ?>
    <dt><label for="age">Your Age:</label> <?php echo $form->text('age', 'size="3"') ?></dt>
<?php
} ?>
<?php
if ($category->my->postingsHaveRatings == 'Y') { ?>
    <dt><label for="rating">Your Rating:</label></dt>
    <dd><?php echo $form->select('rating', array('5' => '5 stars', '4' => '4 stars', '3' => '3 stars', '2' => '2 stars', '1' => '1 star')) ?></dd>
<?php
} ?>
<dt><label for="xdescription">Description:</label> <small>(some HTML is allowed)</small></dt>  
<dd><?php echo $form->textarea('xdescription', 'rows="6" class="input-field"') ?></dd>
<dt>
    <?php HTMLHelper::displayImage($posting, 'photo1', true) ?>
    <?php HTMLHelper::displayImage($posting, 'photo2', true) ?>
    <?php HTMLHelper::displayImage($posting, 'photo3', true) ?>
</dt>
<dt>Upload Photo(s):</dt>
<dd style="padding:0 0 5px 0"><?php echo XNC_Image::create(XN_Content::create('Posting'), "photo1")->buildFormField()?></dd>
<dd style="padding:0 0 5px 0"><?php echo XNC_Image::create(XN_Content::create('Posting'), "photo2")->buildFormField()?></dd>
<dd style="padding:0 0 5px 0"><?php echo XNC_Image::create(XN_Content::create('Posting'), "photo3")->buildFormField()?><br />
<small>We can only accept .jpg, .jpeg, .png, and .gif images at this time</small></dd>
<dt>Contact Preferences:</dt>  
<dd><?php echo $form->checkbox('displayingUsername', 'Y') ?> <label for="displayingUsername">Display my username</label> <small style="padding-left:10px;">(If you don't tick this box, your posting will be anonymous)</small></dd>
<?php
if ($category->my->postingsHaveMessaging == 'Y') { ?>
    <dd><?php echo $form->checkbox('allowingMessaging', 'Y') ?> <label for="allowingMessaging">Allow people to send me messages</label> <small style="padding-left:10px;">(If you don't tick this box, be sure to include contact info somewhere in your description!)</small></dd>
<?php
} ?>
<dt><label for="tags">Tag This Posting:</label></dt>        
<dd><?php echo $form->text('tags', 'class="input-field"') ?></dd>


