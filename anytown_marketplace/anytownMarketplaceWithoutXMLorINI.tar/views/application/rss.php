<?php
// The output must begin with <?xml ... If you are getting an error about
// "xml processing instruction not at start of external entity", check that
// none of the include files have trailing whitespace that is getting output.
// [Jon Aquino 2005-11-09]

XN_Application::includeFile('alphacomponents','/Alpha/Format/RSS.php');
$feed = new XNC_Alpha_Format_RSS();
$feed->version('0.91');
$feed->title('Anytown Marketplace Clones');
$feed->link('http://anytownmarketplace.ning.com');
$feed->description('Active apps that are clones of Anytown Marketplace');
// pubDate and lastBuild date are required by some aggregators, like Bloglines.
// See http://jonaquino.blogspot.com/2005/02/rolling-your-own-rss-feed-be-sure-to.html
// [Jon Aquino 2005-11-09]
$feed->pubDate(date('r'));
$feed->lastBuildDate(date('r'));
foreach ($applications as $application) { 
    if ($application->owner->publishedState == 'N') { continue; }
    $item = $feed->createItem();
    $item->title($application->owner->name);
    $item->link('http://' . $application->owner->relativeUrl . '.ning.com');
    $item->description('by ' . $application->contributorName);
    $item->pubDate($application->createdDate);
    $feed->items[] = $item;
} 
header("Content-Type: text/xml");
echo $feed->toXML();
?>

