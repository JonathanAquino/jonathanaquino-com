<div id="main">       
    <h2>Other Cities/Groups</h2> 
    <br />
    <p>
        Don't see your city or group listed? Clone <a href="http://anytownmarketplace.ning.com">Anytown Marketplace</a> 
        or <a href="http://anytownmarketplacewithmaps.ning.com">Anytown Marketplace With Maps</a> for your city or club! 
    </p>
    <br />
    <?php
    foreach ($applications as $application) { 
        if ($application->owner->publishedState == 'N') { continue; } ?>           
        <li>
            <a href="http://<?php echo htmlentities($application->owner->relativeUrl, ENT_QUOTES, 'UTF-8') ?>.ning.com"><?php echo htmlentities($application->owner->name, ENT_QUOTES, 'UTF-8') ?></a>
            by <a class="user" href="http://<?php echo htmlentities($application->owner->relativeUrl, ENT_QUOTES, 'UTF-8') ?>.ning.com/index.php?controller=posting&action=list&by=<?php echo $application->urlencode('contributorName') ?>&lastBreadcrumb=<?php echo $application->urlencode('contributorName') ?>"><?php echo $application->h('contributorName') ?></a>
            <span style="color:black"><?php echo HTMLHelper::date(strtotime($application->createdDate)) ?></span>
            <?php if ($location = HTMLHelper::location($application, $application->owner->relativeUrl)) { echo '<span>' . $location . '</span>'; } ?>             
        </li>        
    <?php    
    } ?>      
    <table width="100%">
        <tr>
            <td>
                <p><a href="index.php?controller=application&action=rss&xn_auth=no">RSS</a></p>            
            </td>
        </tr>
    </table>      
</div>

