<div id="main">
	<h4 class="systemMsg"><?php echo $header ?></h4>
    <?php
    if ($message) { 
        echo '<p>' . $message . '</p>';
    } ?>	
    <?php
    if ($exception) {
        echo '<div class="stackTrace">Technical stuff:<br/><br/>' . $exception->getMessage() . '<br />' . nl2br($exception->getTraceAsString()) . '</div>'; 
    } ?>    
</div><!-- end #main -->
