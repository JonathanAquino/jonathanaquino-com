<?php
if ($category->my->postingsHaveRatings == 'Y') { ?>
    <dt><label for="rating">Your Rating:</label></dt>
    <dd><?php echo $form->select('rating', array('5' => '5 stars', '4' => '4 stars', '3' => '3 stars', '2' => '2 stars', '1' => '1 star')) ?></dd>
<?php
} ?>
<dt><label for="xdescription">Your <?php echo $category->my->postingsHaveRatings == 'Y' ? 'Review' : 'Comment' ?>:</label></dt>
<dd><?php echo $form->textarea('xdescription', 'rows="6" class="input-field"') ?></dd>
