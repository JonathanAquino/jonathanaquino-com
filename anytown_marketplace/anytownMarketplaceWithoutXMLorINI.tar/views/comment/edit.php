<?php HTMLHelper::displayErrors($errors); ?>
<?php HTMLHelper::displayBreadcrumbs($category, $subcategory, $posting, true); ?>
<h2>Edit Your Comment</h2>
<?php
// categoryID and subcategoryID are used by the Post link in the header [Jon Aquino 2005-11-04]
?>
<form id="form" name="form" method="POST" action="index.php?controller=comment&amp;action=update&amp;categoryID=<?php echo CategoryHelper::contentId($posting, 'category') ?>&amp;subcategoryID=<?php echo CategoryHelper::contentId($posting, 'subcategory') ?>&amp;id=<?php echo $comment->id ?>">
    <dl>
        <?php include 'views/shared/_commentForm.php' ?>
        <dt><?php echo $form->submit(null, 'Continue', 'class="button"') ?></dt>  
    </dl>
</form>

<script type="text/javascript">
    document.form.xdescription.focus();
</script>
