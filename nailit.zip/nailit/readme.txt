Nail It!
========

This program runs in the system tray and allows you to make windows
"sticky", so that they remain above other windows.  This is useful
for keeping readme files such as this one visible while installing
software, keeping floating clocks in sight, and lots of other uses.

I have included a copy of ctl3d32.dll in case you need it.  Most
system have a copy already but there have been a few people who
write to me each month saying that the dll is missing.  If you don't
have it copy it into your windows\system directory.  Most people won't
need to worry about it.

Steps To Use This Software
==========================

	Run it.

Status Of This Software
=======================

 Current Version: 1.0
   Last Released: November 22, 1996

This program is freeware.  If you like it, send me Email.  If it breaks
send me Email.  I am actively developing all of my software so please
let me know what you do and do not like.  The latest version of this
library is available from the WWW address below.

This program is REDISTRIBUTABLE.  If you want to redistribute please
send me email detailing how and where you are going to be doing so.

How To Contact The Author
=========================

This is where I get to be positively shameless and tell you that if
you haven't explored all the nooks and cranies of my web site
you're missing more than you think.  So go to the address below
and snoop around.

	Email:  Don Neufeld <cv@common.net>
	Web:	http://www.common.net/~cv/

Copyright 1997 Don Neufeld