/*
SQLyog v4.06 RC1
Host - 4.1.10-log : Database - yubnub
*********************************************************************
Server version : 4.1.10-log
*/

